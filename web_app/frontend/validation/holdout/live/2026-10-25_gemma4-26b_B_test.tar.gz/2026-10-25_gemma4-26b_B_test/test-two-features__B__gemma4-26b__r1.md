# test-two-features__B__gemma4:26b__r1

- Case: `test-two-features` (test set) · Arm B: Copilot with skills and guardrails
- Model: gemma4:26b (Ollama) (`gemma4:26b`, temperature 0.2) · run 1
- Protocol 2026-10-24.6 · commit 7456af9dfe904c66b62dc900f39aa734a6c9c447 · 2026-10-25T01:24:19.201Z → 2026-10-25T01:25:53.081Z (94 s)
- Server: Ollama 0.40.2 · context window: num_ctx 40,960 (sized per request; the model holds 262,144)
- Reply cap: num_ctx minus the prompt estimate, per request · final round: no tools sent (the native API has no tool_choice)
- Temperature 0.2 (a request asked again after a loop: 0.6 or more) · limits: 6 rounds × 4 calls, 3600 s a turn, results 3,000 / turn 12,000 characters, 2 questions, 2 gate send-backs
- Context guard: refuses a request that would not fit, never cuts it (2.5 characters a token, 1.4 for tool JSON; 8,192-token reply reserve)
- Tools offered: read_run_data, find_gr_peaks, list_sites, analyze_displacement_directions, compute_bond_angles, polyhedral_distortion, analyze_clusters, analyze_modulations, detect_symmetry, measure_symmetry_lowering, ask_user, read_skill
- Skills offered: coordination-shells, displacement-anisotropy, local-order, local-symmetry, rmc-fit-assessment
- View: Detected SG at 0.2 Å with its ladder, nothing hidden, no PCA table, Live Data off
- Context sections: structure, symmetry, pair_correlations, datasets (absent: configuration_optimization, run_settings, pca_displacements, partial_weights, convergence) · one fresh question, no earlier turns

## Step 0 · the question

> Analyse the local structure of this RMC configuration. Is there order or distortion beyond the average structure (off-centred atoms, correlated clusters, a superstructure, distorted polyhedra)? What is the average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on the Workbench's analyses, and say so plainly if there is no such order.
> 
> Finish with one line that starts with VERDICT and holds a JSON object, after everything else (the Outcome line included):
> VERDICT {"features": [{"kind": "...", "element": "...", "direction_uvw": [u, v, w] or null, "magnitude_A": number or null, "q": [h, k, l] or null}], "space_group": "..." or null, "chiral": true/false/null, "centrosymmetric": true/false/null, "polar": true/false/null}
> kind is one of off_centre, modulation, cluster_distortion, cluster_breathing, rigid_cluster, jahn_teller, symmetry_lowering. features is [] when there is no order beyond thermal motion. direction_uvw is a crystal direction; magnitude_A the static displacement (off_centre, symmetry_lowering) or the long minus short bond (jahn_teller); q in reciprocal-lattice units. Use null for what you did not determine. A number may be a reference to a tool result, as in the answer ("magnitude_A": {{r3.sites.0.shift_A}}): the app fills it in; a text reference goes inside its quotes ("element": "{{r3.sites.0.element}}").

## Step 1 · read_skill · round 1

**Model reasoning before the call:**

> The user wants a comprehensive analysis of the local structure of the provided RMC configuration.
> I need to check for:
> 1.  **Off-centered atoms**: Check `list_sites` for large displacements or non-Gaussianity.
> 2.  **Correlated clusters**: Check `analyze_clusters` for dimers, trimers, etc.
> 3.  **Superstructure**: Check `analyze_modulations` for order enlarging the unit cell.
> 4.  **Distorted polyhedra**: Check `polyhedral_distortion` for distorted octahedra/tetrahedra.
> 5.  **Average structure symmetry**: Check `detect_symmetry` and the `symmetry.ladder` in the context.
> 
> Plan:
> 1.  Read `rmc-fit-assessment` skill to understand how to judge the run first.
> 2.  Read `local-order` skill to guide the search for order.
> 3.  Read `local-symmetry` skill to guide the symmetry analysis.
> 4.  Read `displacement-anisotropy` skill to guide the off-centering analysis.
> 5.  Read `coordination-shells` skill to guide the polyhedra/cluster analysis.
> 6.  Check `list_sites` to see if any sites are particularly disordered or anisotropic.
> 7.  Check `find_gr_peaks` for `Cr-Br` and `Br-Br` to identify coordination shells.
> 8.  If `Cr-Br` shows a split shell or distortion, use `polyhedral_distortion`.
> 9.  If `Cr-Br` or `Br-Br` shows clusters, use `analyze_clusters`.
> 10. Check `analyze_modulations` for superstructures.
> 11. Check `detect_symmetry` for the average structure.
> 12. Check `measure_symmetry_lowering` if there's evidence of symmetry breaking.
> 
> Let's start by examining the context and reading the necessary skills.
> 
> Context analysis:
> - Space group: `Pm-3m (No. 221)`.
> - Symmetry ladder: `P1` -> `Pm` -> `Amm2` -> `P4/mmm` -> `Pm-3m`.
> - `Br` (6f) has `mean_disp_A: 0.23`.
> - `Cr` (1b) has `mean_disp_A: 0.15`.
> - `Rb` (1a) has `mean_disp_A: 0.096`.
> - `Cr-Br` pair: `first_shell` shows `mean_d_A: 2.68`, `cn_Br_per_Cr: 6`. This suggests octahedra. The peaks are at 2.52 and 2.96. This is a split shell.
> - `Br-Br` pair: `first_shell` shows `cn_Br_per_Br: 4`.
> - `Br-Br` peaks at 3.58 and 3.9.
> 
> Step 1: Read skills.

**Arguments:** `{"name":"rmc-fit-assessment"}` · status ok · 0.07520800037309527 ms

<details><summary>Result the model read</summary>

```json
{
 "skill": "rmc-fit-assessment",
 "text": "# RMC fit assessment\n\n**Status: Interviewed 2026-10-24.** The steps are the user's own answers of that day\n(docs/SKILL_INTERVIEWS.md §1).\n\nRMCProfile moves atoms to fit the data under constraints. It is a configuration optimization, not\na Rietveld refinement: never call it a refinement, and there are no esds of refined parameters.\n\n## Steps\n\n1. **What was fitted.** From the run context: the datasets and their Rwp. A Fourier-transform\n   file (`*_FT_*`) is the same measurement as its F(Q), shown in real space: one measurement\n   fitted in both spaces counts once. Read `partial_weights` (Faber–Ziman): a partial that\n   carries a few % of the signal is weakly constrained by the data (Ga–X in GaTa₄Se₈, about 5 %).\n2. **Convergence.** Judge every fit term and the total (`assess_convergence`, the context's\n   `watchdog_status`). Say \"converged\" only when none is still falling beyond its noise over the\n   last tenth of the run, even when a 48-point plot looks flat; quote the change over the last\n   tenth. A run still improving may answer first-shell quantities (distances, CN) with a \"still\n   improving\" caveat; for subtle effects (distortions, directions, order) the run must continue.\n3. **Where the fit misses.** Call `compare_fit` for each dataset you judge, G(r) **and** F(Q):\n   Rw, the share of the misfit per range of r or Q, the largest residual features. There is no\n   fixed Rw cutoff, for X-ray and neutron data alike: distrust the run when most of the misfit\n   sits in one r or Q range that the box size or the scale doesn't explain, or when residual\n   features rise above the data's noise. A misfit concentrated at low r points at local structure\n   or a constraint; at the highest r or the lowest Q, at the box size or the scale.\n4. **Constraints.** For each pair whose closest-approach constraint (`min_distances_A`) sits\n   near its first peak, call `find_gr_peaks`. When g(r) just above the cut is above 5 % of the\n   peak, the peak is constraint-limited (the Demo's Ga–Se at 2.2 Å: g at 8.7 % of the peak):\n   interpret nothing on its low-r side, name the pair, and suggest rerunning with the constraint\n   loosened.\n5. **Sampling.** Before quoting a distribution or a small effect, have at least 3 independent\n   runs or configurations and at least 10 accepted moves per atom past convergence; below that,\n   the answer says so. Moves per atom are on the model card and in the context: the Demo's 3.5\n   accepted moves per atom is too light. The distributions of weakly weighted atoms are the least\n   reliable.\n6. **Never a finding.** Refuse to report as a finding: an Rw below the data's noise presented as\n   a better fit; a detailed claim about a partial under 5 % of the signal; order at a box-scale q\n   (step 7); any feature that differs between independent runs.\n7. **Long waves:** a long wave is a correlation the finite box can't represent, so it says\n   nothing about order at its own q; a point or mode that passes its own test at another q is\n   judged on that test alone. A long wave has every |q_i| ≤ 0.25 of the cell's reciprocal axes\n   (`analyze_modulations` reports the strongest). The test, as `analyze_modulations` applies it:\n   ratio ≥ 3 and ≥ 3σ against independent cells, corrected over the points tested.\n\n## Acceptance checklist\n\n- [ ] The datasets are named correctly (an F(Q) and its FT count once).\n- [ ] Convergence judged on every fit term and the total; never \"converged\" while one is still\n      falling beyond its noise over the last tenth.\n- [ ] `compare_fit` ran on every dataset the answer judges, read without a fixed Rw cutoff.\n- [ ] Constraint-limited peaks are named, with the constraint distance; nothing is read on their\n      low-r side.\n- [ ] Sampling stated: moves per atom past convergence and the number of independent runs.\n- [ ] No order is claimed at a box-scale wavevector (every |q_i| ≤ 0.25).\n- [ ] Nothing that step 6 refuses is reported as a finding.\n- [ ] Every number comes from a tool or the context; no invented uncertainty.\n\n## Known failure modes\n\n- **Called a still-falling run converged** (\"converged — a plateau\", the review's first round):\n  the history is ln(χ²) of one term, and a slow decline looks flat. *Firm rule in the app:* an\n  answer that says the run has converged while the watchdog or `assess_convergence` says\n  improving or diverging gets a warning under it.\n- **Read F(Q) and its FT as two datasets** (review): the context now marks the FT file as the\n  same measurement.\n- **Missed the Ga–Se pile-up at the 2.2 Å constraint** (review): `find_gr_peaks` now checks\n  each pair's constraint.\n- **Judged one space only** (the 5 K run: G(r) misfit checked, F(Q) not, still \"achieved\").\n- **The verdict was a self-assessment:** models wrote \"achieved\" even over a cut coordination\n  shell. *Firm rule in the app (THY-18):* the Outcome is computed from the checks; the model's\n  line only explains it.\n- **Order claimed at a box-scale wavevector** (step 7). *Firm rule in the app:* an answer that\n  claims order at a box-scale wavevector (every |q_i| ≤ 0.25) gets a warning under it.\n- **A distribution quoted from one configuration** (step 5). *Firm rule in the app:* an answer\n  that quotes a distribution from a single configuration without saying so gets a warning under\n  it.\n\n## Report\n\nAlways: the datasets and their weights, the convergence status, each dataset's Rw and where its\nmisfit sits, the constraint-limited pairs, and the sampling with the number of runs. Never:\n\"refinement\", esds as if parameters were refined, or order at a box-scale q.\n\nReferences (read one with read_skill and `reference`):\n- run-numbers: the Demo's and the 5 K run's measured numbers from the 2026-10-10 review, to compare against."
}
```

</details>

## Step 2 · list_sites · round 2

**Model reasoning before the call:**

> The user wants an analysis of the local structure of the RMC configuration.
> I need to check for:
> 1. Off-centered atoms.
> 2. Correlated clusters.
> 3. A superstructure.
> 4. Distorted polyhedra.
> 5. Average structure's space group, chirality, centrosymmetry, and polarity.
> 
> From the context:
> - Space group: `Pm-3m (No. 221)`.
> - Point group: `m-3m`.
> - `m-3m` is cubic, centrosymmetric, achiral, and non-polar.
> - `Pm-3m` is the average structure.
> 
> To check for order/distortion:
> - `local-symmetry`: To see if there's symmetry lowering.
> - `displacement-anisotropy`: To check for off-centering or anisotropic motion.
> - `local-order`: To check for clusters or superstructures.
> - `coordination-shells`: To check for distorted polyhedra or split shells.
> 
> First, I'll check the convergence and fit quality using `rmc-fit-assessment` logic. The context doesn't provide the `.log` or `watchdog_status` directly in the JSON, but it provides `datasets`. I'll check the `pair_correlations` for any constraint-limited peaks.
> 
> Looking at `pair_correlations`:
> - `Cr-Br`: `avg_structure_d_A`: 2.67. `gr_peaks_A`: 2.52, 2.96. `first_shell`: `mean_d_A`: 2.68. No `min_distances_A` mentioned in the JSON, but I should check if any peak is at a constraint. The `min_distances_A` are not in the JSON, but I can check the `pair_correlations` for peaks near the average distance.
> - `Br-Br`: `avg_structure_d_A`: 3.77. `gr_peaks_A`: 3.58, 3.9. `first_shell`: `mean_d_A`: 3.8.
> 
> I'll start by checking the symmetry and the sites.
> The sites are:
> - Br: 6f, `mean_disp_A`: 0.23
> - Cr: 1b, `mean_disp_A`: 0.15
> - Rb: 1a, `mean_disp_A`: 0.096
> 
> I'll use `list_sites` to see the displacement statistics.
> Then I'll use `measure_symmetry_lowering` to see if the symmetry is broken.
> Then I'll use `analyze_clusters` or `polyhedral_distortion` if I find evidence of distortion.
> I'll also check `analyze_displacement_directions` for the Br site since it has the largest displacement.
> 
> Step 1: Check site displacements and anisotropy.
> Step 2: Check symmetry lowering.
> Step 3: Check for polyhedral distortion or clusters.
> 
> Let's start with `list_sites` for Br.

**Arguments:** `{"element":"Br"}` · status ok · 15.219791000243276 ms

**Checks the model read:**

- note: Split: sites 5 (Br), 7 (Br), 8 (Br), 6 (Br), 3 (Br), 4 (Br) have two positions along PC1 (PC1 excess kurtosis ≤ −0.5, at least 3 sampling errors below 0); delta_A is the static displacement, along pc1_uvw.
- ok: 6 sites, 2744 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; pc1_uvw = PC1 as a direct-lattice direction [u v w] (not a plane normal), where PC1 is resolved; delta_A = static displacement along PC1 of a split site (two positions: PC1 excess kurtosis ≤ −0.5 and 3 sampling errors below 0), sqrt(rms1² − rms⊥²) with rms⊥² = (rms2² + rms3²)/2: ±delta_A for two equally occupied positions, their RMS otherwise; delta_se_A = its sampling error; split sites first (largest delta_A first), then by |kurtosis|, largest first",
 "element": "Br",
 "n_sites": 6,
 "total_atoms": 2744,
 "largest_U_iso_refs": [
  5,
  7,
  8
 ],
 "largest_abs_kurtosis_refs": [
  4,
  7,
  3
 ],
 "most_anisotropic_refs": [
  3,
  8,
  5
 ],
 "sites": [
  {
   "ref": 5,
   "site": "Br",
   "count": 343,
   "U_iso_A2": 0.0184,
   "rms_axes_A": [
    0.221,
    0.0578,
    0.0538
   ],
   "anisotropy": 4.11,
   "kurtosis": -0.191,
   "kurtosis_axes": [
    -1.36,
    null,
    null
   ],
   "pc1_uvw": [
    -0.01,
    1,
    0.02
   ],
   "delta_A": 0.214,
   "delta_se_A": 0.0049
  },
  {
   "ref": 7,
   "site": "Br",
   "count": 343,
   "U_iso_A2": 0.0179,
   "rms_axes_A": [
    0.219,
    0.0548,
    0.0533
   ],
   "anisotropy": 4.1,
   "kurtosis": -0.305,
   "kurtosis_axes": [
    -1.43,
    null,
    null
   ],
   "pc1_uvw": [
    0.01,
    -0.01,
    1
   ],
   "delta_A": 0.212,
   "delta_se_A": 0.0046
  },
  {
   "ref": 8,
   "site": "Br",
   "count": 343,
   "U_iso_A2": 0.0179,
   "rms_axes_A": [
    0.219,
    0.055,
    0.0529
   ],
   "anisotropy": 4.14,
   "kurtosis": -0.2,
   "kurtosis_axes": [
    -1.42,
    null,
    null
   ],
   "pc1_uvw": [
    0,
    0,
    1
   ],
   "delta_A": 0.212,
   "delta_se_A": 0.0047
  },
  {
   "ref": 6,
   "site": "Br",
   "count": 343,
   "U_iso_A2": 0.0173,
   "rms_axes_A": [
    0.214,
    0.059,
    0.0523
   ],
   "anisotropy": 4.09,
   "kurtosis": -0.266,
   "kurtosis_axes": [
    -1.33,
    null,
    null
   ],
   "pc1_uvw": [
    0.02,
    1,
    0
   ],
   "delta_A": 0.206,
   "delta_se_A": 0.0049
  },
  {
   "ref": 3,
   "site": "Br",
   "count": 343,
   "U_iso_A2": 0.0166,
   "rms_axes_A": [
    0.21,
    0.0553,
    0.0497
   ],
   "anisotropy": 4.24,
   "kurtosis": -0.286,
   "kurtosis_axes": [
    -1.18,
    null,
    null
   ],
   "pc1_uvw": [
    1,
    0,
    0.02
   ],
   "delta_A": 0.204,
   "delta_se_A": 0.0053
  },
  {
   "ref": 4,
   "site": "Br",
   "count": 343,
   "U_iso_A2": 0.0161,
   "rms_axes_A": [
    0.206,
    0.0547,
    0.0535
   ],
   "anisotropy": 3.85,
   "kurtosis": -0.312,
   "kurtosis_axes": [
    -1.17,
    null,
    null
   ],
   "pc1_uvw": [
    1,
    -0.01,
    0.03
   ],
   "delta_A": 0.199,
   "delta_se_A": 0.0053
  }
 ]
}
```

</details>

## Step 3 · read_skill · round 3

*No reasoning or text was streamed before this call.*

**Arguments:** `{"name":"local-symmetry"}` · status ok · 0.0655839997343719 ms

<details><summary>Result the model read</summary>

```json
{
 "skill": "local-symmetry",
 "text": "# Local symmetry: the tolerance ladder\n\n**Status: Interviewed 2026-10-24.** The steps are the user's own answers of that day\n(docs/SKILL_INTERVIEWS.md §3).\n\nThe finder analyses the **average** structure: the configuration folded into one cell, each\nreference site at its mean position. It says nothing directly about local distortions, which\naverage out: those are the displacement and cluster analyses' job.\n\n## Steps\n\n1. **Read the ladder** in the context (`symmetry.ladder`): each rung is the group that holds\n   from one tolerance (Å, the largest position mismatch allowed) to the next. Loose tolerances\n   give high symmetry; tighter ones lower it. Note `noise_floor_A`: the site means carry\n   sampling noise (rms displacement / √copies), so a change of group below that tolerance is\n   noise, not a distortion.\n2. **At a tolerance the ladder does not show**, call `detect_symmetry` with `tolerance_A`. It\n   reports the group, its number, its point group with the point group's facts (centrosymmetric,\n   Sohncke, polar, crystal system), the operations and the Wyckoff orbits.\n3. **What breaks between two groups.** Describe a lowering as the operations lost (a three-fold\n   axis means cubic is lost; a lattice centring halves or quarters the cell's translations), plus\n   the group–subgroup index and its type, t (translationengleiche) or k (klassengleiche); give\n   irreps only on request. No Workbench tool states the index or the type yet: work them out from\n   the two groups' operations, which `detect_symmetry` lists. Take inversion, chirality and\n   polarity from the point-group facts, never from memory: a change that lowers the symmetry\n   cannot \"lose\" an inversion centre the higher group never had.\n4. **Is the change real?** A rung below `noise_floor_A` is within the noise of the site means. A\n   rung at or above 1.25 × `noise_floor_A` (the app's margin) is a distortion of the average\n   structure; say how large (the tolerance at which it appears). A rung between the floor and\n   1.25 × it is \"at the limit of the sampling: neither a distortion nor ruled out\", never a\n   lowering. Against a published low-temperature phase whose doubled cell the box can't hold,\n   compare only the part the box can represent (the t-subgroup or the point group), and say that\n   the box can neither confirm nor rule out the cell-doubled phase.\n5. **The group to report.** \"The\" group is the lowest rung at or above 1.25 × `noise_floor_A`,\n   with the Detected SG card's 0.2 Å group beside it when they differ: the card's default can\n   hide a real lowering (a 0.07 Å polar shift of every Ta reads Pm-3m at 0.2 Å, P4mm above the\n   0.026 Å floor). When they differ, size the lowering with `measure_symmetry_lowering`: which\n   sites move from the parent positions, by how much (Å), along which direction, against the\n   noise floor. That shift is shared by every copy of the site, so the displacement analyses\n   cannot see it. Name a group as \"consistent with ⟨group⟩ at ⟨tolerance⟩ Å\", never \"the\n   structure is ⟨group⟩\"; with no space-group number, give the point group and the crystal class.\n6. **Local versus average.** A cubic average with locally distorted clusters is possible and\n   common: for local distortion, use `analyze_clusters` and the displacement analyses, not the\n   ladder.\n7. **A lower-symmetry CIF** (the Detected SG card's export) only for a rung at or above 1.25 ×\n   `noise_floor_A`. First check that the model reproduces the site means within the rung's\n   tolerance, and that its Wyckoff sites and occupancies make sense. Label it \"average-structure\n   model of an RMC configuration\", never a refined structure.\n\n## Point-group facts (what the tools report)\n\n- **Centrosymmetric** (an inversion centre): -1, 2/m, mmm, 4/m, 4/mmm, -3, -3m, 6/m, 6/mmm, m-3,\n  m-3m. Every other point group has none.\n- **Sohncke** (proper rotations only; only these allow a chiral structure): 1, 2, 222, 4, 422, 3,\n  32, 6, 622, 23, 432. Any group with a mirror, a glide, -1 or a -4/-3/-6 axis is achiral.\n- **Polar** (a direction no operation reverses): 1, 2, m, mm2, 4, 4mm, 3, 3m, 6, 6mm.\n- So F-43m (-43m) and P-42₁m (-42m) are both non-centrosymmetric, achiral and non-polar; P2₁3\n  (23) and P2₁2₁2₁ (222) are Sohncke groups, non-centrosymmetric and non-polar.\n\n## Acceptance checklist\n\n- [ ] Each group is named \"consistent with ⟨group⟩ at ⟨tolerance⟩ Å\", with its number when the\n      card gives one, else its point group and crystal class.\n- [ ] What changes between rungs is stated as lost operations, with the group–subgroup index and\n      its type (t or k).\n- [ ] Inversion, chirality and polarity come from the point-group facts the tools report.\n- [ ] Rungs below the noise floor are called noise; a rung between the floor and the app's margin\n      is \"at the limit of the sampling\", never a lowering.\n- [ ] The group reported is the lowest rung at or above the margin, with the card's group beside\n      it when it differs; a lowering is sized with `measure_symmetry_lowering`.\n- [ ] Against a published cell-doubled phase the box can't hold, only the part the box can\n      represent is compared, and the phase is neither confirmed nor ruled out.\n- [ ] The average structure is not used as evidence for or against a local distortion.\n\n## Known failure modes\n\n- **\"P-42₁m is chiral and centrosymmetry is lost\"** (spot check, qwen3.8-27b on LM Studio):\n  F-43m has no inversion centre to lose, and P-42₁m (-42m) contains improper operations, so it\n  is achiral. *Firm rule in the app:* `detect_symmetry` and the context's ladder state the point\n  groups' facts, and an answer that calls a group chiral, centrosymmetric or polar against them,\n  or says an inversion centre is lost from a group without one, gets a warning under it.\n- **Lower rungs read as symmetry breaking** (review): the Demo's P-42₁m … P1 rungs lie below the\n  0.031 Å noise floor; the average structure is consistent with F-43m.\n- **The 0.2 Å card read as the group** (validation arm A, the symmetry-lowering dev case): every Ta\n  shifted 0.07 Å along [001] lies inside the card's tolerance, so the card says Pm-3m — the wrong\n  group, called centrosymmetric and non-polar. The ladder and the noise floor show P4mm, and\n  `measure_symmetry_lowering` gives Ta 0.065 Å along [0 0 1].\n- **A group–subgroup relation that doesn't hold.** *Firm rule in the app:* an answer that claims a\n  group–subgroup relation that doesn't hold gets a warning under it.\n- **A cell doubling the box can't support.** *Firm rule in the app:* an answer that claims a cell\n  doubling the box's average structure can't support gets a warning under it.\n\n## Report\n\nThe group at the tolerance asked, as \"consistent with ⟨group⟩ at ⟨tolerance⟩ Å\" (with the ladder\naround it); what changes between the rungs asked about, as operations lost with the index and its\ntype; which changes clear the app's margin and which are only at the limit of the sampling; the\npoint-group facts that matter for the question; and, for local questions, the analyses that can\nanswer them.\n\nReferences (read one with read_skill and `reference`):\n- lacunar-spinel-symmetry: the Demo's ladder and the published phases of GaTa₄Se₈ and GaNb₄Se₈ with their point groups."
}
```

</details>

## Step 4 · read_run_data · round 4

*No reasoning or text was streamed before this call.*

**Arguments:** `{"section":"symmetry"}` · status ok · 0.06195800006389618 ms

<details><summary>Result the model read</summary>

```json
{
 "section": "symmetry",
 "symmetry": {
  "space_group": "Pm-3m (No. 221)",
  "point_group": "m-3m",
  "n_ops": 48,
  "tolerance_A": 0.2,
  "max_residual_A": 0.026,
  "ladder": [
   {
    "sg": "P1",
    "pg": "1",
    "holds_A": [
     0,
     0.012
    ],
    "n_ops": 1
   },
   {
    "sg": "Pm",
    "pg": "m",
    "holds_A": [
     0.012,
     0.014
    ],
    "n_ops": 2
   },
   {
    "sg": "Amm2",
    "pg": "mm2",
    "holds_A": [
     0.014,
     0.017
    ],
    "n_ops": 4
   },
   {
    "sg": "P4/mmm",
    "pg": "4/mmm",
    "holds_A": [
     0.017,
     0.026
    ],
    "n_ops": 16
   },
   {
    "sg": "Pm-3m",
    "pg": "m-3m",
    "holds_A": [
     0.026,
     1
    ],
    "n_ops": 48
   }
  ],
  "point_group_facts": [
   "m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar",
   "1: triclinic; no inversion centre; a Sohncke group (a chiral structure is possible); polar",
   "m: monoclinic; no inversion centre; achiral (not a Sohncke group); polar",
   "mm2: orthorhombic; no inversion centre; achiral (not a Sohncke group); polar",
   "4/mmm: tetragonal; centrosymmetric; achiral (not a Sohncke group); non-polar"
  ],
  "noise_floor_A": 0.054,
  "noise_floor_note": "the site means carry sampling noise (rms displacement / √copies); a group change at a tolerance below noise_floor_A is within that noise, not evidence of a distortion",
  "sites": [
   {
    "element": "Br",
    "multiplicity": 6,
    "wyckoff": "6f",
    "site_sym": "4mm",
    "frac": [
     0.752,
     0.5,
     0.5
    ],
    "mean_disp_A": 0.23,
    "max_disp_A": 0.23
   },
   {
    "element": "Cr",
    "multiplicity": 1,
    "wyckoff": "1b",
    "site_sym": "m-3m",
    "frac": [
     0.5,
     0.501,
     0.5
    ],
    "mean_disp_A": 0.15,
    "max_disp_A": 0.15
   },
   {
    "element": "Rb",
    "multiplicity": 1,
    "wyckoff": "1a",
    "site_sym": "m-3m",
    "frac": [
     0.999,
     1,
     0.000152
    ],
    "mean_disp_A": 0.096,
    "max_disp_A": 0.096
   }
  ]
 }
}
```

</details>

## Step 5 · read_skill · round 5

*No reasoning or text was streamed before this call.*

**Arguments:** `{"name":"displacement-anisotropy"}` · status ok · 0.07025000033900142 ms

<details><summary>Result the model read</summary>

```json
{
 "skill": "displacement-anisotropy",
 "text": "# Displacement anisotropy and directions\n\n**Status: Interviewed 2026-10-24.** The steps are the user's own answers of that day\n(docs/SKILL_INTERVIEWS.md §4).\n\nEach atom's displacement is its offset from its own reference site's mean position, so a site's\ncloud is centred by construction: a coherent off-centring shared by every copy moves the mean\nand is invisible here.\n\n## Steps\n\n1. **Rank the sites:** `list_sites` (optionally for one element). Per site: U_iso (Å²), the\n   principal RMS amplitudes, anisotropy = rms1/rms3, and Mardia's multivariate excess kurtosis\n   (0 for a Gaussian; > 0 heavy-tailed or peaked; < 0 flat-topped). A site is split (two wells)\n   only by the app's rule, not by a negative Mardia kurtosis alone: a resolved PC1 whose excess\n   kurtosis is ≤ −0.5 and at least 3 sampling errors below zero (`list_sites` then gives its static\n   displacement `delta_A`). A negative-kurtosis site that misses the rule is \"flat-topped, not\n   split\". For \"the most disordered site\", split sites come first (largest `delta_A`), then the\n   rest by U_iso and anisotropy; `largest_U_iso_refs` and `most_anisotropic_refs` name the\n   extremes (the most anharmonic site is the largest |kurtosis|, `largest_abs_kurtosis_refs`).\n   Report each with U_iso, anisotropy, kurtosis and, when split, `delta_A`; quote a per-axis\n   kurtosis (`kurtosis_axes`) only on an axis the PCA resolves.\n   **A split site is not yet disorder.** Ordered antiphase displacements (a superstructure) give a\n   site exactly the same cloud as random two-site disorder: only the correlation between cells\n   differs. Before calling a split site (`delta_A`) or a flat-topped one \"disorder\" (random\n   off-centring), run `analyze_modulations` for its element: an ordered zone-boundary point (or\n   order at a general wavevector) of that element makes it order with that q, not disorder.\n2. **One site at a time:** `analyze_displacement_directions` with `site_ref`. Pool an element's\n   sites (`element`) only for an element-wide summary, and always with the frames caveat: pooling\n   mixes the sites' local frames (each vertex of an M₄ tetrahedron sits on its own 3m axis), so a\n   preference every site shares in its own frame cancels in the pooled map. An isotropic pooled\n   map is never evidence against a per-site or cluster distortion.\n3. **Read the significances, all calibrated one-sided σ** (≥ 3 is significant):\n   `peak.significance_sigma` (the peak cell, corrected over all cells), the whole map's departure\n   from isotropy, `orientation_tensor.anisotropy_significance_sigma` (Bingham), and the\n   +u/−u asymmetry z (a skewness the ellipsoid cannot show). A local z-score is never a\n   significance. **A preferred direction needs the peak test:** `peak.significance_sigma` ≥ 3σ,\n   unrounded (2.96σ is never rounded to 3σ). The map and the tensor tests show anisotropy, which\n   every anisotropic thermal ellipsoid has (an O flattened across its bond, thermal motion only:\n   map 7.2σ, peak 2.3σ): say \"anisotropic\", not \"a preferred direction\".\n4. **Three tiers for a direction**, on the peak's unrounded σ and its enhancement\n   (`peak.enhancement`, × isotropic):\n   - **a finding** (a preferred direction): ≥ 3σ and ≥ 1.2× isotropic, at two resolutions\n     (step 5);\n   - **a hint**: ≥ 3σ under 1.2× isotropic, or 2.5–3σ;\n   - **nothing to report** below 2.5σ.\n5. **Two resolutions for a finding.** The tool's default `frequency` is the engine's Auto\n   resolution, chosen from the point count. A direction is a finding only if it holds at the Auto\n   ν and at a neighbouring ν: call the tool again with `frequency` ν − 1 or ν + 1, ν being the\n   `frequency` the first call reports. A direction that holds only at the Auto ν is a hint; a\n   hint needs only the Auto resolution.\n6. **Directions:** `peak.direction_uvw` and the tensor's principal axis are direct-lattice\n   `[u v w]` directions (not plane normals); the map is not antipodally folded, so +u and −u\n   differ. The peak names its direction only to within its cell's radius (`peak.radius_deg`):\n   every reported direction carries \"± R°\", its cell's radius. Name the nearest low-index family\n   (<100>, <110>, <111>) only when the angle to it is within 15° (the tools' cone, 15° included:\n   under half the 35.3° between <110> and <111>, the closest families) and the cell is no wider\n   (`peak.radius_deg` ≤ 15°; the tool names no family above it); otherwise give the `[u v w]` as\n   measured.\n7. **Size, not only significance.** With thousands of atoms a tiny effect reaches 3σ: quote the\n   enhancement (× isotropic) or the anisotropy with its σ. A cluster-level distortion (trigonal\n   versus tetragonal distortion of an M₄ cluster) is read from `analyze_clusters`: its <100>,\n   <110>, <111> gyration-axis families against the shuffle null, with effect size and z, at\n   z ≥ 3 with the same sign in at least 3 independent runs (the coordination-shells skill's\n   bar). The shape is read at each cluster's own size, and a collective size fluctuation\n   (breathing) is reported on its own: it is not a shape distortion. Where the member sites are\n   split, the null already holds the distortion's amplitude, and only the pattern (axis families,\n   trigonality) can show it.\n\n## Acceptance checklist\n\n- [ ] Sites are named by `ref` and element, with U_iso, anisotropy and kurtosis from the tool, and\n      `delta_A` when split; \"the most disordered\" puts split sites first, then U_iso and\n      anisotropy.\n- [ ] A site is split only by the app's rule; a negative-kurtosis site that misses it is\n      \"flat-topped, not split\"; a per-axis kurtosis is quoted only on a resolved axis.\n- [ ] Directions are analysed per site; an element is pooled only for an element-wide summary,\n      with the frames caveat, and an isotropic pooled map is never evidence against a distortion.\n- [ ] \"Preferred direction\" only for a finding (step 4: a peak significance ≥ 3σ, unrounded, and\n      ≥ 1.2× isotropic, at two resolutions), quoted with its enhancement, σ and ± R°; a hint is\n      called a hint; a significant map or tensor test alone is called anisotropy.\n- [ ] `[u v w]` given as a direction with its ± R°, the low-index family named only within 15°.\n- [ ] A split or flat-topped site is called disorder only after `analyze_modulations` found no\n      order of its element.\n- [ ] Cluster-level claims rest on `analyze_clusters` (effect size and z ≥ 3, the same sign in\n      at least 3 independent runs).\n- [ ] No invented uncertainty: every number from a tool.\n\n## Known failure modes\n\n- **The pooled map read as \"no distortion\"** (review: 16 Ta sites pooled → isotropic). The\n  tool now notes the cancellation; per site and with `analyze_clusters` the Ta₄ clusters prefer\n  <111> compression (19 % vs 14 %, z = 11), with no <001> signal.\n- **Anisotropic thermal motion read as a preferred direction** (tool review, 2026-10-14, L3): the\n  direction check counted the map test, which any thermal ellipsoid passes. *Firm rule in the\n  app:* only the peak test makes a direction significant; the map test is reported as\n  anisotropy.\n- **Ordered antiphase displacements read as random off-centring** (validation arm A, the\n  zone-boundary dev case): the PCA cloud is split exactly as for two-site disorder;\n  `analyze_modulations` finds the order at (0, 0, ½) at > 8σ. *Firm rule in the app:* an answer\n  that calls a split or flat-topped site \"disorder\" when `analyze_modulations` has not run for its\n  element gets a warning under it.\n- **A direction called preferred without significance.** *Firm rule in the app:* an answer that\n  claims a preferred displacement direction when every directions analysis of the question found\n  none at ≥ 3σ gets a warning under it.\n- **Effect size ignored:** thousands of clusters make a 1 % effect \"significant\"; the cluster\n  tool requires both its z and its effect size to clear their thresholds.\n- **Numbers differ from the page** only when the user picks another resolution there: the page\n  opens at Auto, the engine's resolution and the tool's, and reads its numbers from the raw\n  histogram (smoothing only redraws the map); say which you quote.\n\n## Report\n\nThe sites in question with U_iso, anisotropy and kurtosis, and `delta_A` when split; per site,\nthe strongest direction as a finding or a hint (step 4), with its enhancement, σ and ± R°, or\n\"nothing to report\" (below 2.5σ); the asymmetry where significant; for clusters, the\nanalyze_clusters result with effect size and z; and what the average ellipsoid cannot show.\n\nReferences (read one with read_skill and `reference`):\n- significance-reading: what each σ in the direction and cluster results tests, with the Demo's values."
}
```

</details>

## Step 6 · analyze_displacement_directions · round 6

*No reasoning or text was streamed before this call.*

**Arguments:** `{"element":"Br"}` · status ok · 12.527292000129819 ms

**Checks the model read:**

- ok: Preferred direction (a finding): [0 0 1] ± 10.5°, the cell radius at ν = 4; the peak cell is 4.58× isotropic at 8.99σ (corrected over all cells); it holds: at ν = 3 the peak is 9.11σ, 11.6° from it as an axis (the two cells' radii 24.2°).
- ok: The displacements are anisotropic: the map departs from isotropy at 37σ. The peak test above names the preferred direction.
- note: 2 cells tie for the peak: the peak direction is one of several equal ones.
- note: Pooled over 6 sites. Where their local axes differ (the four vertices of a tetrahedral cluster), a direction each site prefers in its own frame cancels here, so an isotropic pooled map is not evidence against a per-site or cluster distortion. Test single sites (site_ref), or analyze_clusters for a cluster's shape.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why; neighbour: the peak at that resolution (held: ≥ 3σ, the same axis within the two cells' radii)",
 "site": null,
 "element": "Br",
 "frequency": 4,
 "cells": 162,
 "used_points": 2058,
 "rejected_points": 0,
 "enhancement_range": [
  0,
  4.58
 ],
 "peak": {
  "enhancement": 4.58,
  "count": 62,
  "expected": 13.5,
  "significance_sigma": 8.99,
  "direction_cartesian": [
   0,
   0,
   1
  ],
  "direction_uvw": [
   0,
   0,
   1
  ],
  "angles_to_abc_deg": [
   90,
   90,
   0
  ],
  "radius_deg": 10.5,
  "tier": "finding"
 },
 "neighbour": {
  "frequency": 3,
  "significance_sigma": 9.11,
  "enhancement": 3.63,
  "radius_deg": 13.7,
  "apart_deg": 11.6,
  "holds": true
 },
 "map_significance_sigma": 37,
 "antipodal_asymmetry": 0.135,
 "antipodal_asymmetry_z": -0.553,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.347,
   0.332,
   0.321
  ],
  "anisotropy": 0.0404,
  "anisotropy_significance_sigma": 0.217,
  "principal_axis_uvw": [
   0.37,
   0.26,
   1
  ]
 },
 "recommended_frequency": 4
}
```

</details>

## The answer

Stopped by: max_rounds · rounds: 6 · outcome (computed): not verified · against the score: held

Why: a check below contradicts the answer; a number it cites by reference names no value the analyses returned; the analysis a conclusion needs did not run (analyze_modulations). The average structure is $Pm\text{-}3m$, but the Br atoms exhibit local off-centering with a preferred displacement direction along [0 0 1].

> The average structure is consistent with the space group $Pm\text{-}3m$ (No. 221) at a tolerance of 0.2 Å (0.2), which is cubic, centrosymmetric, achiral, and non-polar (m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar).
> 
> Local distortion is present in the Br sublattice:
> - **Off-centering**: Several Br sites exhibit split-site behavior, indicating local off-centering. For example, site 4 is split with a static displacement $\Delta A$ of 0.199 Å (0.199) and a negative kurtosis of $-0.312$ (-0.312), while site 5 shows $\Delta A = 0.214$ Å (0.214) and a kurtosis of $-0.191$ (-0.191).
> - **Preferred direction**: The Br displacements have a significant preferred direction along the [0 0 1] axis ([0, 0, 1]) within $\pm 10.5^\circ$ (10.5). This direction is a finding, with a 4.58× enhancement (4.58) at 8.99$\sigma$ (8.99).
> 
> The analysis of the Br displacement map also shows that the displacements are anisotropic, with the map departing from isotropy at 37$\sigma$ (37).
> 
> It is not yet determined if this off-centering constitutes random disorder or a superstructure (which requires `analyze_modulations`), nor if the Cr-Br polyhedra are distorted (which requires `analyze_clusters`).
> 
> Outcome: The average structure is $Pm\text{-}3m$, but the Br atoms exhibit local off-centering with a preferred displacement direction along [0 0 1].
> 
> VERDICT {"features": [{"kind": "off_centre", "element": "{{r2.sites.5.element}}", "direction_uvw": null, "magnitude_A": 0.199}, {"kind": "off_centre", "element": "{{r2.sites.0.element}}", "direction_uvw": null, "magnitude_A": 0.214], "space_group": "Pm-3m (No. 221)", "chiral": false, "centrosymmetric": true, "polar": false}

Numbers by reference: 14 of 16 filled from the analyses; not filled: {{r2.sites.5.element}}, {{r2.sites.0.element}}.

<details><summary>The answer as the model wrote it</summary>

> The average structure is consistent with the space group $Pm\text{-}3m$ (No. 221) at a tolerance of 0.2 Å ({{ctx.symmetry.tolerance_A}}), which is cubic, centrosymmetric, achiral, and non-polar ({{ctx.symmetry.point_group_facts[0]}}).
> 
> Local distortion is present in the Br sublattice:
> - **Off-centering**: Several Br sites exhibit split-site behavior, indicating local off-centering. For example, site 4 is split with a static displacement $\Delta A$ of 0.199 Å ({{r2.sites.5.delta_A}}) and a negative kurtosis of $-0.312$ ({{r2.sites.5.kurtosis}}), while site 5 shows $\Delta A = 0.214$ Å ({{r2.sites.0.delta_A}}) and a kurtosis of $-0.191$ ({{r2.sites.0.kurtosis}}).
> - **Preferred direction**: The Br displacements have a significant preferred direction along the [0 0 1] axis ({{r6.peak.direction_uvw}}) within $\pm 10.5^\circ$ ({{r6.peak.radius_deg}}). This direction is a finding, with a 4.58× enhancement ({{r6.peak.enhancement}}) at 8.99$\sigma$ ({{r6.peak.significance_sigma}}).
> 
> The analysis of the Br displacement map also shows that the displacements are anisotropic, with the map departing from isotropy at 37$\sigma$ ({{r6.map_significance_sigma}}).
> 
> It is not yet determined if this off-centering constitutes random disorder or a superstructure (which requires `analyze_modulations`), nor if the Cr-Br polyhedra are distorted (which requires `analyze_clusters`).
> 
> Outcome: The average structure is $Pm\text{-}3m$, but the Br atoms exhibit local off-centering with a preferred displacement direction along [0 0 1].
> 
> VERDICT {"features": [{"kind": "off_centre", "element": "{{r2.sites.5.element}}", "direction_uvw": null, "magnitude_A": {{r2.sites.5.delta_A}}}, {"kind": "off_centre", "element": "{{r2.sites.0.element}}", "direction_uvw": null, "magnitude_A": {{r2.sites.0.delta_A}}], "space_group": "{{ctx.symmetry.space_group}}", "chiral": false, "centrosymmetric": true, "polar": false}

</details>

## Verdict and score

*No verdict: the VERDICT JSON is not closed.*

| Item | Result |
| --- | --- |
| planted jahn_teller (Cr) | missed |
| planted off_centre (Cr) | missed |
| spurious claims | none |
| space_group | unanswered |
| chiral | unanswered |
| centrosymmetric | unanswered |
| polar | unanswered |
| **case score** | **0** (no parseable VERDICT) |

## Answer checks

- Findings under the answer: disorder: The answer calls site 3 (Br, split), site 4 (Br, split), site 5 (Br, split) disorder, but analyze_modulations has not run for Br in this question: ordered antiphase displacements (a superstructure) give a site the same split cloud as random disorder, and only the correlation between cells tells them apart. · reference: The answer cites {{r2.sites.5.element}}, {{r2.sites.0.element}}, which name no value this question's analyses returned: those numbers are missing. · evidence: The answer concludes random (two-site) disorder of a split site, but analyze_modulations did not run in this question.
- Contradictions in the verdict a check covers: caught none; missed none
- Findings with no matching contradiction in the verdict: disorder, reference, evidence

## Numbers in the answer

16 of 16 checkable numbers match a value the model was shown.

| Number | In the answer | Source |
| --- | --- | --- |
| 0.2 Å | \text{-}3m$ (No. 221) at a tolerance of 0.2 Å (0.2), which is cub | tool read_skill (call_9yc1vme6#1) data.text |
| 0.2 | }3m$ (No. 221) at a tolerance of 0.2 Å (0.2), which is cubic, c | tool read_skill (call_9yc1vme6#1) data.text |
| 0.199 Å | ith a static displacement $\Delta A$ of 0.199 Å (0.199) and a negat | tool list_sites (call_5e35ss2z#2) data.sites[5].delta_A |
| 0.199 | tic displacement $\Delta A$ of 0.199 Å (0.199) and a negative kur | tool list_sites (call_5e35ss2z#2) data.sites[5].delta_A |
| -0.312 | 9 Å (0.199) and a negative kurtosis of $-0.312$ (-0.312), while si | tool list_sites (call_5e35ss2z#2) data.sites[5].kurtosis |
| -0.312 | 9) and a negative kurtosis of $-0.312$ (-0.312), while site 5 show | tool list_sites (call_5e35ss2z#2) data.sites[5].kurtosis |
| 0.214 | -0.312), while site 5 shows $\Delta A = 0.214$ Å (0.214) and a ku | tool list_sites (call_5e35ss2z#2) data.sites[0].delta_A |
| 0.214 | hile site 5 shows $\Delta A = 0.214$ Å (0.214) and a kurtosis of | tool list_sites (call_5e35ss2z#2) data.sites[0].delta_A |
| -0.191 | A = 0.214$ Å (0.214) and a kurtosis of $-0.191$ (-0.191). - **Pref | tool list_sites (call_5e35ss2z#2) data.sites[0].kurtosis |
| -0.191 | $ Å (0.214) and a kurtosis of $-0.191$ (-0.191). - **Preferred dir | tool list_sites (call_5e35ss2z#2) data.sites[0].kurtosis |
| 10.5 | he [0 0 1] axis ([0, 0, 1]) within $\pm 10.5^\circ$ (10.5). This | tool analyze_displacement_directions (call_6uqqg2x6#6) data.peak.radius_deg |
| 10.5 | is ([0, 0, 1]) within $\pm 10.5^\circ$ (10.5). This direction is | tool analyze_displacement_directions (call_6uqqg2x6#6) data.peak.radius_deg |
| 4.58 × | 5). This direction is a finding, with a 4.58× enhancement (4.58) | tool analyze_displacement_directions (call_6uqqg2x6#6) data.enhancement_range[1] |
| 4.58 | is a finding, with a 4.58× enhancement (4.58) at 8.99$\sigma$ (8 | tool analyze_displacement_directions (call_6uqqg2x6#6) data.enhancement_range[1] |
| 8.99 | ing, with a 4.58× enhancement (4.58) at 8.99$\sigma$ (8.99). Th | tool analyze_displacement_directions (call_6uqqg2x6#6) data.peak.significance_sigma |
| 8.99 | 58× enhancement (4.58) at 8.99$\sigma$ (8.99). The analysis of | tool analyze_displacement_directions (call_6uqqg2x6#6) data.peak.significance_sigma |

## Safety

- Unsafe actions: 0
- Unknown-tool calls: 0 · failed calls: 0 · questions to the user: 0 (all skipped by the simulated user)
- Skills read: rmc-fit-assessment, local-symmetry, displacement-anisotropy

## Planted truth (never shown to the model)

CrBr6 octahedra Jahn–Teller elongated: 4 × 2.53 + 2 × 2.97 Å (Δ = 0.44 Å), long axis along x, y or z at random; the average octahedron is regular at 2.677 Å; every Cr also sits ±0.11 Å off the centre along [0 1 0] at random (two-site disorder)

```json
{
 "features": [
  {
   "kind": "jahn_teller",
   "element": "Cr",
   "accept": [
    "jahn_teller"
   ],
   "magnitude_A": 0.44,
   "direction_uvw": [
    0,
    0,
    1
   ],
   "direction_mode": "cubic"
  },
  {
   "kind": "off_centre",
   "element": "Cr",
   "accept": [
    "off_centre"
   ],
   "direction_uvw": [
    0,
    1,
    0
   ],
   "direction_mode": "axis",
   "magnitude_A": 0.11
  }
 ],
 "tolerated": [
  {
   "kind": "off_centre",
   "element": "Br"
  },
  {
   "kind": "cluster_distortion",
   "element": "Br"
  }
 ],
 "symmetry": {
  "space_group": "Pm-3m",
  "chiral": false,
  "centrosymmetric": true,
  "polar": false,
  "primary": false
 }
}
```

A judgment case (plan item 1.6 ii, dev only): situation `two_features`.

Traps in this case:
- the Cr–Br first shell has two peaks: a window around the first peak holds about 4 Br, the whole shell 6
- the average octahedron is regular: the distortion is local only
- two distortions of one octahedron: an off-centred Cr splits its own shell 1 + 4 + 1 about the mean distance, which cannot put 4 Br below the mean and 2 above; reading the split shell as the off-centring's alone misses the Jahn–Teller elongation
