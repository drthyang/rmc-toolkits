# test-offcentre__B__gemma4:26b__r1

- Case: `test-offcentre` (test set) · Arm B: Copilot with skills and guardrails
- Model: gemma4:26b (Ollama) (`gemma4:26b`, temperature 0.2) · run 1
- Protocol 2026-10-24.6 · commit 7456af9dfe904c66b62dc900f39aa734a6c9c447 · 2026-10-25T00:39:51.648Z → 2026-10-25T00:41:12.195Z (81 s)
- Server: Ollama 0.40.2 · context window: num_ctx 40,960 (sized per request; the model holds 262,144)
- Reply cap: num_ctx minus the prompt estimate, per request · final round: no tools sent (the native API has no tool_choice)
- Temperature 0.2 (a request asked again after a loop: 0.6 or more) · limits: 6 rounds × 4 calls, 3600 s a turn, results 3,000 / turn 12,000 characters, 2 questions, 2 gate send-backs
- Context guard: refuses a request that would not fit, never cuts it (2.5 characters a token, 1.4 for tool JSON; 8,192-token reply reserve)
- Tools offered: read_run_data, find_gr_peaks, list_sites, analyze_displacement_directions, compute_bond_angles, polyhedral_distortion, analyze_clusters, analyze_modulations, detect_symmetry, measure_symmetry_lowering, ask_user, read_skill
- Skills offered: coordination-shells, displacement-anisotropy, local-order, local-symmetry, rmc-fit-assessment
- View: Detected SG at 0.2 Å with its ladder, nothing hidden, no PCA table, Live Data off
- Context sections: structure, symmetry, pair_correlations, datasets (absent: configuration_optimization, run_settings, pca_displacements, partial_weights, convergence) · one fresh question, no earlier turns

## Step 0 · the question

> Analyse the local structure of this RMC configuration. Is there order or distortion beyond the average structure (off-centred atoms, correlated clusters, a superstructure, distorted polyhedra)? What is the average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on the Workbench's analyses, and say so plainly if there is no such order.
> 
> Finish with one line that starts with VERDICT and holds a JSON object, after everything else (the Outcome line included):
> VERDICT {"features": [{"kind": "...", "element": "...", "direction_uvw": [u, v, w] or null, "magnitude_A": number or null, "q": [h, k, l] or null}], "space_group": "..." or null, "chiral": true/false/null, "centrosymmetric": true/false/null, "polar": true/false/null}
> kind is one of off_centre, modulation, cluster_distortion, cluster_breathing, rigid_cluster, jahn_teller, symmetry_lowering. features is [] when there is no order beyond thermal motion. direction_uvw is a crystal direction; magnitude_A the static displacement (off_centre, symmetry_lowering) or the long minus short bond (jahn_teller); q in reciprocal-lattice units. Use null for what you did not determine. A number may be a reference to a tool result, as in the answer ("magnitude_A": {{r3.sites.0.shift_A}}): the app fills it in; a text reference goes inside its quotes ("element": "{{r3.sites.0.element}}").

## Step 1 · read_skill · round 1

**Model reasoning before the call:**

> The user wants a comprehensive analysis of the local structure of the provided RMC configuration.
> I need to check for:
> 1.  **Off-centered atoms**: I'll use `list_sites` to see if any sites have large displacements or non-Gaussianity, then `analyze_displacement_directions` or `measure_symmetry_lowering`.
> 2.  **Correlated clusters**: I'll use `analyze_clusters` for potential clusters (dimers, trimers, etc.).
> 3.  **Superstructure**: I'll use `analyze_modulations` to look for order that enlarges the unit cell.
> 4.  **Distorted polyhedra**: I'll use `polyhedral_distortion` for polyhedra like $GeO_6$ or $SrO_{12}$.
> 5.  **Average structure symmetry**: I'll use `detect_symmetry` (though the context already provides the space group and its properties).
> 
> Plan:
> 1.  Check `list_sites` to identify candidates for off-centering or anisotropy.
> 2.  Check `detect_symmetry` to confirm the space group and its properties (though context says $Pm\text{-}3m$, centrosymmetric, achiral, non-polar).
> 3.  Check `analyze_clusters` for $Ge$ or $Sr$ if there's evidence of clustering.
> 4.  Check `polyhedral_distortion` for $GeO_6$ (since $Ge$ is $1b$ and $O$ is $3c$, $GeO_6$ is a likely candidate).
> 5.  Check `analyze_modulations` for superstructures.
> 
> Let's start by looking at the sites to see if any are particularly disordered.

**Arguments:** `{"name":"local-order"}` · status ok · 0.1742919999996957 ms

<details><summary>Result the model read</summary>

```json
{
 "skill": "local-order",
 "text": "# Local order: when to say \"no order\"\n\n**Status: Interviewed 2026-10-24.** The steps are the user's own answers of that day\n(docs/SKILL_INTERVIEWS.md §5).\n\nEach kind of local order hides from every analysis but one or two. The average structure folds the\nsupercell into one cell; each site's displacement cloud is centred on its own mean; an RMC\nconfiguration that the data did not shape looks like independent atoms. So one empty analysis\nsays nothing about the others: \"no order\" is the conclusion that every test the Workbench has came\nback empty. What was not run is \"not tested\", never \"absent\".\n\n## Steps\n\n1. **Sites:** `list_sites`. Note the split sites (two positions, by the app's rule: a resolved\n   PC1 whose excess kurtosis is ≤ −0.5 and at least 3 sampling errors below zero; `list_sites`\n   gives them a `delta_A`), the other sites with negative kurtosis (flat-topped), large positive\n   kurtosis (heavy tails, an anharmonic well) or large anisotropy.\n2. **Directions, per site:** `analyze_displacement_directions` with `site_ref` for every\n   symmetry-inequivalent site (one per orbit), not only those whose kurtosis or anisotropy stands\n   out; never pooled over sites whose local frames differ. Empty means no peak at ≥ 3σ. A\n   significant map or tensor test alone is anisotropy, which thermal ellipsoids have: it is not\n   order.\n3. **Order between cells:** `analyze_modulations` (every element). Empty means no zone-boundary\n   point and no general wavevector called ordered, and no diffuse short-range order: the diffuse\n   verdict, when it passes its calibrated bar, counts as order between cells. A long wave (every\n   |q_i| ≤ 0.25) is a box-scale correlation, not order. A split site whose element has an ordered\n   point is order with that q (a superstructure), not random disorder.\n4. **Clusters:** for every element whose own first shell is closed and holds 0.5–4.5 neighbours of\n   its own kind (`find_gr_peaks` on the A–A pair: a dimer 1, a trimer 2, a tetrahedron 3, an\n   octahedron 4 per member), `analyze_clusters` in its `first_shell.window_A`.\n   Empty means no shape distortion or pattern beyond independent atoms at the clusters' own size,\n   no breathing, no rigidity, and a regular average cluster. An extended network (the tool says\n   so) has no clusters to test: test its polyhedra with `polyhedral_distortion` (Baur's DI and\n   Robinson's indices, against the average structure's polyhedra).\n5. **Polyhedra:** `find_gr_peaks` for each bonded pair: the whole first shell's CN and peaks against\n   the average structure. A split shell the average structure does not explain is a distorted\n   polyhedron (coordination-shells); a split explained by a split centre site is that site's\n   disorder (step 1–3). A partial under 5 % of the signal is \"not constrained by the data\": say\n   so, and leave it out of the conclusion.\n6. **Average structure:** the context's ladder and noise floor. Empty means the group of the lowest\n   rung clearly above the noise floor (from 1.25 × `noise_floor_A`) is the card's group, or\n   `measure_symmetry_lowering` finds no site shifted above the noise floor (local-symmetry).\n7. **Conclude.** \"No order beyond thermal motion\" only when steps 2–6 all came back empty; name\n   each analysis and its result, and the partials left out as not constrained by the data. When a\n   test could not run (too few points per sphere cell, a zone-boundary point an odd supercell axis\n   cannot hold), say \"no order found in the tests that could run; ⟨test⟩ not tested because\n   ⟨reason⟩\": never a bare \"no order\". When one found order, report that order: the analysis, the\n   statistic, its effect size and σ.\n\n## Acceptance checklist\n\n- [ ] Every analysis of steps 2–6 ran, or the answer names what was not tested and why.\n- [ ] Directions for every symmetry-inequivalent site, not pooled; anisotropy not called order.\n- [ ] Split sites read against `analyze_modulations` before they are called disorder.\n- [ ] Clusters tested for every element with a finite same-element shell; an extended network's\n      polyhedra with `polyhedral_distortion`.\n- [ ] Order between cells at the zone boundary, at general wavevectors and in the diffuse\n      verdict; no long wave called order.\n- [ ] The average structure's group read above the noise floor.\n- [ ] A partial the data barely weight (step 5) reported as \"not constrained by the data\" and\n      left out of the conclusion.\n- [ ] Never a bare \"no order\": a test that could not run is named with its reason.\n- [ ] No literature expectation used as evidence either way.\n\n## Known failure modes\n\n- **The literature for the data** (validation, the thermal-null dev case): a perovskite whose\n  composition is known for off-centred B cations, thermal motion only in the configuration. The\n  answer is \"no order\"; its O ellipsoids are anisotropic (map 7.2σ, peak 2.3σ), which is not order.\n- **\"No order\" from the pages alone** (validation arm A, the breathing dev case): no page shows a\n  cluster's breathing; `analyze_clusters` finds it at z = 22.\n- **Order called disorder** (validation arm A, the zone-boundary dev case): ordered antiphase Ti\n  displacements give the same split cloud as random off-centring; only `analyze_modulations` tells\n  them apart.\n- *Firm rule in the app:* an answer that claims a superstructure, a cluster distortion, breathing,\n  rigidity or a preferred direction that the question's analyses did not find gets a warning under\n  it; and an answer that concludes \"no order\" before the superstructure test, a per-site direction\n  map and the cluster analyses ran is sent back to run them (the evidence gate, THY-18).\n- **\"No order\" before the whole list ran.** *Firm rule in the app:* an answer that concludes \"no\n  order\" is refused until every applicable analysis of steps 2–6 has run, the diffuse verdict and\n  `polyhedral_distortion` included (the evidence gate, extended).\n\n## Report\n\nEach analysis with its result (statistic, effect size, σ); the order found, or \"none at ≥ 3σ\";\nwhat was not tested and why (\"⟨test⟩ not tested because ⟨reason⟩\"); the partials not constrained\nby the data; the average structure's group above the noise floor.\n\nReferences (read one with read_skill and `reference`):\n- order-signatures: how each kind of order shows, and hides, in each analysis, with the dev cases' numbers."
}
```

</details>

## Step 2 · list_sites · round 2

**Model reasoning before the call:**

> The user wants to know if there is any local order or distortion in the RMC configuration.
> Following the `local-order` skill:
> 1.  **Sites**: I need to check `list_sites` for any split sites, high kurtosis, or high anisotropy.
> 2.  **Directions**: I need to run `analyze_displacement_directions` for every symmetry-inequivalent site.
> 3.  **Order between cells**: I need to run `analyze_modulations` for every element.
> 4.  **Clusters**: I need to check `pair_correlations` to see if any element has a finite same-element shell (0.5-4.5 neighbors).
>     - Sr-Sr: CN ~ 6 (not a cluster)
>     - Ge-Ge: CN ~ 6 (not a cluster)
>     - O-O: CN ~ 8 (not a cluster)
>     - Wait, the skill says "0.5-4.5 neighbours". Let's check the CNs.
>     - Sr-Sr: 5.99
>     - Ge-Ge: 6
>     - O-O: 7.99
>     - None of these are clusters. They are extended networks.
> 5.  **Polyhedra**: Since they are extended networks, I should use `polyhedral_distortion` for the polyhedra.
>     - I need to find the first shell windows for the polyhedra.
>     - Ge-O: CN 6 (octahedra). I'll use `polyhedral_distortion` for Ge-O.
>     - Sr-O: CN 12 (cuboctahedron).
>     - Sr-Ge: CN 8 (cube).
>     - I'll start with `find_gr_peaks` for Ge-O to get the window.
> 6.  **Average structure**: I need to check the symmetry ladder and noise floor. The context already provides the ladder and noise floor. I'll check if any group change is above the noise floor.
> 7.  **Symmetry lowering**: I'll run `measure_symmetry_lowering` to see if any site is shifted above the noise floor.
> 
> Plan:
> 1.  `list_sites` to identify interesting sites.
> 2.  `analyze_displacement_directions` for each site.
> 3.  `analyze_modulations` for all elements.
> 4.  `find_gr_peaks` for Ge-O to get the window for `polyhedral_distortion`.
> 5.  `polyhedral_distortion` for Ge-CN=6.
> 6.  `measure_symmetry_lowering` to check for coherent shifts.
> 
> Let's start with `list_sites`.

**Arguments:** `{"element":"all"}` · status failed (error) · 0.022791999999753898 ms

**Error:** element must be one of "Ge", "O", "Sr", got "all"

## Step 3 · list_sites · round 3

*No reasoning or text was streamed before this call.*

**Arguments:** `{"element":"Ge"}` · status ok · 8.2467080000024 ms

**Checks the model read:**

- note: Split: site 2 (Ge) has two positions along PC1 (PC1 excess kurtosis ≤ −0.5, at least 3 sampling errors below 0); delta_A is the static displacement, along pc1_uvw.
- ok: 1 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; pc1_uvw = PC1 as a direct-lattice direction [u v w] (not a plane normal), where PC1 is resolved; delta_A = static displacement along PC1 of a split site (two positions: PC1 excess kurtosis ≤ −0.5 and 3 sampling errors below 0), sqrt(rms1² − rms⊥²) with rms⊥² = (rms2² + rms3²)/2: ±delta_A for two equally occupied positions, their RMS otherwise; delta_se_A = its sampling error; split sites first (largest delta_A first), then by |kurtosis|, largest first",
 "element": "Ge",
 "n_sites": 1,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  2
 ],
 "largest_abs_kurtosis_refs": [
  2
 ],
 "most_anisotropic_refs": [
  2
 ],
 "sites": [
  {
   "ref": 2,
   "site": "Ge",
   "count": 512,
   "U_iso_A2": 0.0126,
   "rms_axes_A": [
    0.174,
    0.0632,
    0.0597
   ],
   "anisotropy": 2.92,
   "kurtosis": -0.329,
   "kurtosis_axes": [
    -1.53,
    null,
    null
   ],
   "pc1_uvw": [
    1,
    0.92,
    -0.01
   ],
   "delta_A": 0.163,
   "delta_se_A": 0.0029
  }
 ]
}
```

</details>

## Step 4 · list_sites · round 4

*No reasoning or text was streamed before this call.*

**Arguments:** `{"element":"O"}` · status ok · 0.6190419999984442 ms

**Checks the model read:**

- ok: 3 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; sites sorted by |kurtosis|, largest first",
 "element": "O",
 "n_sites": 3,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  4,
  3,
  5
 ],
 "largest_abs_kurtosis_refs": [
  5,
  4,
  3
 ],
 "most_anisotropic_refs": [
  3,
  4,
  5
 ],
 "sites": [
  {
   "ref": 5,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00632,
   "rms_axes_A": [
    0.0929,
    0.0877,
    0.0515
   ],
   "anisotropy": 1.8,
   "kurtosis": -0.229,
   "kurtosis_axes": [
    null,
    null,
    -0.253
   ]
  },
  {
   "ref": 4,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00699,
   "rms_axes_A": [
    0.0978,
    0.0948,
    0.0493
   ],
   "anisotropy": 1.99,
   "kurtosis": 0.103,
   "kurtosis_axes": [
    null,
    null,
    0.25
   ]
  },
  {
   "ref": 3,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00638,
   "rms_axes_A": [
    0.0938,
    0.0903,
    0.0468
   ],
   "anisotropy": 2,
   "kurtosis": 0.0424,
   "kurtosis_axes": [
    null,
    null,
    0.239
   ]
  }
 ]
}
```

</details>

## Step 5 · list_sites · round 5

*No reasoning or text was streamed before this call.*

**Arguments:** `{"element":"Sr"}` · status ok · 0.4912079999994603 ms

**Checks the model read:**

- ok: 1 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); anisotropy = rms1/rms3; sites sorted by |kurtosis|, largest first",
 "element": "Sr",
 "n_sites": 1,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  1
 ],
 "largest_abs_kurtosis_refs": [
  1
 ],
 "most_anisotropic_refs": [
  1
 ],
 "sites": [
  {
   "ref": 1,
   "site": "Sr",
   "count": 512,
   "U_iso_A2": 0.00635,
   "rms_axes_A": [
    0.0832,
    0.0794,
    0.0763
   ],
   "anisotropy": 1.09,
   "kurtosis": -0.0958
  }
 ]
}
```

</details>

## Step 6 · analyze_displacement_directions · round 6

*No reasoning or text was streamed before this call.*

**Arguments:** `{"site_ref":2}` · status ok · 13.134125000000495 ms

**Checks the model read:**

- ok: Preferred direction (a finding): the peak cell is 5.56× isotropic at 10.1σ (corrected over all cells), toward [-0.62 -1 0] ± 19.3°, the cell radius at ν = 2; it holds: at ν = 1 the peak is 13.8σ, 0° from it as an axis (the two cells' radii 56.7°). The direction is not resolved finer than 19.3° (over 15°), so it names no <100>, <110> or <111> family.
- ok: The displacements are anisotropic: the map departs from isotropy at 30.9σ. The peak test above places the preferred direction only to within its cell.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why; neighbour: the peak at that resolution (held: ≥ 3σ, the same axis within the two cells' radii)",
 "site": 2,
 "element": "Ge",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0,
  5.56
 ],
 "peak": {
  "enhancement": 5.56,
  "count": 62,
  "expected": 11.2,
  "significance_sigma": 10.1,
  "direction_cartesian": [
   -0.526,
   -0.851,
   0
  ],
  "direction_uvw": [
   -0.62,
   -1,
   0
  ],
  "angles_to_abc_deg": [
   121.7,
   148.3,
   90
  ],
  "radius_deg": 19.3,
  "tier": "finding"
 },
 "neighbour": {
  "frequency": 1,
  "significance_sigma": 13.8,
  "enhancement": 3.82,
  "radius_deg": 37.4,
  "apart_deg": 0,
  "holds": true
 },
 "map_significance_sigma": 30.9,
 "antipodal_asymmetry": 0.0977,
 "antipodal_asymmetry_z": -1.03,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.761,
   0.123,
   0.116
  ],
  "anisotropy": 1.28,
  "anisotropy_significance_sigma": 32.1,
  "principal_axis_uvw": [
   1,
   0.93,
   0
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## The answer

Stopped by: max_rounds · rounds: 6 · outcome (computed): not verified · against the score: under

Why: the analysis a conclusion needs did not run (analyze_modulations). The Ge site is off-centered with a significant preferred displacement direction, while the average structure is a centrosymmetric, non-polar cubic group.

> The analysis of the local structure reveals evidence of off-centered atoms, specifically for Germanium. The Ge site is split, with a static displacement of 0.163 Å (0.163) along the direction [1, 0.92, -0.01] ([1, 0.92, -0.01]). This displacement is not random; the displacement cloud has a significant preferred direction toward [-0.62, -1, 0] ([-0.62, -1, 0]) at a significance of 10.1σ (10.1), and the overall displacement map is anisotropic at 30.9σ (30.9). No split sites were identified for Oxygen (-0.229 to 0.0424) or Strontium (-0.0958).
> 
> The average structure belongs to the space group $Pm\text{-}3m$ (No. 221), which is cubic, centrosymmetric, achiral, and non-polar (context).
> 
> Tests for other types of local order, including correlated clusters ({{analyze_clusters}}), superstructures/modulations ({{analyze_modulations}}), and polyhedral distortions ({{polyhedral_distortion}}), were not performed.
> 
> Outcome: The Ge site is off-centered with a significant preferred displacement direction, while the average structure is a centrosymmetric, non-polar cubic group.
> 
> VERDICT {"features": [{"kind": "off_centre", "element": "Ge", "direction_uvw": [1, 0.92, -0.01], "magnitude_A": 0.163}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}

Numbers by reference: 8 of 8 filled from the analyses.

<details><summary>The answer as the model wrote it</summary>

> The analysis of the local structure reveals evidence of off-centered atoms, specifically for Germanium. The Ge site is split, with a static displacement of 0.163 Å ({{r2.sites.0.delta_A}}) along the direction [1, 0.92, -0.01] ({{r2.sites.0.pc1_uvw}}). This displacement is not random; the displacement cloud has a significant preferred direction toward [-0.62, -1, 0] ({{r5.peak.direction_uvw}}) at a significance of 10.1σ ({{r5.peak.significance_sigma}}), and the overall displacement map is anisotropic at 30.9σ ({{r5.map_significance_sigma}}). No split sites were identified for Oxygen ({{r3.sites.0.kurtosis}} to {{r3.sites.2.kurtosis}}) or Strontium ({{r4.sites.0.kurtosis}}).
> 
> The average structure belongs to the space group $Pm\text{-}3m$ (No. 221), which is cubic, centrosymmetric, achiral, and non-polar (context).
> 
> Tests for other types of local order, including correlated clusters ({{analyze_clusters}}), superstructures/modulations ({{analyze_modulations}}), and polyhedral distortions ({{polyhedral_distortion}}), were not performed.
> 
> Outcome: The Ge site is off-centered with a significant preferred displacement direction, while the average structure is a centrosymmetric, non-polar cubic group.
> 
> VERDICT {"features": [{"kind": "off_centre", "element": "Ge", "direction_uvw": [1, 0.92, -0.01], "magnitude_A": 0.163}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}

</details>

## Verdict and score

```json
{
 "features": [
  {
   "kind": "off_centre",
   "element": "Ge",
   "direction_uvw": [
    1,
    0.92,
    -0.01
   ],
   "magnitude_A": 0.163
  }
 ],
 "space_group": "Pm-3m",
 "chiral": false,
 "centrosymmetric": true,
 "polar": false
}
```

| Item | Result |
| --- | --- |
| planted off_centre (Ge) | found; direction off by 2.4°; magnitude 0.163 ok |
| spurious claims | none |
| space_group | right |
| chiral | right |
| centrosymmetric | right |
| polar | right |
| **case score** | **1**  |

## Answer checks

- Findings under the answer: evidence: The answer concludes random (two-site) disorder of a split site, but analyze_modulations did not run in this question.
- Contradictions in the verdict a check covers: caught none; missed none
- Findings with no matching contradiction in the verdict: evidence

## Numbers in the answer

15 of 15 checkable numbers match a value the model was shown.

| Number | In the answer | Source |
| --- | --- | --- |
| 0.163 Å | is split, with a static displacement of 0.163 Å (0.163) along the d | tool list_sites (call_kyczzlfh#3) data.sites[0].delta_A |
| 0.163 | with a static displacement of 0.163 Å (0.163) along the directio | tool list_sites (call_kyczzlfh#3) data.sites[0].delta_A |
| 0.92 | 0.163 Å (0.163) along the direction [1, 0.92, -0.01] ([1, 0.92, | tool list_sites (call_kyczzlfh#3) data.sites[0].pc1_uvw[1] |
| -0.01 | Å (0.163) along the direction [1, 0.92, -0.01] ([1, 0.92, -0.01]) | tool list_sites (call_kyczzlfh#3) data.sites[0].U_iso_A2 |
| 0.92 | ong the direction [1, 0.92, -0.01] ([1, 0.92, -0.01]). This disp | tool list_sites (call_kyczzlfh#3) data.sites[0].pc1_uvw[1] |
| -0.01 | e direction [1, 0.92, -0.01] ([1, 0.92, -0.01]). This displacemen | tool list_sites (call_kyczzlfh#3) data.sites[0].U_iso_A2 |
| -0.62 | significant preferred direction toward [-0.62, -1, 0] ([-0.62, -1 | tool analyze_displacement_directions (call_t3hgg0cw#6) data.peak.direction_uvw[0] |
| -0.62 | erred direction toward [-0.62, -1, 0] ([-0.62, -1, 0]) at a signi | tool analyze_displacement_directions (call_t3hgg0cw#6) data.peak.direction_uvw[0] |
| 10.1 σ | ] ([-0.62, -1, 0]) at a significance of 10.1σ (10.1), and the ove | tool analyze_displacement_directions (call_t3hgg0cw#6) data.peak.significance_sigma |
| 10.1 | 62, -1, 0]) at a significance of 10.1σ (10.1), and the overall d | tool analyze_displacement_directions (call_t3hgg0cw#6) data.peak.significance_sigma |
| 30.9 σ | rall displacement map is anisotropic at 30.9σ (30.9). No split si | tool analyze_displacement_directions (call_t3hgg0cw#6) data.map_significance_sigma |
| 30.9 | splacement map is anisotropic at 30.9σ (30.9). No split sites we | tool analyze_displacement_directions (call_t3hgg0cw#6) data.map_significance_sigma |
| -0.229 | split sites were identified for Oxygen (-0.229 to 0.0424) or Stron | tool list_sites (call_jtbdw434#4) data.sites[0].kurtosis |
| 0.0424 | s were identified for Oxygen (-0.229 to 0.0424) or Strontium (-0.0 | tool list_sites (call_jtbdw434#4) data.sites[2].kurtosis |
| -0.0958 | Oxygen (-0.229 to 0.0424) or Strontium (-0.0958). The average stru | tool list_sites (call_mo4mtryu#5) data.sites[0].kurtosis |

## Safety

- Unsafe actions: 0
- Unknown-tool calls: 0 · failed calls: 1 · questions to the user: 0 (all skipped by the simulated user)
- Skills read: local-order

## Planted truth (never shown to the model)

Ge off-centred ±0.16 Å along [1 1 0] at random (two-site disorder); the average structure stays cubic

```json
{
 "features": [
  {
   "kind": "off_centre",
   "element": "Ge",
   "accept": [
    "off_centre"
   ],
   "direction_uvw": [
    1,
    1,
    0
   ],
   "direction_mode": "axis",
   "magnitude_A": 0.16
  }
 ],
 "tolerated": [],
 "symmetry": {
  "space_group": "Pm-3m",
  "chiral": false,
  "centrosymmetric": true,
  "polar": false,
  "primary": false
 }
}
```

Traps in this case:
- the Ge ellipsoid alone cannot tell a split site from large thermal motion: read the kurtosis and the direction map
