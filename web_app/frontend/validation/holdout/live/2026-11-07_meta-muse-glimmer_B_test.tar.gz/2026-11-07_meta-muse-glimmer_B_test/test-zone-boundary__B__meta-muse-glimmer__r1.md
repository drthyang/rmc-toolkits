# test-zone-boundary__B__meta/muse-glimmer__r1

- Case: `test-zone-boundary` (test set) · Arm B: Copilot with skills and guardrails
- Model: meta/muse-glimmer (LM Studio; 28B, tool use, up to 128k context) (`meta/muse-glimmer`, temperature 0.2) · run 1
- Protocol 2026-11-01.1 · commit 472d9bdab1cabb1152a6f49691b55d1d49eb0ffe · 2026-11-07T09:54:59.066Z → 2026-11-07T10:04:02.525Z (543 s)
- Server: LM Studio · context window: 49,152 loaded (minimum 49,152)
- Reply cap: none sent; the guard needs 4,096 tokens of room beyond the prompt · final round: tool_choice "none", tools still sent
- Temperature 0.2 (a request asked again after a loop: 0.6 or more) · limits: 6 rounds × 4 calls, 600 s a turn, results 3,000 / turn 12,000 characters, 2 questions, 2 gate send-backs
- Context guard: refuses a request that would not fit, never cuts it (2.5 characters a token, 1.4 for tool JSON; 8,192-token reply reserve)
- Tools offered: read_run_data, find_gr_peaks, list_sites, analyze_displacement_directions, compute_bond_angles, polyhedral_distortion, analyze_clusters, analyze_modulations, detect_symmetry, measure_symmetry_lowering, ask_user, read_skill
- Skills offered: coordination-shells, displacement-anisotropy, local-order, local-symmetry, rmc-fit-assessment
- View: Detected SG at 0.2 Å with its ladder, nothing hidden, no PCA table, Live Data off
- Context sections: structure, symmetry, pair_correlations, datasets (absent: configuration_optimization, run_settings, pca_displacements, partial_weights, convergence) · one fresh question, no earlier turns

## Step 0 · the question

> Analyse the local structure of this RMC configuration. Is there order or distortion beyond the average structure (off-centred atoms, correlated clusters, a superstructure, distorted polyhedra)? What is the average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on the Workbench's analyses, and say so plainly if there is no such order.
> 
> Finish with one line that starts with VERDICT and holds a JSON object, after everything else (the Outcome line included):
> VERDICT {"features": [{"kind": "...", "element": "...", "direction_uvw": [u, v, w] or null, "magnitude_A": number or null, "q": [h, k, l] or null}], "space_group": "..." or null, "chiral": true/false/null, "centrosymmetric": true/false/null, "polar": true/false/null}
> kind is one of off_centre, modulation, cluster_distortion, cluster_breathing, rigid_cluster, jahn_teller, symmetry_lowering. features is [] when there is no order beyond thermal motion. direction_uvw is a crystal direction; magnitude_A the static displacement (off_centre, symmetry_lowering) or the long minus short bond (jahn_teller); q in reciprocal-lattice units. Use null for what you did not determine. A number may be a reference to a tool result, as in the answer ("magnitude_A": {{r3.sites.0.shift_A}}): the app fills it in; a text reference goes inside its quotes ("element": "{{r3.sites.0.element}}").

## Step 1 · list_sites · round 1

**Model reasoning before the call:**

> Analyse local structure of this RMC configuration. Is there order or distortion beyond average structure (off-centred atoms, correlated clusters, superstructure, distorted polyhedra)? What is average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on Workbench's analyses, and say so plainly if there is no such order.
> 
> Finish with one line that starts with VERDICT and holds JSON object.
> 
> We need to analyze local structure. Context gives symmetry ladder: Pm-3m holds at tolerance >=0.013 Å. Ladder: P1 holds 0-0.0053, Pm 0.0053-0.0092, Amm2 0.0092-0.013, Pm-3m 0.013-1. Noise floor 0.03 Å. So symmetry changes at tolerances below noise floor? Noise floor 0.03 Å. The ladder holds up to 0.013 for Pm-3m. The noise floor is 0.03, so the group change at 0.013 is below noise floor? Actually noise floor is 0.03, so tolerance below 0.03 is within noise. The ladder shows Pm-3m holds from 0.013 upwards. The changes at 0.0092-0.013 etc are below noise floor? 0.013 <0.03, so yes below noise floor. So the symmetry lowering is within sampling noise, not evidence of distortion.
> 
> Sites: Ca mean_disp 0.16, O 0.14, Zr 0.13. Displacements moderate.
> 
> Pair correlations: first shells mean_d matches avg_structure_d, CN ~6,8,12 etc. No split peaks mentioned. gr_peaks fwhm ~0.27 etc.
> 
> We need to check for order beyond average. Need to run analyses: displacement directions, clusters, modulations, polyhedral distortion, symmetry lowering.
> 
> We have context but need analyses to confirm no order. The instruction says base every claim on Workbench's analyses. So we must run tools.
> 
> First, assess fit? Might be needed but question is local structure.
> 
> We need to check for off-centre atoms: analyze_displacement_directions per site. Need site_ref. We have sites: Ca 1a, O 3c, Zr 1b. Need reference numbers. Could list_sites to get refs.
> 
> Let's list sites.

**Arguments:** `{}` · status ok · 6.339458999922499 ms

**Checks the model read:**

- note: Split: site 2 (Zr) has two positions along PC1 (PC1 excess kurtosis ≤ −0.5, at least 3 sampling errors below 0); delta_A is the static displacement, along pc1_uvw.
- ok: 5 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; pc1_uvw = PC1 as a direct-lattice direction [u v w] (not a plane normal), where PC1 is resolved; delta_A = static displacement along PC1 of a split site (two positions: PC1 excess kurtosis ≤ −0.5 and 3 sampling errors below 0), sqrt(rms1² − rms⊥²) with rms⊥² = (rms2² + rms3²)/2: ±delta_A for two equally occupied positions, their RMS otherwise; delta_se_A = its sampling error; split sites first (largest delta_A first), then by |kurtosis|, largest first",
 "n_sites": 5,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  1,
  3,
  5
 ],
 "largest_abs_kurtosis_refs": [
  2,
  1,
  4
 ],
 "most_anisotropic_refs": [
  3,
  2,
  4
 ],
 "sites": [
  {
   "ref": 2,
   "site": "Zr",
   "count": 512,
   "U_iso_A2": 0.00605,
   "rms_axes_A": [
    0.105,
    0.0621,
    0.0578
   ],
   "anisotropy": 1.81,
   "kurtosis": -0.15,
   "kurtosis_axes": [
    -0.906,
    null,
    null
   ],
   "pc1_uvw": [
    1,
    0.03,
    -0.02
   ],
   "delta_A": 0.0857,
   "delta_se_A": 0.0031
  },
  {
   "ref": 1,
   "site": "Ca",
   "count": 512,
   "U_iso_A2": 0.00864,
   "rms_axes_A": [
    0.112,
    0.0835,
    0.0805
   ],
   "anisotropy": 1.39,
   "kurtosis": -0.137,
   "kurtosis_axes": [
    -0.466,
    null,
    null
   ],
   "pc1_uvw": [
    0.15,
    0.07,
    1
   ]
  },
  {
   "ref": 4,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00598,
   "rms_axes_A": [
    0.089,
    0.0867,
    0.05
   ],
   "anisotropy": 1.78,
   "kurtosis": 0.0161,
   "kurtosis_axes": [
    null,
    null,
    -0.0204
   ]
  },
  {
   "ref": 3,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00649,
   "rms_axes_A": [
    0.0925,
    0.0919,
    0.0495
   ],
   "anisotropy": 1.87,
   "kurtosis": -0.0152,
   "kurtosis_axes": [
    null,
    null,
    -0.354
   ]
  },
  {
   "ref": 5,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00625,
   "rms_axes_A": [
    0.0909,
    0.0877,
    0.0527
   ],
   "anisotropy": 1.72,
   "kurtosis": -0.00911,
   "kurtosis_axes": [
    null,
    null,
    -0.135
   ]
  }
 ]
}
```

</details>

## Step 2 · analyze_displacement_directions · round 2

**Model reasoning before the call:**

> Analyse the local structure of this RMC configuration. Is there order or distortion beyond the average structure (off-centred atoms, correlated clusters, a superstructure, distorted polyhedra)? What is the average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on the Workbench's analyses, and say so plainly if there is no such order.
> 
> We have context. Need to analyse local structure. Use tools. We have list_sites result. It shows Zr site ref2 has split site? Note says Split: site 2 (Zr) has two positions along PC1 (PC1 excess kurtosis ≤ -0.5, at least 3 sampling errors below 0); delta_A is static displacement, along pc1_uvw. Data: ref2 site Zr count 512, U_iso 0.00605, rms_axes [0.105,0.0621,0.0578], anisotropy 1.81, kurtosis -0.15, kurtosis_axes [-0.906,null,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0857, delta_se_A 0.0031.
> 
> So Zr has split site with static displacement 0.0857 Å along [1,0.03,-0.02] ~ [100]. That's off-centre? Split site.
> 
> Also Ca ref1: U_iso 0.00864, rms_axes [0.112,0.0835,0.0805], anisotropy 1.39, kurtosis -0.137, kurtosis_axes [-0.466,null,null], pc1_uvw [0.15,0.07,1] ~ [001]. No delta.
> 
> O sites have anisotropy ~1.7-1.9.
> 
> We need to check for order beyond average structure: off-centred atoms, correlated clusters, superstructure, distorted polyhedra.
> 
> We have symmetry ladder: P1 holds 0-0.0053, Pm holds 0.0053-0.0092, Amm2 holds 0.0092-0.013, Pm-3m holds 0.013-1. Noise floor 0.03 Å. So symmetry changes at tolerances below noise floor. The max residual 0.013. So average structure is Pm-3m at tolerance 0.2. The ladder shows that at tolerance ~0.013 it becomes Pm-3m. Noise floor is 0.03, so changes below 0.03 are within noise. The first change from Pm-3m to Amm2 is at 0.013, which is below noise floor 0.03. So no real symmetry lowering? Wait ladder holds_A intervals: Pm-3m holds_A [0.013,1]. So at tolerance 0.013 it holds. The next lower is Amm2 holds [0.0092,0.013]. So the tolerance where higher symmetry first holds is 0.013. That's below noise floor 0.03. So the distortion is within noise? Actually noise floor is 0.03, so tolerance below 0.03 is noise. So the symmetry lowering to Amm2 at 0.0092-0.013 is below noise floor, so not significant. So average structure is Pm-3m.
> 
> Space group Pm-3m No.221. Point group m-3m. From context point_group_facts: m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar.
> 
> We need to check for off-centre atoms: Zr split site with delta_A 0.0857 Å. That's s
> … [836 more characters in the JSON record]

**Arguments:** `{"site_ref":2}` · status ok · 6.090666999923997 ms

**Checks the model read:**

- ok: Preferred direction (a finding): the peak cell is 2.96× isotropic at 4.48σ (corrected over all cells), toward [1 0 0.62] ± 19.3°, the cell radius at ν = 2; it holds: at ν = 1 the peak is 4.55σ, 0° from it as an axis (the two cells' radii 56.7°). The direction is not resolved finer than 19.3° (over 15°), so it names no <100>, <110> or <111> family.
- ok: The displacements are anisotropic: the map departs from isotropy at 11.8σ. The peak test above places the preferred direction only to within its cell.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why; neighbour: the peak at that resolution (held: ≥ 3σ, the same axis within the two cells' radii)",
 "site": 2,
 "element": "Zr",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0.0896,
  2.96
 ],
 "peak": {
  "enhancement": 2.96,
  "count": 33,
  "expected": 11.2,
  "significance_sigma": 4.48,
  "direction_cartesian": [
   0.851,
   0,
   0.526
  ],
  "direction_uvw": [
   1,
   0,
   0.62
  ],
  "angles_to_abc_deg": [
   31.7,
   90,
   58.3
  ],
  "radius_deg": 19.3,
  "tier": "finding"
 },
 "neighbour": {
  "frequency": 1,
  "significance_sigma": 4.55,
  "enhancement": 1.87,
  "radius_deg": 37.4,
  "apart_deg": 0,
  "holds": true
 },
 "map_significance_sigma": 11.8,
 "antipodal_asymmetry": 0.148,
 "antipodal_asymmetry_z": -0.111,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.548,
   0.241,
   0.211
  ],
  "anisotropy": 0.644,
  "anisotropy_significance_sigma": 15.7,
  "principal_axis_uvw": [
   1,
   0.03,
   0.01
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## Step 3 · analyze_modulations · round 3

*No reasoning or text was streamed before this call.*

**Arguments:** `{}` · status ok · 10.658750000060536 ms

**Checks the model read:**

- ok: Ordered Zr displacements at q = (½, ½, ½): 425× the median power, > 8σ against independent cells (corrected over 21 zone-boundary points) — a superstructure doubling the cell along a, b, c, polarised along [1 0 0] (0.8° off; 100 % of the power at q).
- note: Ca's strongest mode is a long-wavelength wave, q = (0, 0.125, 0) at 110× the median: box-scale displacement correlations (common in RMC), not a crystallographic superstructure.

<details><summary>Result the model read</summary>

```json
{
 "note": "zone_boundary rows are [q, ratio, percentile, sigma]: an element's displacement power at wavevector q (fractions of the cell's reciprocal axes) over its median across all q of the supercell grid (the diffuse background), the share of the compared modes (one per ±q pair, long waves with every |q_i| ≤ 0.25 left out) with less power, and the calibrated one-sided significance against independent cells (each cell's own correlations kept), corrected over all 21 zone-boundary points of the configuration's 3 elements, whichever the call names (≥ 3 with ratio ≥ 3 is order). strongest rows are [q, ratio, percentile, sigma]: the sigma of a general q (neither zone boundary nor long wave; a complex sum, corrected over the compared modes of every element), null otherwise. A ½ component is order that doubles the cell along that axis; order at a general q is correlation between cells (incommensurate or short-range) that does not. diffuse is [lag, correlation, sigma]: the strongest correlation between a site's displacements in cells one lag apart that the power over the compared modes shows (+ in phase, − antiphase), and the significance of the 13 neighbour-cell lags together against independent cells (≥ 3 with |correlation| ≥ 0.1: correlation spread over many q). polarisation: each ordered point's displacement direction (the leading axis of the element's power tensor at q) as a direct-lattice [u v w], an axis, and share, the fraction of the power at q along it (1: one direction; ⅓: none).",
 "supercell": [
  8,
  8,
  8
 ],
 "wavevectors": 511,
 "elements": [
  {
   "element": "Ca",
   "sites": 1,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     0.24,
     3.6,
     null
    ],
    [
     "(0, ½, 0)",
     1.2,
     61.9,
     -4.9
    ],
    [
     "(0, ½, ½)",
     0.084,
     0,
     null
    ],
    [
     "(½, 0, 0)",
     2.3,
     90.4,
     -2.7
    ],
    [
     "(½, 0, ½)",
     0.32,
     5.6,
     null
    ],
    [
     "(½, ½, 0)",
     0.53,
     14.2,
     -7.8
    ],
    [
     "(½, ½, ½)",
     0.64,
     23.9,
     -7.2
    ]
   ],
   "strongest": [
    [
     "(0, 0.125, 0)",
     110,
     100,
     null
    ],
    [
     "(0, 0.375, 0.25)",
     4.7,
     99.5,
     -2.9
    ],
    [
     "(0.125, 0.375, 0.125)",
     4.3,
     99,
     -4.3
    ]
   ],
   "diffuse": [
    "[1 -1 1]",
    0.079,
    -1.9
   ]
  },
  {
   "element": "O",
   "sites": 3,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     1.3,
     77.7,
     -3
    ],
    [
     "(0, ½, 0)",
     1.7,
     93.4,
     -1.4
    ],
    [
     "(0, ½, ½)",
     1.9,
     97.5,
     -0.8
    ],
    [
     "(½, 0, 0)",
     0.52,
     4.1,
     null
    ],
    [
     "(½, 0, ½)",
     1.4,
     83.2,
     -2.7
    ],
    [
     "(½, ½, 0)",
     0.66,
     12.7,
     -7.2
    ],
    [
     "(½, ½, ½)",
     1,
     50.8,
     -4.6
    ]
   ],
   "strongest": [
    [
     "(0, ½, 0.375)",
     2.2,
     99.5,
     -2.5
    ],
    [
     "(½, 0.375, -0.375)",
     2.1,
     99,
     -2.9
    ],
    [
     "(0.125, 0, 0.25)",
     2.1,
     99,
     null
    ]
   ],
   "diffuse": [
    "[0 1 0]",
    -0.11,
    0
   ]
  },
  {
   "element": "Zr",
   "sites": 1,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     2.96,
     97.5,
     -2.3
    ],
    [
     "(0, ½, 0)",
     2.2,
     91.4,
     -3.3
    ],
    [
     "(0, ½, ½)",
     0.17,
     1.5,
     null
    ],
    [
     "(½, 0, 0)",
     0.38,
     12.2,
     null
    ],
    [
     "(½, 0, ½)",
     0.92,
     47.2,
     -6.2
    ],
    [
     "(½, ½, 0)",
     0.32,
     8.6,
     null
    ],
    [
     "(½, ½, ½)",
     430,
     99.5,
     18.8
    ]
   ],
   "strongest": [
    [
     "(½, ½, ½)",
     430,
     99.5,
     null
    ],
    [
     "(0, 0, 0.375)",
     3.5,
     99,
     null
    ],
    [
     "(0.375, 0.125, 0.125)",
     3.1,
     98.5,
     null
    ]
   ],
   "polarisation": [
    {
     "q": "(½, ½, ½)",
     "uvw": [
      1,
      0.01,
      -0.01
     ],
     "share": 1,
     "nearest_low_index": {
      "uvw": [
       1,
       0,
       0
      ],
      "off_deg": 0.8
     }
    }
   ],
   "diffuse": [
    "[1 -1 0]",
    0.14,
    0.6
   ]
  }
 ]
}
```

</details>

## Step 4 · measure_symmetry_lowering · round 4

*No reasoning or text was streamed before this call.*

**Arguments:** `{"parent_tolerance_A":0.2,"tolerance_A":0.038}` · status ok · 36.68429100001231 ms

**Checks the model read:**

- ok: No site is shifted from the Pm-3m positions above the 0.03 Å noise floor (largest 0.007 Å): no coherent lowering of the average structure.

<details><summary>Result the model read</summary>

```json
{
 "note": "shift_A = the site mean's distance from the position the parent group puts it at, measured with the parent placed on the majority of the atoms (the origin a lowering leaves free is fixed by the geometric median of all shifts); a shift every copy of a site shares, which the displacement analyses cannot show; direction_uvw is a direct-lattice direction (±); se_A the sampling error of the site mean along it",
 "parent": {
  "tolerance_A": 0.2,
  "space_group": "Pm-3m",
  "point_group": "m-3m"
 },
 "lower": {
  "tolerance_A": 0.038,
  "space_group": "Pm-3m",
  "point_group": "m-3m",
  "point_group_facts": "m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar"
 },
 "noise_floor_A": 0.03,
 "sites": [
  {
   "ref": 3,
   "element": "O",
   "shift_A": 0.007,
   "direction_uvw": [
    1,
    -0.09,
    -0.47
   ],
   "se_A": 0.0038,
   "above_noise_floor": false
  },
  {
   "ref": 5,
   "element": "O",
   "shift_A": 0.007,
   "direction_uvw": [
    -0.59,
    1,
    -0.23
   ],
   "se_A": 0.0035,
   "above_noise_floor": false
  },
  {
   "ref": 4,
   "element": "O",
   "shift_A": 0.003,
   "direction_uvw": [
    0.3,
    -1,
    -0.5
   ],
   "se_A": 0.0028,
   "above_noise_floor": false
  },
  {
   "ref": 1,
   "element": "Ca",
   "shift_A": 0.002,
   "direction_uvw": [
    0.03,
    -0.72,
    1
   ],
   "nearest_low_index": {
    "uvw": [
     0,
     -1,
     1
    ],
    "off_deg": 9.5
   },
   "se_A": 0.0044,
   "above_noise_floor": false
  },
  {
   "ref": 2,
   "element": "Zr",
   "shift_A": 0.001,
   "direction_uvw": [
    -1,
    0.98,
    0.34
   ],
   "nearest_low_index": {
    "uvw": [
     -1,
     1,
     0
    ],
    "off_deg": 13.5
   },
   "se_A": 0.0037,
   "above_noise_floor": false
  }
 ]
}
```

</details>

## Step 5 · detect_symmetry · round 5

*No reasoning or text was streamed before this call.*

**Arguments:** `{"tolerance_A":0.038}` · status ok · 20.866665999987163 ms

**Checks the model read:**

- ok: Pm-3m (No. 221) holds at 0.038 Å.
- note: Point group m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar. Take inversion, chirality and polarity from this, not from memory.

<details><summary>Result the model read</summary>

```json
{
 "tolerance_A": 0.038,
 "space_group": "Pm-3m",
 "number": 221,
 "point_group": "m-3m",
 "point_group_facts": "m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar",
 "n_ops": 48,
 "max_residual_A": 0.013,
 "orbits": [
  {
   "element": "O",
   "wyckoff": "3c",
   "site_symmetry": "4/mmm",
   "frac": [
    0.5019,
    0.5001,
    0.9995
   ]
  },
  {
   "element": "Ca",
   "wyckoff": "1a",
   "site_symmetry": "m-3m",
   "frac": [
    0.0004,
    0.9999,
    0.0007
   ]
  },
  {
   "element": "Zr",
   "wyckoff": "1b",
   "site_symmetry": "m-3m",
   "frac": [
    0.5002,
    0.5005,
    0.5003
   ]
  }
 ]
}
```

</details>

## Step 6 · find_gr_peaks · round 6

*No reasoning or text was streamed before this call.*

**Arguments:** `{"pair":"Zr-O"}` · status ok · 0.2277089999988675 ms

**Checks the model read:**

- ok: First peak at 2.055 Å; first shell to 2.42 Å, mean 2.057 Å, CN 5.99 O per Zr, 2 Zr per O.

<details><summary>Result the model read</summary>

```json
{
 "pair": "Zr-O",
 "r_max_A": 6,
 "peaks_A": [
  {
   "r": 2.055,
   "fwhm": 0.23
  },
  {
   "r": 4.585,
   "fwhm": 0.28
  }
 ],
 "first_shell": {
  "window_A": [
   1.74,
   2.42
  ],
  "peaks_in_shell_A": [
   2.055
  ],
  "mean_d_A": 2.057,
  "sd_d_A": 0.093,
  "cn": {
   "O_per_Zr": 5.99,
   "Zr_per_O": 2
  },
  "cn_if_cut_0p2A_earlier_later": [
   5.76,
   5.99
  ],
  "trough_g_fraction": 0.00078,
  "average_structure_d_A": [
   2.05,
   2.05
  ]
 }
}
```

</details>

## The answer

*Round 6: the reference repair sent the answer below back to the model:*

> Average structure
> 
> * The average structure remains Pm-3m at the tested tolerance. `detect_symmetry` finds Pm-3m (No. 221) holds at 0.038 Å with max residual 0.013 Å {{r5.data.tolerance_A}} and point group m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar {{r5.data.point_group_facts}}.
> * `measure_symmetry_lowering` finds no coherent lowering above the sampling noise: no site is shifted from the Pm-3m positions above the 0.03 Å noise floor, largest shift 0.007 Å {{r4.checks.0.text}}; site shifts e.g. O 0.007 Å, Ca 0.002 Å, Zr 0.001 Å, all `above_noise_floor:false` {{r4.data.sites}}.
> 
> Zr local displacements
> 
> * `list_sites` reports a split Zr site: U_iso_A2 0.00605 Å², rms_axes_A [0.105,0.0621,0.0578] Å, anisotropy 1.81, kurtosis_axes [-0.906,null,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0857 Å, delta_se_A 0.0031 Å {{r1.data.sites.0}}.
> * `analyze_displacement_directions` for Zr: map departs from isotropy at 11.8σ, peak enhancement 2.96× isotropic at 4.48σ, direction_uvw [1,0,0.62] ±19.3°, held at ν=1 4.55σ; orientation tensor principal axis uvw [1,0.03,0.01] {{r2.data.peak}}, {{r2.data.map_significance_sigma}}, {{r2.data.orientation_tensor.principal_axis_uvw}}.
> 
> Correlated order / superstructure
> 
> * `analyze_modulations` shows ordered Zr displacements at q = (½,½,½): ratio 430× median, 99.5 percentile, sigma 18.8 against independent cells, corrected over 21 zone-boundary points {{r3.data.elements.2.zone_boundary.6}}. Polarisation at that q is uvw [1,0.01,-0.01
> … [1520 more characters in the JSON record]

- Reference repair, round 6: The answer quoted 7 numbers by reference that name no value; the app asked for them again.

Stopped by: max_rounds · rounds: 6 · outcome (computed): not verified · against the score: held

Why: 2 checks below contradict the answer; the analysis a conclusion needs did not run (analyze_clusters). Zr shows a significant ½½½ superstructure modulation with a split-site off-centring, while the average structure remains Pm-3m centrosymmetric non-polar and no coherent symmetry lowering is detected above noise; polyhedral/cluster distortion analyses are still missing.

> Average structure
> 
> * The average structure remains Pm-3m at the tested tolerance. `detect_symmetry` finds Pm-3m (No. 221) holds at 0.038 Å with max residual 0.013 Å 0.038 and point group m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar.
> * `measure_symmetry_lowering` finds no coherent lowering above the sampling noise: no site is shifted from the Pm-3m positions above the 0.03 Å noise floor, largest shift 0.007 Å; site shifts e.g. O 0.007 Å 0.007, Ca 0.002 Å 0.002, Zr 0.001 Å 0.001, all `above_noise_floor:false`.
> 
> Zr local displacements
> 
> * `list_sites` reports a split Zr site: U_iso_A2 0.00605 Å², rms_axes_A [0.105,0.0621,0.0578] Å, anisotropy 1.81, kurtosis_axes [-0.906,null,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0857 Å, delta_se_A 0.0031 Å 0.0857.
> * `analyze_displacement_directions` for Zr: map departs from isotropy at 11.8σ 11.8, peak enhancement 2.96× isotropic at 4.48σ 4.48, direction_uvw [1,0,0.62] ±19.3°, held at ν=1 4.55σ; orientation tensor principal axis uvw [1,0.03,0.01] [1, 0.03, 0.01].
> 
> Correlated order / superstructure
> 
> * `analyze_modulations` shows ordered Zr displacements at q = (½,½,½): ratio 430× median, 99.5 percentile, sigma 18.8 against independent cells, corrected over 21 zone-boundary points 18.8.
>   Polarisation at that q is uvw [1,0.01,-0.01], share 1, nearest low index [1,0,0] off 0.8° 0.8.
>   This is a superstructure doubling the cell along a,b,c, polarised along [1 0 0].
> * Ca strongest mode is q = (0,0.125,0) at 110× median, described as box-scale displacement correlations, not a crystallographic superstructure.
> 
> First coordination shell
> 
> * Zr–O first peak at 2.055 Å, first shell to 2.42 Å, mean 2.057 Å, CN 5.99 O per Zr, 2 Zr per O 2.057; average structure d 2.05 Å.
> 
> What is still missing
> 
> No bond-angle / polyhedral distortion metrics, no cluster analysis, and no explicit test for Jahn–Teller / rigid-cluster / breathing modes have been run. The split-site / preferred-direction signatures are consistent with the q = ½½½ superstructure, but a dedicated cluster / polyhedron distortion analysis is required to confirm distorted polyhedra beyond the first-shell mean.
> 
> Outcome: Zr shows a significant ½½½ superstructure modulation with a split-site off-centring, while the average structure remains Pm-3m centrosymmetric non-polar and no coherent symmetry lowering is detected above noise; polyhedral/cluster distortion analyses are still missing.
> VERDICT {"features": [{"kind": "modulation", "element": "Zr", "direction_uvw": [1,0.01,-0.01], "magnitude_A": null, "q": [0.5,0.5,0.5]}, {"kind": "off_centre", "element": "Zr", "direction_uvw": [1,0.03,-0.02], "magnitude_A": 0.0857, "q": null}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}

Numbers by reference: 12 of 12 filled from the analyses.

<details><summary>The answer as the model wrote it</summary>

> Average structure
> 
> * The average structure remains Pm-3m at the tested tolerance. `detect_symmetry` finds Pm-3m (No. 221) holds at 0.038 Å with max residual 0.013 Å {{r5.data.tolerance_A}} and point group m-3m: cubic; centrosymmetric; achiral (not a Sohncke group); non-polar {{r5.data.point_group_facts}}.
> * `measure_symmetry_lowering` finds no coherent lowering above the sampling noise: no site is shifted from the Pm-3m positions above the 0.03 Å noise floor, largest shift 0.007 Å; site shifts e.g. O 0.007 Å {{r4.data.sites.0.shift_A}}, Ca 0.002 Å {{r4.data.sites.3.shift_A}}, Zr 0.001 Å {{r4.data.sites.4.shift_A}}, all `above_noise_floor:false`.
> 
> Zr local displacements
> 
> * `list_sites` reports a split Zr site: U_iso_A2 0.00605 Å², rms_axes_A [0.105,0.0621,0.0578] Å, anisotropy 1.81, kurtosis_axes [-0.906,null,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0857 Å, delta_se_A 0.0031 Å {{r1.data.sites.0.delta_A}}.
> * `analyze_displacement_directions` for Zr: map departs from isotropy at 11.8σ {{r2.data.map_significance_sigma}}, peak enhancement 2.96× isotropic at 4.48σ {{r2.data.peak.significance_sigma}}, direction_uvw [1,0,0.62] ±19.3°, held at ν=1 4.55σ; orientation tensor principal axis uvw [1,0.03,0.01] {{r2.data.orientation_tensor.principal_axis_uvw}}.
> 
> Correlated order / superstructure
> 
> * `analyze_modulations` shows ordered Zr displacements at q = (½,½,½): ratio 430× median, 99.5 percentile, sigma 18.8 against independent cells, corrected over 21 zone-boundary points {{r3.data.elements.2.zone_boundary.6.3}}.
>   Polarisation at that q is uvw [1,0.01,-0.01], share 1, nearest low index [1,0,0] off 0.8° {{r3.data.elements.2.polarisation.0.nearest_low_index.off_deg}}.
>   This is a superstructure doubling the cell along a,b,c, polarised along [1 0 0].
> * Ca strongest mode is q = (0,0.125,0) at 110× median, described as box-scale displacement correlations, not a crystallographic superstructure.
> 
> First coordination shell
> 
> * Zr–O first peak at 2.055 Å, first shell to 2.42 Å, mean 2.057 Å, CN 5.99 O per Zr, 2 Zr per O {{r6.data.first_shell.mean_d_A}}; average structure d 2.05 Å.
> 
> What is still missing
> 
> No bond-angle / polyhedral distortion metrics, no cluster analysis, and no explicit test for Jahn–Teller / rigid-cluster / breathing modes have been run. The split-site / preferred-direction signatures are consistent with the q = ½½½ superstructure, but a dedicated cluster / polyhedron distortion analysis is required to confirm distorted polyhedra beyond the first-shell mean.
> 
> Outcome: Zr shows a significant ½½½ superstructure modulation with a split-site off-centring, while the average structure remains Pm-3m centrosymmetric non-polar and no coherent symmetry lowering is detected above noise; polyhedral/cluster distortion analyses are still missing.
> VERDICT {"features": [{"kind": "modulation", "element": "Zr", "direction_uvw": [1,0.01,-0.01], "magnitude_A": null, "q": [0.5,0.5,0.5]}, {"kind": "off_centre", "element": "Zr", "direction_uvw": [1,0.03,-0.02], "magnitude_A": 0.0857, "q": null}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}

</details>

## Verdict and score

```json
{
 "features": [
  {
   "kind": "modulation",
   "element": "Zr",
   "direction_uvw": [
    1,
    0.01,
    -0.01
   ],
   "q": [
    0.5,
    0.5,
    0.5
   ]
  },
  {
   "kind": "off_centre",
   "element": "Zr",
   "direction_uvw": [
    1,
    0.03,
    -0.02
   ],
   "magnitude_A": 0.0857
  }
 ],
 "space_group": "Pm-3m",
 "chiral": false,
 "centrosymmetric": true,
 "polar": false
}
```

| Item | Result |
| --- | --- |
| planted modulation (Zr) | found; direction off by 0.8°; q [0.5,0.5,0.5] ok |
| spurious claims | off_centre (Zr) |
| space_group | right |
| chiral | right |
| centrosymmetric | right |
| polar | right |
| **case score** | **0.8333**  |

## Answer checks

- Findings under the answer: window: The answer gives a coordination number ("CN 5.99") without its window in Å: every coordination number and bond angle carries the window it was counted in (this question's: Zr–O 1.74–2.42 Å; O–Zr 1.74–2.42 Å). · single-configuration: The answer quotes the numbers of the site 2 displacement-direction distribution without saying they come from one configuration: every analysis here reads the run's one configuration, so its distribution carries no spread between runs; say so. · evidence: The answer concludes the clusters' distortion, breathing or rigidity, but analyze_clusters did not run in this question.
- Contradictions in the verdict a check covers: caught none; missed spurious off_centre (Zr)
- Findings with no matching contradiction in the verdict: window, single-configuration, evidence

## Numbers in the answer

50 of 50 checkable numbers match a value the model was shown.

| Number | In the answer | Source |
| --- | --- | --- |
| 0.038 Å | ymmetry` finds Pm-3m (No. 221) holds at 0.038 Å with max residual 0 | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.lower.tolerance_A |
| 0.013 Å | 221) holds at 0.038 Å with max residual 0.013 Å 0.038 and point gro | tool detect_symmetry (GAGheshkfQUBIILVyJTBOdY9nznlSKuz#5) data.max_residual_A |
| 0.038 | ds at 0.038 Å with max residual 0.013 Å 0.038 and point group m-3 | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.lower.tolerance_A |
| 0.03 Å | fted from the Pm-3m positions above the 0.03 Å noise floor, larges | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].pc1_uvw[1] |
| 0.007 Å | e the 0.03 Å noise floor, largest shift 0.007 Å; site shifts e.g. O | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[0].shift_A |
| 0.007 Å | rgest shift 0.007 Å; site shifts e.g. O 0.007 Å 0.007, Ca 0.002 Å 0 | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[0].shift_A |
| 0.007 | ift 0.007 Å; site shifts e.g. O 0.007 Å 0.007, Ca 0.002 Å 0.002, | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[0].shift_A |
| 0.002 Å | Å; site shifts e.g. O 0.007 Å 0.007, Ca 0.002 Å 0.002, Zr 0.001 Å 0 | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[3].shift_A |
| 0.002 | shifts e.g. O 0.007 Å 0.007, Ca 0.002 Å 0.002, Zr 0.001 Å 0.001, | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[3].shift_A |
| 0.001 Å | . O 0.007 Å 0.007, Ca 0.002 Å 0.002, Zr 0.001 Å 0.001, all `above_n | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[4].shift_A |
| 0.001 | 7 Å 0.007, Ca 0.002 Å 0.002, Zr 0.001 Å 0.001, all `above_noise_f | tool measure_symmetry_lowering (uc8lMsPdoDKWul8zVD27PGsqlzXk0GjH#4) data.sites[4].shift_A |
| 0.00605 Å | ites` reports a split Zr site: U_iso_A2 0.00605 Å², rms_axes_A [0.105 | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].U_iso_A2 |
| 0.105 | site: U_iso_A2 0.00605 Å², rms_axes_A [0.105,0.0621,0.0578] Å, a | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].rms_axes_A[0] |
| 0.0621 | U_iso_A2 0.00605 Å², rms_axes_A [0.105,0.0621,0.0578] Å, anisotro | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].rms_axes_A[1] |
| 0.0578 | A2 0.00605 Å², rms_axes_A [0.105,0.0621,0.0578] Å, anisotropy 1.81 | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].rms_axes_A[2] |
| 1.81 | s_A [0.105,0.0621,0.0578] Å, anisotropy 1.81, kurtosis_axes [-0. | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].anisotropy |
| -0.906 | 578] Å, anisotropy 1.81, kurtosis_axes [-0.906,null,null], pc1_uvw | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].kurtosis_axes[0] |
| 0.03 | sis_axes [-0.906,null,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0 | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].pc1_uvw[1] |
| -0.02 | xes [-0.906,null,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0857 Å, | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].pc1_uvw[2] |
| 0.0857 Å | ,null], pc1_uvw [1,0.03,-0.02], delta_A 0.0857 Å, delta_se_A 0.0031 | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].delta_A |
| 0.0031 Å | 03,-0.02], delta_A 0.0857 Å, delta_se_A 0.0031 Å 0.0857. * `analyze_ | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].delta_se_A |
| 0.0857 | , delta_A 0.0857 Å, delta_se_A 0.0031 Å 0.0857. * `analyze_displac | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].delta_A |
| 11.8 σ | s` for Zr: map departs from isotropy at 11.8σ 11.8, peak enhancem | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.map_significance_sigma |
| 11.8 | Zr: map departs from isotropy at 11.8σ 11.8, peak enhancement 2 | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.map_significance_sigma |
| 2.96 × | sotropy at 11.8σ 11.8, peak enhancement 2.96× isotropic at 4.48σ | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.enhancement_range[1] |
| 4.48 σ | .8, peak enhancement 2.96× isotropic at 4.48σ 4.48, direction_uvw | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.peak.significance_sigma |
| 4.48 | ak enhancement 2.96× isotropic at 4.48σ 4.48, direction_uvw [1,0 | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.peak.significance_sigma |
| 0.62 | ropic at 4.48σ 4.48, direction_uvw [1,0,0.62] ±19.3°, held at ν= | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.peak.direction_uvw[2] |
| 19.3 ° | t 4.48σ 4.48, direction_uvw [1,0,0.62] ±19.3°, held at ν=1 4.55σ; | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.peak.radius_deg |
| 4.55 σ | tion_uvw [1,0,0.62] ±19.3°, held at ν=1 4.55σ; orientation tensor | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) data.neighbour.significance_sigma |
| 0.03 | rientation tensor principal axis uvw [1,0.03,0.01] [1, 0.03, 0.0 | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].pc1_uvw[1] |
| 0.01 | ation tensor principal axis uvw [1,0.03,0.01] [1, 0.03, 0.01]. | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].U_iso_A2 |
| 0.03 | or principal axis uvw [1,0.03,0.01] [1, 0.03, 0.01]. Correlated | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].pc1_uvw[1] |
| 0.01 | ncipal axis uvw [1,0.03,0.01] [1, 0.03, 0.01]. Correlated order | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].U_iso_A2 |
| 430 × | Zr displacements at q = (½,½,½): ratio 430× median, 99.5 percen | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[2].zone_boundary[6][1] |
| 99.5 | ents at q = (½,½,½): ratio 430× median, 99.5 percentile, sigma 1 | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[0].strongest[1][2] |
| 18.8 | tio 430× median, 99.5 percentile, sigma 18.8 against independent | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[2].zone_boundary[6][3] |
| 18.8 | corrected over 21 zone-boundary points 18.8. Polarisation at | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[2].zone_boundary[6][3] |
| 0.01 | 8.8. Polarisation at that q is uvw [1,0.01,-0.01], share 1, ne | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].U_iso_A2 |
| -0.01 | Polarisation at that q is uvw [1,0.01,-0.01], share 1, nearest | tool list_sites (P3H8fxqHZSIvczQ5I4kRiO9wsnPEYQfT#1) data.sites[0].U_iso_A2 |
| 0.8 ° | share 1, nearest low index [1,0,0] off 0.8° 0.8. This is a su | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[1].zone_boundary[2][3] |
| 0.8 | e 1, nearest low index [1,0,0] off 0.8° 0.8. This is a supers | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[1].zone_boundary[2][3] |
| 0.125 | [1 0 0]. * Ca strongest mode is q = (0,0.125,0) at 110× median, | tool analyze_modulations (VQxboNgZEfal4FnXvlzLLl1le6aa1XD9#3) data.elements[0].strongest[0][0] |
| 110 × | Ca strongest mode is q = (0,0.125,0) at 110× median, described a | tool analyze_displacement_directions (x5FbUVIemycZqxlXnKtVDNYLZBX29ELn#2) check 1 |
| 2.055 Å | oordination shell * Zr–O first peak at 2.055 Å, first shell to 2.4 | tool find_gr_peaks (5SN76xAvEFlT2RDaDlUoDPQEKotOa3eT#6) data.peaks_A[0].r |
| 2.42 Å | O first peak at 2.055 Å, first shell to 2.42 Å, mean 2.057 Å, CN 5 | tool find_gr_peaks (5SN76xAvEFlT2RDaDlUoDPQEKotOa3eT#6) data.first_shell.window_A[1] |
| 2.057 Å | at 2.055 Å, first shell to 2.42 Å, mean 2.057 Å, CN 5.99 O per Zr, | tool find_gr_peaks (5SN76xAvEFlT2RDaDlUoDPQEKotOa3eT#6) data.first_shell.mean_d_A |
| 5.99 | first shell to 2.42 Å, mean 2.057 Å, CN 5.99 O per Zr, 2 Zr per | tool find_gr_peaks (5SN76xAvEFlT2RDaDlUoDPQEKotOa3eT#6) data.first_shell.cn.O_per_Zr |
| 2.057 | n 2.057 Å, CN 5.99 O per Zr, 2 Zr per O 2.057; average structure | tool find_gr_peaks (5SN76xAvEFlT2RDaDlUoDPQEKotOa3eT#6) data.first_shell.mean_d_A |
| 2.05 Å | , 2 Zr per O 2.057; average structure d 2.05 Å. What is still mis | tool find_gr_peaks (5SN76xAvEFlT2RDaDlUoDPQEKotOa3eT#6) data.peaks_A[0].r |

## Safety

- Unsafe actions: 0
- Unknown-tool calls: 0 · failed calls: 0 · questions to the user: 0 (all skipped by the simulated user)
- Skills read: none

## Planted truth (never shown to the model)

Zr displaced ±0.09 Å along [1 0 0] in an ordered pattern with q = (0.5, 0.5, 0.5) (a superstructure the folded average cannot show); Ca carries a stronger box-scale wave at q = (0, 0.125, 0) as a decoy

```json
{
 "features": [
  {
   "kind": "modulation",
   "element": "Zr",
   "accept": [
    "modulation"
   ],
   "q": [
    0.5,
    0.5,
    0.5
   ],
   "direction_uvw": [
    1,
    0,
    0
   ],
   "direction_mode": "axis"
  }
 ],
 "tolerated": [],
 "symmetry": {
  "space_group": "Pm-3m",
  "chiral": false,
  "centrosymmetric": true,
  "polar": false,
  "primary": false
 }
}
```

Traps in this case:
- Zr's folded cloud is split ±0.09 Å like two-site disorder: only the cell-to-cell correlation (analyze_modulations) shows it is ordered
- Ca's strongest mode is a long wave at the box scale, not a crystallographic superstructure
