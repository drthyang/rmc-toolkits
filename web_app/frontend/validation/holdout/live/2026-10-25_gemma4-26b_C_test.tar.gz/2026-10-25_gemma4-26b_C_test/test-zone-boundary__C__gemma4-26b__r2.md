# test-zone-boundary__C__gemma4:26b__r2

- Case: `test-zone-boundary` (test set) · Arm C: Copilot without the method: no skills, method rules or advice (ablation)
- Model: gemma4:26b (Ollama) (`gemma4:26b`, temperature 0.2) · run 2
- Protocol 2026-10-24.6 · commit 7456af9dfe904c66b62dc900f39aa734a6c9c447 · 2026-10-25T01:47:52.289Z → 2026-10-25T01:49:10.733Z (78 s)
- Server: Ollama 0.40.2 · context window: num_ctx 40,960 (sized per request; the model holds 262,144)
- Reply cap: num_ctx minus the prompt estimate, per request · final round: no tools sent (the native API has no tool_choice)
- Temperature 0.2 (a request asked again after a loop: 0.6 or more) · limits: 6 rounds × 4 calls, 3600 s a turn, results 3,000 / turn 12,000 characters, 2 questions, 2 gate send-backs
- Context guard: refuses a request that would not fit, never cuts it (2.5 characters a token, 1.4 for tool JSON; 8,192-token reply reserve)
- Tools offered: read_run_data, find_gr_peaks, list_sites, analyze_displacement_directions, compute_bond_angles, polyhedral_distortion, analyze_clusters, analyze_modulations, detect_symmetry, measure_symmetry_lowering, ask_user
- Skills offered: none (ablation)
- View: Detected SG at 0.2 Å with its ladder, nothing hidden, no PCA table, Live Data off
- Context sections: structure, symmetry, pair_correlations, datasets (absent: configuration_optimization, run_settings, pca_displacements, partial_weights, convergence) · one fresh question, no earlier turns

## Step 0 · the question

> Analyse the local structure of this RMC configuration. Is there order or distortion beyond the average structure (off-centred atoms, correlated clusters, a superstructure, distorted polyhedra)? What is the average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on the Workbench's analyses, and say so plainly if there is no such order.
> 
> Finish with one line that starts with VERDICT and holds a JSON object, after everything else (the Outcome line included):
> VERDICT {"features": [{"kind": "...", "element": "...", "direction_uvw": [u, v, w] or null, "magnitude_A": number or null, "q": [h, k, l] or null}], "space_group": "..." or null, "chiral": true/false/null, "centrosymmetric": true/false/null, "polar": true/false/null}
> kind is one of off_centre, modulation, cluster_distortion, cluster_breathing, rigid_cluster, jahn_teller, symmetry_lowering. features is [] when there is no order beyond thermal motion. direction_uvw is a crystal direction; magnitude_A the static displacement (off_centre, symmetry_lowering) or the long minus short bond (jahn_teller); q in reciprocal-lattice units. Use null for what you did not determine. A number may be a reference to a tool result, as in the answer ("magnitude_A": {{r3.sites.0.shift_A}}): the app fills it in; a text reference goes inside its quotes ("element": "{{r3.sites.0.element}}").

## Step 1 · list_sites · round 1

**Model reasoning before the call:**

> The user wants a comprehensive analysis of the local structure of the RMC configuration.
> I need to check for:
> 1.  **Off-centered atoms**: I'll use `list_sites` to see displacement statistics and `analyze_displacement_directions` to see if there's a preferred direction. I'll also check `measure_symmetry_lowering` to see if there's a coherent shift.
> 2.  **Correlated clusters**: I'll use `analyze_clusters` for Zr or Ca.
> 3.  **Superstructure**: I'll use `analyze_modulations`.
> 4.  **Distorted polyhedra**: I'll use `polyhedral_distortion` for Zr-O or Ca-O.
> 5.  **Average structure properties**: The context already provides the space group (Pm-3m), point group (m-3m), and its properties (cubic, centrosymmetric, achiral, non-polar).
> 
> Plan:
> 1.  Check `list_sites` for Ca, Zr, and O to see displacement statistics.
> 2.  Check `analyze_displacement_directions` for Ca or Zr to see if there's a preferred direction.
> 3.  Check `measure_symmetry_lowering` to see if there's a coherent shift.
> 4.  Check `analyze_modulations` to see if there's a superstructure.
> 5.  Check `polyhedral_distribution` for Zr-O (since Zr-O is a common coordination in such systems).
> 6.  Check `analyze_clusters` for Zr or Ca.
> 
> Let's start by looking at the site statistics and symmetry lowering.

**Arguments:** `{"element":"Ca"}` · status ok · 4.559291999961715 ms

**Checks the model read:**

- ok: 1 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; pc1_uvw = PC1 as a direct-lattice direction [u v w] (not a plane normal), where PC1 is resolved; sites sorted by |kurtosis|, largest first",
 "element": "Ca",
 "n_sites": 1,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  1
 ],
 "largest_abs_kurtosis_refs": [
  1
 ],
 "most_anisotropic_refs": [
  1
 ],
 "sites": [
  {
   "ref": 1,
   "site": "Ca",
   "count": 512,
   "U_iso_A2": 0.00864,
   "rms_axes_A": [
    0.112,
    0.0835,
    0.0805
   ],
   "anisotropy": 1.39,
   "kurtosis": -0.137,
   "kurtosis_axes": [
    -0.466,
    null,
    null
   ],
   "pc1_uvw": [
    0.15,
    0.07,
    1
   ]
  }
 ]
}
```

</details>

## Step 2 · list_sites · round 2

*No reasoning or text was streamed before this call.*

**Arguments:** `{"element":"Zr"}` · status ok · 3.4495420000166632 ms

**Checks the model read:**

- note: Split: site 2 (Zr) has two positions along PC1 (PC1 excess kurtosis ≤ −0.5, at least 3 sampling errors below 0); delta_A is the static displacement, along pc1_uvw.
- ok: 1 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; pc1_uvw = PC1 as a direct-lattice direction [u v w] (not a plane normal), where PC1 is resolved; delta_A = static displacement along PC1 of a split site (two positions: PC1 excess kurtosis ≤ −0.5 and 3 sampling errors below 0), sqrt(rms1² − rms⊥²) with rms⊥² = (rms2² + rms3²)/2: ±delta_A for two equally occupied positions, their RMS otherwise; delta_se_A = its sampling error; split sites first (largest delta_A first), then by |kurtosis|, largest first",
 "element": "Zr",
 "n_sites": 1,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  2
 ],
 "largest_abs_kurtosis_refs": [
  2
 ],
 "most_anisotropic_refs": [
  2
 ],
 "sites": [
  {
   "ref": 2,
   "site": "Zr",
   "count": 512,
   "U_iso_A2": 0.00605,
   "rms_axes_A": [
    0.105,
    0.0621,
    0.0578
   ],
   "anisotropy": 1.81,
   "kurtosis": -0.15,
   "kurtosis_axes": [
    -0.906,
    null,
    null
   ],
   "pc1_uvw": [
    1,
    0.03,
    -0.02
   ],
   "delta_A": 0.0857,
   "delta_se_A": 0.0031
  }
 ]
}
```

</details>

## Step 3 · analyze_modulations · round 3

**Model reasoning before the call:**

> The user wants to know if there is any order or distortion beyond the average structure.
> From `list_sites` for Ca (r1):
> - `kurtosis` is -0.137 (not highly non-Gaussian).
> - `anisotropy` is 1.39.
> - `pc1_uvw` is [0.15, 0.07, 1].
> 
> From `list_sites` for Zr (r2):
> - `kurtosis` is -0.15.
> - `anisotropy` is 1.81.
> - `delta_A` is 0.0857 Å, which indicates a split site (two positions along PC1).
> - `pc1_uvw` is [1, 0.03, -0.02].
> 
> The average structure's space group is given in the context as `Pm-3m (No. 221)`.
> From the context:
> - `Pm-3m` is `m-3m`.
> - `m-3m` is `cubic; centrosymmetric; achiral (not a Sohncke group); non-polar`.
> 
> I should also check for clusters or modulations.
> I'll check `analyze_modulations` to see if there's a superstructure.
> I'll also check `analyze_clusters` for Zr or Ca, but since Zr is already identified as split, I'll check if there's any cluster distortion.
> I'll also check `polyhedral_distortion` for Zr-O or Ca-O.
> 
> Let's start with `analyze_modulations`.

**Arguments:** `{"element":"all"}` · status failed (error) · 0.09229199995752424 ms

**Error:** element must be one of "Ca", "O", "Zr", got "all"

## Step 4 · polyhedral_distortion · round 4

**Model reasoning before the call:**

> The user wants to know if there is any order or distortion beyond the average structure.
> From `list_sites`, I see:
> - Ca site: `kurtosis` is -0.137 (not very negative, so not clearly split).
> - Zr site: `kurt_axes` shows a significant negative kurtosis along PC1 (-0.906), and `delta_A` is 0.0857 Å. This indicates a split site (two positions) for Zr.
> 
> I also need to check for:
> - Correlated clusters: I'll use `analyze_clusters` for Zr-O or Ca-O if possible, but I'll start by checking if there are any obvious clusters.
> - Superstructure: I tried `analyze_modulations` with "all" and it failed. I should try it for each element or just for the whole system if I can. The error says "element must be one of...". I'll try it for "Zr" since it's split.
> - Distorted polyhedra: I'll use `polyhedral_distortion` for Zr-O and Ca-O.
> - Symmetry of the average structure: The context says `Pm-3m (No. 221)`. It is centrosymmetric, achiral, and non-polar.
> 
> Let's check `polyhedral_distortion` for Zr-O. I need a window. I'll use the first shell from `pair_correlations` for Zr-O: `r_min=1.5`, `r_max=2.5`.
> I'll also check `analyze_clusters` for Zr-O.
> I'll also check `analyze_modulations` for Zr.
> 
> Plan:
> 1. Check `polyhedral_distortion` for Zr-O.
> 2. Check `analyze_clusters` for Zr-O.
> 3. Check `analyze_modulations` for Zr.
> 4. Synthesize the answer.
> 
> Wait, I already have the Zr split site info.
> I'll check `polyhedral_distortion` for Zr-O first.

**Arguments:** `{"centre":"Zr","ligand":"O","r_max":2.5,"r_min":1.5,"window_confirmed":true}` · status ok · 18.679208000015933 ms

**Checks the model read:**

- ok: Every Zr atom (512) has 6 O within 1.5–2.5 Å (octahedron): measured.

<details><summary>Result the model read</summary>

```json
{
 "pair": "Zr–O (Zr central)",
 "window_A": [
  1.5,
  2.5
 ],
 "coordination": {
  "note": "counts[n] = Zr atoms with exactly n O in the window",
  "counts": [
   0,
   0,
   0,
   0,
   0,
   0,
   512
  ],
  "mean": 6,
  "modal": 6,
  "modal_share": 1,
  "unbonded_share": 0
 },
 "shell": {
  "note": "the first Zr–O shell (find_gr_peaks); cn, cn_in_window: O per Zr",
  "window_A": [
   1.74,
   2.42
  ],
  "cn": 5.99,
  "cn_in_window": 6,
  "holds": "more"
 },
 "measured": {
  "coordination": 6,
  "shape": "octahedron",
  "centres": 512,
  "polyhedra": 512,
  "skipped": 0
 },
 "configuration": {
  "bond_length_A": {
   "mean": 2.057,
   "sd": 0.092
  },
  "distortion_index": {
   "mean": 0.035,
   "sd": 0.013,
   "p10": 0.0194,
   "median": 0.0336,
   "p90": 0.0502
  },
  "quadratic_elongation": {
   "mean": 1.0088,
   "sd": 0.0044,
   "p10": 1.0041,
   "median": 1.0081,
   "p90": 1.0139
  },
  "angle_variance_deg2": {
   "mean": 23.7,
   "sd": 12,
   "p10": 9.58,
   "median": 21.9,
   "p90": 39.4
  },
  "trans_angle_deg": {
   "mean": 173,
   "sd": 2.4
  }
 },
 "average_structure": {
  "polyhedra": 1,
  "bond_ladder_A": [
   2.046,
   2.047,
   2.048,
   2.052,
   2.053,
   2.054
  ],
  "distortion_index": {
   "mean": 0.00153,
   "sd": null
  },
  "quadratic_elongation": {
   "mean": 1,
   "sd": null
  },
  "angle_variance_deg2": {
   "mean": 0.0235,
   "sd": null
  },
  "trans_angle_deg": {
   "mean": 179.7,
   "sd": null
  }
 }
}
```

</details>

## Step 5 · analyze_modulations · round 5

*No reasoning or text was streamed before this call.*

**Arguments:** `{"element":"Ca"}` · status ok · 8.539958000008482 ms

**Checks the model read:**

- ok: No order that doubles the cell: no zone-boundary point stands out of the diffuse background (the strongest, Ca at (½, 0, 0), is 2.3× the median, -2.7σ after the correction).
- note: Ca's strongest mode is a long-wavelength wave, q = (0, 0.125, 0) at 110× the median: box-scale displacement correlations, not a crystallographic superstructure.

<details><summary>Result the model read</summary>

```json
{
 "note": "zone_boundary rows are [q, ratio, percentile, sigma]: an element's displacement power at wavevector q (fractions of the cell's reciprocal axes) over its median across all q of the supercell grid (the diffuse background), the share of the compared modes (one per ±q pair, long waves with every |q_i| ≤ 0.25 left out) with less power, and the calibrated one-sided significance against independent cells (each cell's own correlations kept), corrected over all 21 zone-boundary points of the configuration's 3 elements, whichever the call names (≥ 3 with ratio ≥ 3 is order). strongest rows are [q, ratio, percentile, sigma]: the sigma of a general q (neither zone boundary nor long wave; a complex sum, corrected over the compared modes of every element), null otherwise. A ½ component is order that doubles the cell along that axis; order at a general q is correlation between cells (incommensurate or short-range) that does not. diffuse is [lag, correlation, sigma]: the strongest correlation between a site's displacements in cells one lag apart that the power over the compared modes shows (+ in phase, − antiphase), and the significance of the 13 neighbour-cell lags together against independent cells (≥ 3 with |correlation| ≥ 0.1: correlation spread over many q).",
 "supercell": [
  8,
  8,
  8
 ],
 "wavevectors": 511,
 "elements": [
  {
   "element": "Ca",
   "sites": 1,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     0.24,
     3.6,
     null
    ],
    [
     "(0, ½, 0)",
     1.2,
     61.9,
     -4.9
    ],
    [
     "(0, ½, ½)",
     0.084,
     0,
     null
    ],
    [
     "(½, 0, 0)",
     2.3,
     90.4,
     -2.7
    ],
    [
     "(½, 0, ½)",
     0.32,
     5.6,
     null
    ],
    [
     "(½, ½, 0)",
     0.53,
     14.2,
     -7.8
    ],
    [
     "(½, ½, ½)",
     0.64,
     23.9,
     -7.2
    ]
   ],
   "strongest": [
    [
     "(0, 0.125, 0)",
     110,
     100,
     null
    ],
    [
     "(0, 0.375, 0.25)",
     4.7,
     99.5,
     -2.9
    ],
    [
     "(0.125, 0.375, 0.125)",
     4.3,
     99,
     -4.3
    ]
   ],
   "diffuse": [
    "[1 -1 1]",
    0.079,
    -1.9
   ]
  }
 ]
}
```

</details>

## The answer

*Round 5: the evidence gate: lowering sent the answer below back to the model:*

> The average structure of this RMC configuration belongs to the space group **Pm-3m (No. 221)**, which is **centrosymmetric**, **achiral**, and **non-polar** (as specified in the symmetry context).
> 
> Analysis of the local structure reveals several features of disorder and distortion beyond the average structure:
> 
> *   **Off-centered Atoms**: 
>     *   The **Zr** site shows evidence of a split-site configuration. The atoms are distributed between two positions along the PC1 direction ([1, 0.03, -0.02]), with a static displacement of {{r2.sites.0.delta_A}} Å ({{r2.sites.0.delta_A}}). The negative kurtosis (-0.15) and the resolved PC1 axis indicate this split-site behavior.
>     *   The **Ca** site also shows significant anisotropy (anisotropy = 1.39) and a negative kurtosis (-0.137), though no distinct split-site displacement was measured.
> *   **Distorted Polyhedra**: The **Zr–O octahedra** in the configuration are distorted compared to the ideal average structure. While the average structure is perfectly regular, the configuration shows a mean Baur's distortion index (DI) of {{r3.distortion_index.mean}} Å ({{r3.distortion_index.mean}}) and a mean quadratic elongation ($\langle\lambda\rangle$) of {{r3.quadratic_elongation.mean}} ({{r3.quadratic_elongation.mean}}).
> *   **Correlated Displacements**: There is no evidence of a crystallographic superstructure (no zone-boundary points show significant power). However, there is a strong long-wavelength displacement correlation for **Ca** a
> … [808 more characters in the JSON record]

- Evidence gate, round 5: The answer concluded a lowering of the average structure without measure_symmetry_lowering; the app asked for it first.

Stopped by: answer · rounds: 5 · outcome (computed): not verified · against the score: held

Why: 3 checks below contradict the answer; a number it cites by reference names no value the analyses returned. The local structure shows Zr off-centering and Ca-displacement correlations, but no evidence for symmetry lowering was found.

> No analysis run in this turn provided evidence for a lowering of the average structure's symmetry (e.g., via `measure_symmetry_lowering`). However, the following local distortions and correlations were identified:
> 
> * **Off-centered Atoms**: The **Zr** site shows evidence of a split-site configuration. The atoms are distributed between two positions along the PC1 direction ([1, 0.03, -0.02]), with a static displacement of 0.0857 Å (0.0857).
> * **Distorted Polyhedra**: The **Zr–O** octahedra in the configuration are distorted compared to the ideal average structure. The configuration shows a mean Baur's distortion index (DI) of {{r3.distortion_index.mean}} Å ({{r3.distortion_index.mean}}).
> * **Correlated Displacements**: There is a strong long-wavelength displacement correlation for **Ca** at $q = (0, 0.125, 0)$, with a power 110 times the median background ({{r4.strongest.0.ratio}}). This indicates box-scale displacement correlations rather than a crystallographic superstructure.
> * **Anisotropic Motion**: The **Ca** site exhibits significant anisotropy (anisotropy = 1.39).
> 
> The average structure belongs to the space group **Pm-3m (No. 221)**, which is **centrosymmetric**, **achiral**, and **non-polar**.
> 
> VERDICT {"features": [{"kind": "off_centre", "element": "Zr", "direction_uvw": [1, 0.03, -0.02], "magnitude_A": 0.0857, "q": null}, {"kind": "modulation", "element": "Ca", "direction_uvance": null, "magnitude_A": null, "q": [0, 0.125, 0]}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}
> 
> Outcome: The local structure shows Zr off-centering and Ca-displacement correlations, but no evidence for symmetry lowering was found.

Numbers by reference: 4 of 7 filled from the analyses; not filled: {{r3.distortion_index.mean}}, {{r4.strongest.0.ratio}}.

<details><summary>The answer as the model wrote it</summary>

> No analysis run in this turn provided evidence for a lowering of the average structure's symmetry (e.g., via `measure_symmetry_lowering`). However, the following local distortions and correlations were identified:
> 
> * **Off-centered Atoms**: The **Zr** site shows evidence of a split-site configuration. The atoms are distributed between two positions along the PC1 direction ([1, 0.03, -0.02]), with a static displacement of {{r2.sites.0.delta_A}} Å ({{r2.sites.0.delta_A}}).
> * **Distorted Polyhedra**: The **Zr–O** octahedra in the configuration are distorted compared to the ideal average structure. The configuration shows a mean Baur's distortion index (DI) of {{r3.distortion_index.mean}} Å ({{r3.distortion_index.mean}}).
> * **Correlated Displacements**: There is a strong long-wavelength displacement correlation for **Ca** at $q = (0, 0.125, 0)$, with a power 110 times the median background ({{r4.strongest.0.ratio}}). This indicates box-scale displacement correlations rather than a crystallographic superstructure.
> * **Anisotropic Motion**: The **Ca** site exhibits significant anisotropy (anisotropy = {{r1.sites.0.anisotropy}}).
> 
> The average structure belongs to the space group **Pm-3m (No. 221)**, which is **centrosymmetric**, **achiral**, and **non-polar**.
> 
> VERDICT {"features": [{"kind": "off_centre", "element": "Zr", "direction_uvw": [1, 0.03, -0.02], "magnitude_A": {{r2.sites.0.delta_A}}, "q": null}, {"kind": "modulation", "element": "Ca", "direction_uvance": null, "magnitude_A": null, "q": [0, 0.125, 0]}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}
> 
> Outcome: The local structure shows Zr off-centering and Ca-displacement correlations, but no evidence for symmetry lowering was found.

</details>

## Verdict and score

```json
{
 "features": [
  {
   "kind": "off_centre",
   "element": "Zr",
   "direction_uvw": [
    1,
    0.03,
    -0.02
   ],
   "magnitude_A": 0.0857
  },
  {
   "kind": "modulation",
   "element": "Ca",
   "q": [
    0,
    0.125,
    0
   ]
  }
 ],
 "space_group": "Pm-3m",
 "chiral": false,
 "centrosymmetric": true,
 "polar": false
}
```

| Item | Result |
| --- | --- |
| planted modulation (Zr) | missed |
| spurious claims | off_centre (Zr), modulation (Ca) |
| space_group | right |
| chiral | right |
| centrosymmetric | right |
| polar | right |
| **case score** | **0.6667**  |

## Answer checks

- Findings under the answer: disorder: The answer calls site 2 (Zr, split) disorder, but analyze_modulations has not run for Zr in this question: ordered antiphase displacements (a superstructure) give a site the same split cloud as random disorder, and only the correlation between cells tells them apart. · superstructure: The answer claims a superstructure, but no analyze_modulations of this question found order between cells (no zone-boundary point or general wavevector beyond the independent-displacement background after the correction). · long-wave: The answer claims order at a long (box-scale) wave, but a long wave is a correlation the finite box can't represent, so it says nothing about order at its own q; a point or mode that passes its own test at another q is judged on that test alone. · reference: The answer cites {{r3.distortion_index.mean}}, {{r4.strongest.0.ratio}}, which name no value this question's analyses returned: those numbers are missing.
- Contradictions in the verdict a check covers: caught spurious modulation (Ca); missed spurious off_centre (Zr)
- Findings with no matching contradiction in the verdict: disorder, long-wave, reference

## Numbers in the answer

6 of 6 checkable numbers match a value the model was shown.

| Number | In the answer | Source |
| --- | --- | --- |
| 0.03 | positions along the PC1 direction ([1, 0.03, -0.02]), with a st | tool list_sites (call_f7ujda2y#2) data.sites[0].pc1_uvw[1] |
| -0.02 | ions along the PC1 direction ([1, 0.03, -0.02]), with a static di | tool list_sites (call_f7ujda2y#2) data.sites[0].pc1_uvw[2] |
| 0.0857 Å | -0.02]), with a static displacement of 0.0857 Å (0.0857). * **Disto | tool list_sites (call_f7ujda2y#2) data.sites[0].delta_A |
| 0.0857 | with a static displacement of 0.0857 Å (0.0857). * **Distorted Pol | tool list_sites (call_f7ujda2y#2) data.sites[0].delta_A |
| 0.125 | ment correlation for **Ca** at $q = (0, 0.125, 0)$, with a power | tool analyze_modulations (call_kup3979g#5) data.elements[0].strongest[0][0] |
| 1.39 | ts significant anisotropy (anisotropy = 1.39). The average stru | tool list_sites (call_8k98pljt#1) data.sites[0].anisotropy |

## Safety

- Unsafe actions: 0
- Unknown-tool calls: 0 · failed calls: 1 · questions to the user: 0 (all skipped by the simulated user)
- Skills read: none

## Planted truth (never shown to the model)

Zr displaced ±0.09 Å along [1 0 0] in an ordered pattern with q = (0.5, 0.5, 0.5) (a superstructure the folded average cannot show); Ca carries a stronger box-scale wave at q = (0, 0.125, 0) as a decoy

```json
{
 "features": [
  {
   "kind": "modulation",
   "element": "Zr",
   "accept": [
    "modulation"
   ],
   "q": [
    0.5,
    0.5,
    0.5
   ],
   "direction_uvw": [
    1,
    0,
    0
   ],
   "direction_mode": "axis"
  }
 ],
 "tolerated": [],
 "symmetry": {
  "space_group": "Pm-3m",
  "chiral": false,
  "centrosymmetric": true,
  "polar": false,
  "primary": false
 }
}
```

Traps in this case:
- Zr's folded cloud is split ±0.09 Å like two-site disorder: only the cell-to-cell correlation (analyze_modulations) shows it is ordered
- Ca's strongest mode is a long wave at the box scale, not a crystallographic superstructure
