# test-symmetry-lowering__B__claude-sonnet-5.5__r2

- Case: `test-symmetry-lowering` (test set) · Arm B: Copilot with skills and guardrails
- Model: Claude Sonnet 5.5 (API) (`claude-sonnet-5-5`, no temperature sent) · run 2
- Protocol 2026-11-01.1 · commit 472d9bdab1cabb1152a6f49691b55d1d49eb0ffe · 2026-11-07T10:29:57.906Z → 2026-11-07T10:30:48.117Z (50 s)
- Server: an OpenAI-compatible server (cloud or other) · context window: the provider's own (not probed)
- Reply cap: max_tokens 8192 in every request (thinking counts within it) · final round: tool_choice "none", tools still sent
- Temperature not sent (the model's default sampling; a request asked again after a loop is sent without one too) · limits: 6 rounds × 4 calls, 600 s a turn, results 3,000 / turn 12,000 characters, 2 questions, 2 gate send-backs
- Context guard: refuses a request that would not fit, never cuts it (2.5 characters a token, 1.4 for tool JSON; 8,192-token reply reserve) · spend cap $20
- Tools offered: read_run_data, find_gr_peaks, list_sites, analyze_displacement_directions, compute_bond_angles, polyhedral_distortion, analyze_clusters, analyze_modulations, detect_symmetry, measure_symmetry_lowering, ask_user, read_skill
- Skills offered: coordination-shells, displacement-anisotropy, local-order, local-symmetry, rmc-fit-assessment
- View: Detected SG at 0.2 Å with its ladder, nothing hidden, no PCA table, Live Data off
- Context sections: structure, symmetry, pair_correlations, datasets (absent: configuration_optimization, run_settings, pca_displacements, partial_weights, convergence) · one fresh question, no earlier turns

## Step 0 · the question

> Analyse the local structure of this RMC configuration. Is there order or distortion beyond the average structure (off-centred atoms, correlated clusters, a superstructure, distorted polyhedra)? What is the average structure's space group, and is it chiral, centrosymmetric, polar? Base every claim on the Workbench's analyses, and say so plainly if there is no such order.
> 
> Finish with one line that starts with VERDICT and holds a JSON object, after everything else (the Outcome line included):
> VERDICT {"features": [{"kind": "...", "element": "...", "direction_uvw": [u, v, w] or null, "magnitude_A": number or null, "q": [h, k, l] or null}], "space_group": "..." or null, "chiral": true/false/null, "centrosymmetric": true/false/null, "polar": true/false/null}
> kind is one of off_centre, modulation, cluster_distortion, cluster_breathing, rigid_cluster, jahn_teller, symmetry_lowering. features is [] when there is no order beyond thermal motion. direction_uvw is a crystal direction; magnitude_A the static displacement (off_centre, symmetry_lowering) or the long minus short bond (jahn_teller); q in reciprocal-lattice units. Use null for what you did not determine. A number may be a reference to a tool result, as in the answer ("magnitude_A": {{r3.sites.0.shift_A}}): the app fills it in; a text reference goes inside its quotes ("element": "{{r3.sites.0.element}}").

## Step 1 · ask_user (asked by the Workbench) · round 0

*the Workbench's own question (clarify.js)*

**Arguments:** `{"question":"Which tolerance? Several groups hold above the sampling noise floor.","options":[{"label":"Pm-3m","description":"holds from 0.09 to 1 Å"},{"label":"P-43m","description":"holds from 0.076 to 0.09 Å"},{"label":"R3m","description":"holds from 0.027 to 0.076 Å"}],"default":"Pm-3m"}` · status ok · 0 ms

**What the model read of it:** (The Workbench asked: "Which tolerance? Several groups hold above the sampling noise floor." — the user chose Pm-3m, which holds from 0.09 to 1 Å; report it with that tolerance range. (The user skipped the question; this is the default.))

**The card's checks (not sent to the model):**

- note: The user skipped the question: use your default, "Pm-3m", and say in the answer that you assumed it.

<details><summary>The card's reply (not sent to the model)</summary>

```json
{
 "question": "Which tolerance? Several groups hold above the sampling noise floor.",
 "answer": "Pm-3m",
 "skipped": true,
 "means": "holds from 0.09 to 1 Å"
}
```

</details>

## Step 2 · read_skill · round 1

**Model text before the call:**

> I'll start by reading the local-order skill.

**Arguments:** `{"name":"local-order"}` · status ok · 0.08825000002980232 ms

<details><summary>Result the model read</summary>

```json
{
 "skill": "local-order",
 "text": "# Local order: when to say \"no order\"\n\n**Status: Interviewed 2026-10-24.** The steps are the user's own answers of that day\n(docs/SKILL_INTERVIEWS.md §5).\n\nEach kind of local order hides from every analysis but one or two. The average structure folds the\nsupercell into one cell; each site's displacement cloud is centred on its own mean; an RMC\nconfiguration that the data did not shape looks like independent atoms. So one empty analysis\nsays nothing about the others: \"no order\" is the conclusion that every test the Workbench has came\nback empty. What was not run is \"not tested\", never \"absent\".\n\n## Steps\n\n1. **Sites:** `list_sites`. Note the split sites (two positions, by the app's rule: a resolved\n   PC1 whose excess kurtosis is ≤ −0.5 and at least 3 sampling errors below zero; `list_sites`\n   gives them a `delta_A`), the other sites with negative kurtosis (flat-topped), large positive\n   kurtosis (heavy tails, an anharmonic well) or large anisotropy.\n2. **Directions, per site:** `analyze_displacement_directions` with `site_ref` for every\n   symmetry-inequivalent site (one per orbit), not only those whose kurtosis or anisotropy stands\n   out; never pooled over sites whose local frames differ. Empty means no peak at ≥ 3σ. A\n   significant map or tensor test alone is anisotropy, which thermal ellipsoids have: it is not\n   order.\n3. **Order between cells:** `analyze_modulations` (every element). Empty means no zone-boundary\n   point and no general wavevector called ordered, and no diffuse short-range order: the diffuse\n   verdict, when it passes its calibrated bar, counts as order between cells. A long wave (every\n   |q_i| ≤ 0.25) is a box-scale correlation, not order. A split site whose element has an ordered\n   point is order with that q (a superstructure), not random disorder.\n4. **Clusters:** for every element whose own first shell is closed and holds 0.5–4.5 neighbours of\n   its own kind (`find_gr_peaks` on the A–A pair: a dimer 1, a trimer 2, a tetrahedron 3, an\n   octahedron 4 per member), `analyze_clusters` in its `first_shell.window_A`.\n   Empty means no shape distortion or pattern beyond independent atoms at the clusters' own size,\n   no breathing, no rigidity, and a regular average cluster. An extended network (the tool says\n   so) has no clusters to test: test its polyhedra with `polyhedral_distortion` (Baur's DI and\n   Robinson's indices, against the average structure's polyhedra).\n5. **Polyhedra:** `find_gr_peaks` for each bonded pair: the whole first shell's CN and peaks against\n   the average structure. A split shell the average structure does not explain is a distorted\n   polyhedron (coordination-shells); a split explained by a split centre site is that site's\n   disorder (step 1–3). A partial under 5 % of the signal is \"not constrained by the data\": say\n   so, and leave it out of the conclusion.\n6. **Average structure:** the context's ladder and noise floor. Empty means the group of the lowest\n   rung clearly above the noise floor (from 1.25 × `noise_floor_A`) is the card's group, or\n   `measure_symmetry_lowering` finds no site shifted above the noise floor (local-symmetry).\n7. **Conclude.** \"No order beyond thermal motion\" only when steps 2–6 all came back empty; name\n   each analysis and its result, and the partials left out as not constrained by the data. When a\n   test could not run (too few points per sphere cell, a zone-boundary point an odd supercell axis\n   cannot hold), say \"no order found in the tests that could run; ⟨test⟩ not tested because\n   ⟨reason⟩\": never a bare \"no order\". When one found order, report that order: the analysis, the\n   statistic, its effect size and σ.\n\n## Acceptance checklist\n\n- [ ] Every analysis of steps 2–6 ran, or the answer names what was not tested and why.\n- [ ] Directions for every symmetry-inequivalent site, not pooled; anisotropy not called order.\n- [ ] Split sites read against `analyze_modulations` before they are called disorder.\n- [ ] Clusters tested for every element with a finite same-element shell; an extended network's\n      polyhedra with `polyhedral_distortion`.\n- [ ] Order between cells at the zone boundary, at general wavevectors and in the diffuse\n      verdict; no long wave called order.\n- [ ] The average structure's group read above the noise floor.\n- [ ] A partial the data barely weight (step 5) reported as \"not constrained by the data\" and\n      left out of the conclusion.\n- [ ] Never a bare \"no order\": a test that could not run is named with its reason.\n- [ ] No literature expectation used as evidence either way.\n\n## Known failure modes\n\n- **The literature for the data** (validation, the thermal-null dev case): a perovskite whose\n  composition is known for off-centred B cations, thermal motion only in the configuration. The\n  answer is \"no order\"; its O ellipsoids are anisotropic (map 7.2σ, peak 2.3σ), which is not order.\n- **\"No order\" from the pages alone** (validation arm A, the breathing dev case): no page shows a\n  cluster's breathing; `analyze_clusters` finds it at z = 22.\n- **Order called disorder** (validation arm A, the zone-boundary dev case): ordered antiphase Ti\n  displacements give the same split cloud as random off-centring; only `analyze_modulations` tells\n  them apart.\n- *Firm rule in the app:* an answer that claims a superstructure, a cluster distortion, breathing,\n  rigidity or a preferred direction that the question's analyses did not find gets a warning under\n  it; and an answer that concludes \"no order\" before the superstructure test, a per-site direction\n  map and the cluster analyses ran is sent back to run them (the evidence gate, THY-18).\n- **\"No order\" before the whole list ran.** *Firm rule in the app:* an answer that concludes \"no\n  order\" is refused until every applicable analysis of steps 2–6 has run, the diffuse verdict and\n  `polyhedral_distortion` included (the evidence gate, extended).\n\n## Report\n\nEach analysis with its result (statistic, effect size, σ); the order found, or \"none at ≥ 3σ\";\nwhat was not tested and why (\"⟨test⟩ not tested because ⟨reason⟩\"); the partials not constrained\nby the data; the average structure's group above the noise floor.\n\nReferences (read one with read_skill and `reference`):\n- order-signatures: how each kind of order shows, and hides, in each analysis, with the dev cases' numbers."
}
```

</details>

## Step 3 · read_skill · round 1

**Model text before the call:**

> I'll start by reading the local-order skill.

**Arguments:** `{"name":"local-symmetry"}` · status ok · 0.041250000009313226 ms

<details><summary>Result the model read</summary>

```json
{
 "skill": "local-symmetry",
 "text": "# Local symmetry: the tolerance ladder\n\n**Status: Interviewed 2026-10-24.** The steps are the user's own answers of that day\n(docs/SKILL_INTERVIEWS.md §3).\n\nThe finder analyses the **average** structure: the configuration folded into one cell, each\nreference site at its mean position. It says nothing directly about local distortions, which\naverage out: those are the displacement and cluster analyses' job.\n\n## Steps\n\n1. **Read the ladder** in the context (`symmetry.ladder`): each rung is the group that holds\n   from one tolerance (Å, the largest position mismatch allowed) to the next. Loose tolerances\n   give high symmetry; tighter ones lower it. Note `noise_floor_A`: the site means carry\n   sampling noise (rms displacement / √copies), so a change of group below that tolerance is\n   noise, not a distortion.\n2. **At a tolerance the ladder does not show**, call `detect_symmetry` with `tolerance_A`. It\n   reports the group, its number, its point group with the point group's facts (centrosymmetric,\n   Sohncke, polar, crystal system), the operations and the Wyckoff orbits.\n3. **What breaks between two groups.** Describe a lowering as the operations lost (a three-fold\n   axis means cubic is lost; a lattice centring halves or quarters the cell's translations), plus\n   the group–subgroup index and its type, t (translationengleiche) or k (klassengleiche); give\n   irreps only on request. No Workbench tool states the index or the type yet: work them out from\n   the two groups' operations, which `detect_symmetry` lists. Take inversion, chirality and\n   polarity from the point-group facts, never from memory: a change that lowers the symmetry\n   cannot \"lose\" an inversion centre the higher group never had.\n4. **Is the change real?** A rung below `noise_floor_A` is within the noise of the site means. A\n   rung at or above 1.25 × `noise_floor_A` (the app's margin) is a distortion of the average\n   structure; say how large (the tolerance at which it appears). A rung between the floor and\n   1.25 × it is \"at the limit of the sampling: neither a distortion nor ruled out\", never a\n   lowering. Against a published low-temperature phase whose doubled cell the box can't hold,\n   compare only the part the box can represent (the t-subgroup or the point group), and say that\n   the box can neither confirm nor rule out the cell-doubled phase.\n5. **The group to report.** \"The\" group is the lowest rung at or above 1.25 × `noise_floor_A`,\n   with the Detected SG card's 0.2 Å group beside it when they differ: the card's default can\n   hide a real lowering (a 0.07 Å polar shift of every Ta reads Pm-3m at 0.2 Å, P4mm above the\n   0.026 Å floor). When they differ, size the lowering with `measure_symmetry_lowering`: which\n   sites move from the parent positions, by how much (Å), along which direction, against the\n   noise floor. That shift is shared by every copy of the site, so the displacement analyses\n   cannot see it. Name a group as \"consistent with ⟨group⟩ at ⟨tolerance⟩ Å\", never \"the\n   structure is ⟨group⟩\"; with no space-group number, give the point group and the crystal class.\n6. **Local versus average.** A cubic average with locally distorted clusters is possible and\n   common: for local distortion, use `analyze_clusters` and the displacement analyses, not the\n   ladder.\n7. **A lower-symmetry CIF** (the Detected SG card's export) only for a rung at or above 1.25 ×\n   `noise_floor_A`. First check that the model reproduces the site means within the rung's\n   tolerance, and that its Wyckoff sites and occupancies make sense. Label it \"average-structure\n   model of an RMC configuration\", never a refined structure.\n\n## Point-group facts (what the tools report)\n\n- **Centrosymmetric** (an inversion centre): -1, 2/m, mmm, 4/m, 4/mmm, -3, -3m, 6/m, 6/mmm, m-3,\n  m-3m. Every other point group has none.\n- **Sohncke** (proper rotations only; only these allow a chiral structure): 1, 2, 222, 4, 422, 3,\n  32, 6, 622, 23, 432. Any group with a mirror, a glide, -1 or a -4/-3/-6 axis is achiral.\n- **Polar** (a direction no operation reverses): 1, 2, m, mm2, 4, 4mm, 3, 3m, 6, 6mm.\n- So F-43m (-43m) and P-42₁m (-42m) are both non-centrosymmetric, achiral and non-polar; P2₁3\n  (23) and P2₁2₁2₁ (222) are Sohncke groups, non-centrosymmetric and non-polar.\n\n## Acceptance checklist\n\n- [ ] Each group is named \"consistent with ⟨group⟩ at ⟨tolerance⟩ Å\", with its number when the\n      card gives one, else its point group and crystal class.\n- [ ] What changes between rungs is stated as lost operations, with the group–subgroup index and\n      its type (t or k).\n- [ ] Inversion, chirality and polarity come from the point-group facts the tools report.\n- [ ] Rungs below the noise floor are called noise; a rung between the floor and the app's margin\n      is \"at the limit of the sampling\", never a lowering.\n- [ ] The group reported is the lowest rung at or above the margin, with the card's group beside\n      it when it differs; a lowering is sized with `measure_symmetry_lowering`.\n- [ ] Against a published cell-doubled phase the box can't hold, only the part the box can\n      represent is compared, and the phase is neither confirmed nor ruled out.\n- [ ] The average structure is not used as evidence for or against a local distortion.\n\n## Known failure modes\n\n- **\"P-42₁m is chiral and centrosymmetry is lost\"** (spot check, qwen3.8-27b on LM Studio):\n  F-43m has no inversion centre to lose, and P-42₁m (-42m) contains improper operations, so it\n  is achiral. *Firm rule in the app:* `detect_symmetry` and the context's ladder state the point\n  groups' facts, and an answer that calls a group chiral, centrosymmetric or polar against them,\n  or says an inversion centre is lost from a group without one, gets a warning under it.\n- **Lower rungs read as symmetry breaking** (review): the Demo's P-42₁m … P1 rungs lie below the\n  0.031 Å noise floor; the average structure is consistent with F-43m.\n- **The 0.2 Å card read as the group** (validation arm A, the symmetry-lowering dev case): every Ta\n  shifted 0.07 Å along [001] lies inside the card's tolerance, so the card says Pm-3m — the wrong\n  group, called centrosymmetric and non-polar. The ladder and the noise floor show P4mm, and\n  `measure_symmetry_lowering` gives Ta 0.065 Å along [0 0 1].\n- **A group–subgroup relation that doesn't hold.** *Firm rule in the app:* an answer that claims a\n  group–subgroup relation that doesn't hold gets a warning under it.\n- **A cell doubling the box can't support.** *Firm rule in the app:* an answer that claims a cell\n  doubling the box's average structure can't support gets a warning under it.\n\n## Report\n\nThe group at the tolerance asked, as \"consistent with ⟨group⟩ at ⟨tolerance⟩ Å\" (with the ladder\naround it); what changes between the rungs asked about, as operations lost with the index and its\ntype; which changes clear the app's margin and which are only at the limit of the sampling; the\npoint-group facts that matter for the question; and, for local questions, the analyses that can\nanswer them.\n\nReferences (read one with read_skill and `reference`):\n- lacunar-spinel-symmetry: the Demo's ladder and the published phases of GaTa₄Se₈ and GaNb₄Se₈ with their point groups."
}
```

</details>

## Step 4 · list_sites · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{}` · status ok · 2.887500000069849 ms

**Checks the model read:**

- ok: 5 sites, 2560 atoms.

<details><summary>Result the model read</summary>

```json
{
 "note": "kurtosis = Mardia multivariate excess kurtosis (0 Gaussian; >0 peaked/heavy-tailed; <0 flat or split); kurtosis_axes = excess kurtosis along PC1, PC2, PC3, null where that axis is not resolved (its direction is noise); anisotropy = rms1/rms3; sites sorted by |kurtosis|, largest first",
 "n_sites": 5,
 "total_atoms": 2560,
 "largest_U_iso_refs": [
  5,
  4,
  1
 ],
 "largest_abs_kurtosis_refs": [
  2,
  4,
  3
 ],
 "most_anisotropic_refs": [
  5,
  4,
  3
 ],
 "sites": [
  {
   "ref": 2,
   "site": "Ti",
   "count": 512,
   "U_iso_A2": 0.00338,
   "rms_axes_A": [
    0.06,
    0.0593,
    0.0549
   ],
   "anisotropy": 1.09,
   "kurtosis": -0.0791
  },
  {
   "ref": 4,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00649,
   "rms_axes_A": [
    0.0949,
    0.0898,
    0.0489
   ],
   "anisotropy": 1.94,
   "kurtosis": -0.0401,
   "kurtosis_axes": [
    null,
    null,
    -0.0757
   ]
  },
  {
   "ref": 3,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00605,
   "rms_axes_A": [
    0.0896,
    0.0876,
    0.0497
   ],
   "anisotropy": 1.8,
   "kurtosis": -0.0328,
   "kurtosis_axes": [
    null,
    null,
    -0.0761
   ]
  },
  {
   "ref": 1,
   "site": "Ca",
   "count": 512,
   "U_iso_A2": 0.00639,
   "rms_axes_A": [
    0.0833,
    0.0798,
    0.0766
   ],
   "anisotropy": 1.09,
   "kurtosis": -0.0163
  },
  {
   "ref": 5,
   "site": "O",
   "count": 512,
   "U_iso_A2": 0.00678,
   "rms_axes_A": [
    0.0983,
    0.0908,
    0.0493
   ],
   "anisotropy": 1.99,
   "kurtosis": -0.00709,
   "kurtosis_axes": [
    null,
    null,
    -0.00948
   ]
  }
 ]
}
```

</details>

## Step 5 · analyze_modulations · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{}` · status ok · 12.09091700008139 ms

**Checks the model read:**

- ok: No order that doubles the cell: no zone-boundary point stands out of the diffuse background (the strongest, Ti at (0, ½, 0), is 3.8× the median, 0.42σ after the correction).

<details><summary>Result the model read</summary>

```json
{
 "note": "zone_boundary rows are [q, ratio, percentile, sigma]: an element's displacement power at wavevector q (fractions of the cell's reciprocal axes) over its median across all q of the supercell grid (the diffuse background), the share of the compared modes (one per ±q pair, long waves with every |q_i| ≤ 0.25 left out) with less power, and the calibrated one-sided significance against independent cells (each cell's own correlations kept), corrected over all 21 zone-boundary points of the configuration's 3 elements, whichever the call names (≥ 3 with ratio ≥ 3 is order). strongest rows are [q, ratio, percentile, sigma]: the sigma of a general q (neither zone boundary nor long wave; a complex sum, corrected over the compared modes of every element), null otherwise. A ½ component is order that doubles the cell along that axis; order at a general q is correlation between cells (incommensurate or short-range) that does not. diffuse is [lag, correlation, sigma]: the strongest correlation between a site's displacements in cells one lag apart that the power over the compared modes shows (+ in phase, − antiphase), and the significance of the 13 neighbour-cell lags together against independent cells (≥ 3 with |correlation| ≥ 0.1: correlation spread over many q).",
 "supercell": [
  8,
  8,
  8
 ],
 "wavevectors": 511,
 "elements": [
  {
   "element": "Ca",
   "sites": 1,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     2.95,
     96.4,
     -0.5
    ],
    [
     "(0, ½, 0)",
     1,
     50.3,
     -4.5
    ],
    [
     "(0, ½, ½)",
     0.47,
     14.7,
     -7.3
    ],
    [
     "(½, 0, 0)",
     0.14,
     0,
     null
    ],
    [
     "(½, 0, ½)",
     1.5,
     71.1,
     -3
    ],
    [
     "(½, ½, 0)",
     3.4,
     97.5,
     -0.1
    ],
    [
     "(½, ½, ½)",
     3.7,
     98.5,
     0.2
    ]
   ],
   "strongest": [
    [
     "(0.25, 0.375, -0.375)",
     4.2,
     99.5,
     -0.3
    ],
    [
     "(0.25, -0.125, 0.375)",
     3.7,
     99,
     -1.5
    ],
    [
     "(½, ½, ½)",
     3.7,
     98.5,
     null
    ]
   ],
   "diffuse": [
    "[0 1 1]",
    0.16,
    -0.2
   ]
  },
  {
   "element": "O",
   "sites": 3,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     0.95,
     44.7,
     -4.9
    ],
    [
     "(0, ½, 0)",
     1.3,
     74.1,
     -3
    ],
    [
     "(0, ½, ½)",
     0.84,
     34,
     -5.6
    ],
    [
     "(½, 0, 0)",
     0.77,
     24.9,
     -6.2
    ],
    [
     "(½, 0, ½)",
     0.77,
     25.4,
     -6.2
    ],
    [
     "(½, ½, 0)",
     1.7,
     92.4,
     -1.4
    ],
    [
     "(½, ½, ½)",
     1.9,
     95.9,
     -0.7
    ]
   ],
   "strongest": [
    [
     "(0.25, -0.125, 0.375)",
     2.4,
     99.5,
     -1.3
    ],
    [
     "(0.375, 0.25, -0.375)",
     2.3,
     99,
     -1.6
    ],
    [
     "(½, ½, 0.125)",
     2.3,
     98.5,
     -1.8
    ]
   ],
   "diffuse": [
    "[0 0 1]",
    0.079,
    -2.8
   ]
  },
  {
   "element": "Ti",
   "sites": 1,
   "zone_boundary": [
    [
     "(0, 0, ½)",
     1.6,
     77.7,
     -2.7
    ],
    [
     "(0, ½, 0)",
     3.8,
     99.5,
     0.4
    ],
    [
     "(0, ½, ½)",
     0.29,
     5.6,
     null
    ],
    [
     "(½, 0, 0)",
     0.097,
     0.5,
     null
    ],
    [
     "(½, 0, ½)",
     1.1,
     53.8,
     -4.2
    ],
    [
     "(½, ½, 0)",
     0.79,
     34.5,
     -5.4
    ],
    [
     "(½, ½, ½)",
     0.23,
     2.5,
     null
    ]
   ],
   "strongest": [
    [
     "(0, ½, 0)",
     3.8,
     99.5,
     null
    ],
    [
     "(½, 0.25, 0.375)",
     3.4,
     99,
     -2.1
    ],
    [
     "(0.375, 0.375, -0.375)",
     3.1,
     98.5,
     -3.1
    ]
   ],
   "diffuse": [
    "[1 0 0]",
    -0.053,
    -2
   ]
  }
 ]
}
```

</details>

## Step 6 · measure_symmetry_lowering · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{}` · status ok · 32.821624999982305 ms

**Checks the model read:**

- ok: Ti shifted 0.055 Å along [1 1 1] (3° off) from the Pm-3m positions (site 2; noise floor 0.027 Å) (the lower group R3m at 0.033 Å): a coherent shift every copy shares, a static distortion of the average structure.
- note: Pm-3m → R3m loses the inversion centre and becomes polar.

<details><summary>Result the model read</summary>

```json
{
 "note": "shift_A = the site mean's distance from the position the parent group puts it at, measured with the parent placed on the majority of the atoms (the origin a lowering leaves free is fixed by the geometric median of all shifts); a shift every copy of a site shares, which the displacement analyses cannot show; direction_uvw is a direct-lattice direction (±); se_A the sampling error of the site mean along it",
 "parent": {
  "tolerance_A": 0.2,
  "space_group": "Pm-3m",
  "point_group": "m-3m"
 },
 "lower": {
  "tolerance_A": 0.033,
  "space_group": "R3m",
  "point_group": "3m",
  "point_group_facts": "3m: trigonal; no inversion centre; achiral (not a Sohncke group); polar"
 },
 "noise_floor_A": 0.027,
 "sites": [
  {
   "ref": 2,
   "element": "Ti",
   "shift_A": 0.055,
   "direction_uvw": [
    0.88,
    1,
    0.93
   ],
   "nearest_low_index": {
    "uvw": [
     1,
     1,
     1
    ],
    "off_deg": 3
   },
   "se_A": 0.0025,
   "above_noise_floor": true
  },
  {
   "ref": 4,
   "element": "O",
   "shift_A": 0.005,
   "direction_uvw": [
    -0.65,
    -1,
    -0.14
   ],
   "nearest_low_index": {
    "uvw": [
     -1,
     -1,
     0
    ],
    "off_deg": 13.9
   },
   "se_A": 0.0028,
   "above_noise_floor": false
  },
  {
   "ref": 3,
   "element": "O",
   "shift_A": 0.003,
   "direction_uvw": [
    -0.39,
    -0.66,
    -1
   ],
   "se_A": 0.003,
   "above_noise_floor": false
  },
  {
   "ref": 5,
   "element": "O",
   "shift_A": 0.002,
   "direction_uvw": [
    -0.66,
    1,
    -0.22
   ],
   "se_A": 0.0036,
   "above_noise_floor": false
  },
  {
   "ref": 1,
   "element": "Ca",
   "shift_A": 0.002,
   "direction_uvw": [
    1,
    -0.1,
    0.61
   ],
   "nearest_low_index": {
    "uvw": [
     1,
     0,
     1
    ],
    "off_deg": 14.3
   },
   "se_A": 0.0035,
   "above_noise_floor": false
  }
 ]
}
```

</details>

## Step 7 · find_gr_peaks · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{"pair":"Ca-Ca"}` · status ok · 0.07220799999777228 ms

**Checks the model read:**

- note: The first shell holds 2 peaks (3.795, 3.865 Å): a split shell, e.g. two bond lengths of one distorted polyhedron. Use first_shell.window_A, not the first peak alone. The first peak alone (first_peak_only, to 3.83 Å) holds 2.58 Ca per Ca of the shell's 6.
- ok: First peak at 3.795 Å; first shell to 4.25 Å, mean 3.854 Å, CN 6 Ca per Ca.

<details><summary>Result the model read</summary>

```json
{
 "pair": "Ca-Ca",
 "r_max_A": 6,
 "peaks_A": [
  {
   "r": 3.795,
   "fwhm": 0.28
  },
  {
   "r": 3.865,
   "fwhm": 0.27
  },
  {
   "r": 5.445,
   "fwhm": 0.29
  }
 ],
 "first_shell": {
  "window_A": [
   3.49,
   4.25
  ],
  "peaks_in_shell_A": [
   3.795,
   3.865
  ],
  "mean_d_A": 3.854,
  "sd_d_A": 0.12,
  "cn": {
   "Ca_per_Ca": 6
  },
  "cn_if_cut_0p2A_earlier_later": [
   5.7,
   6
  ],
  "trough_g_fraction": 0.00029,
  "first_peak_only": {
   "window_A": [
    3.49,
    3.83
   ],
   "cn": {
    "Ca_per_Ca": 2.58
   },
   "trough_g_fraction": 0.98
  },
  "average_structure_d_A": [
   3.85,
   3.85
  ]
 }
}
```

</details>

## Step 8 · find_gr_peaks · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{"pair":"Ti-Ti"}` · status failed (skipped) · 0 ms

**Error:** skipped: at most 4 tool calls per step — call it again in the next step if it is still needed

## Step 9 · find_gr_peaks · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{"pair":"Ti-O"}` · status failed (skipped) · 0 ms

**Error:** skipped: at most 4 tool calls per step — call it again in the next step if it is still needed

## Step 10 · find_gr_peaks · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{"pair":"Ca-O"}` · status failed (skipped) · 0 ms

**Error:** skipped: at most 4 tool calls per step — call it again in the next step if it is still needed

## Step 11 · polyhedral_distortion · round 2

**Model text before the call:**

> I'll run the site, modulation, symmetry-lowering and shell analyses together, since none depends on another.

**Arguments:** `{"centre":"Ti","ligand":"O","r_min":0,"r_max":2.21}` · status failed (skipped) · 0 ms

**Error:** skipped: at most 4 tool calls per step — call it again in the next step if it is still needed

## Step 12 · find_gr_peaks · round 3

**Model text before the call:**

> Next I'll run the Ti–O shell, the TiO6 polyhedra, and the displacement directions for the Ti and Ca sites.

**Arguments:** `{"pair":"Ti-O"}` · status ok · 0.3769999999785796 ms

**Checks the model read:**

- ok: First peak at 1.925 Å; first shell to 2.21 Å, mean 1.932 Å, CN 5.99 O per Ti, 2 Ti per O.

<details><summary>Result the model read</summary>

```json
{
 "pair": "Ti-O",
 "r_max_A": 6,
 "peaks_A": [
  {
   "r": 1.925,
   "fwhm": 0.22
  },
  {
   "r": 4.305,
   "fwhm": 0.28
  },
  {
   "r": 5.785,
   "fwhm": 0.26
  }
 ],
 "first_shell": {
  "window_A": [
   1.67,
   2.21
  ],
  "peaks_in_shell_A": [
   1.925
  ],
  "mean_d_A": 1.932,
  "sd_d_A": 0.085,
  "cn": {
   "O_per_Ti": 5.99,
   "Ti_per_O": 2
  },
  "cn_if_cut_0p2A_earlier_later": [
   4.89,
   6
  ],
  "trough_g_fraction": 0.00066,
  "average_structure_d_A": [
   1.89,
   1.96
  ]
 }
}
```

</details>

## Step 13 · polyhedral_distortion · round 3

**Model text before the call:**

> Next I'll run the Ti–O shell, the TiO6 polyhedra, and the displacement directions for the Ti and Ca sites.

**Arguments:** `{"centre":"Ti","ligand":"O","r_min":0,"r_max":2.21}` · status ok · 7.989749999949709 ms

**Checks the model read:**

- ok: 511 of 512 Ti atoms have 6 O within 0–2.21 Å (octahedron): measured; the 1 with another count are left out.

<details><summary>Result the model read</summary>

```json
{
 "pair": "Ti–O (Ti central)",
 "window_A": [
  0,
  2.21
 ],
 "coordination": {
  "note": "counts[n] = Ti atoms with exactly n O in the window",
  "counts": [
   0,
   0,
   0,
   0,
   0,
   1,
   511
  ],
  "mean": 6,
  "modal": 6,
  "modal_share": 1,
  "unbonded_share": 0
 },
 "shell": {
  "note": "the first Ti–O shell (find_gr_peaks); cn, cn_in_window: O per Ti",
  "window_A": [
   1.67,
   2.21
  ],
  "cn": 5.99,
  "cn_in_window": 6,
  "holds": "whole"
 },
 "measured": {
  "coordination": 6,
  "shape": "octahedron",
  "centres": 512,
  "polyhedra": 511,
  "skipped": 1
 },
 "configuration": {
  "bond_length_A": {
   "mean": 1.932,
   "sd": 0.084
  },
  "distortion_index": {
   "mean": 0.0339,
   "sd": 0.013,
   "p10": 0.0188,
   "median": 0.0325,
   "p90": 0.0518
  },
  "quadratic_elongation": {
   "mean": 1.0091,
   "sd": 0.0042,
   "p10": 1.0045,
   "median": 1.0082,
   "p90": 1.0152
  },
  "angle_variance_deg2": {
   "mean": 25.1,
   "sd": 12,
   "p10": 11.4,
   "median": 22.8,
   "p90": 43.3
  },
  "trans_angle_deg": {
   "mean": 173,
   "sd": 2.3
  }
 },
 "average_structure": {
  "polyhedra": 1,
  "bond_ladder_A": [
   1.887,
   1.892,
   1.894,
   1.957,
   1.96,
   1.964
  ],
  "distortion_index": {
   "mean": 0.0179,
   "sd": null
  },
  "quadratic_elongation": {
   "mean": 1.0009,
   "sd": null
  },
  "angle_variance_deg2": {
   "mean": 2.05,
   "sd": null
  },
  "trans_angle_deg": {
   "mean": 177.3,
   "sd": null
  }
 }
}
```

</details>

## Step 14 · analyze_displacement_directions · round 3

**Model text before the call:**

> Next I'll run the Ti–O shell, the TiO6 polyhedra, and the displacement directions for the Ti and Ca sites.

**Arguments:** `{"site_ref":2}` · status ok · 1.3870420000748709 ms

**Checks the model read:**

- note: No preferred direction: the peak is -2.06σ, below 2.5σ: nothing to report.
- note: 2 cells tie for the peak: the peak direction is one of several equal ones.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why",
 "site": 2,
 "element": "Ti",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0.359,
  1.43
 ],
 "peak": {
  "enhancement": 1.43,
  "count": 18,
  "expected": 12.6,
  "significance_sigma": -2.06,
  "direction_cartesian": [
   -0.5,
   -0.309,
   0.809
  ],
  "direction_uvw": [
   -0.62,
   -0.38,
   1
  ],
  "angles_to_abc_deg": [
   120,
   108,
   36
  ],
  "radius_deg": 20.9,
  "tier": "none"
 },
 "map_significance_sigma": -0.783,
 "antipodal_asymmetry": 0.164,
 "antipodal_asymmetry_z": 0.116,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.356,
   0.329,
   0.315
  ],
  "anisotropy": 0.0683,
  "anisotropy_significance_sigma": -0.371,
  "principal_axis_uvw": [
   0.96,
   1,
   -0.29
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## Step 15 · analyze_displacement_directions · round 3

**Model text before the call:**

> Next I'll run the Ti–O shell, the TiO6 polyhedra, and the displacement directions for the Ti and Ca sites.

**Arguments:** `{"site_ref":1}` · status ok · 1.1351250000298023 ms

**Checks the model read:**

- note: No preferred direction: the peak is 0.35σ, below 2.5σ: nothing to report.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why",
 "site": 1,
 "element": "Ca",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0.448,
  1.79
 ],
 "peak": {
  "enhancement": 1.79,
  "count": 20,
  "expected": 11.2,
  "significance_sigma": 0.35,
  "direction_cartesian": [
   -0.851,
   0,
   0.526
  ],
  "direction_uvw": [
   -1,
   0,
   0.62
  ],
  "angles_to_abc_deg": [
   148.3,
   90,
   58.3
  ],
  "radius_deg": 19.3,
  "tier": "none"
 },
 "map_significance_sigma": 1.36,
 "antipodal_asymmetry": 0.18,
 "antipodal_asymmetry_z": 0.723,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.359,
   0.332,
   0.309
  ],
  "anisotropy": 0.0759,
  "anisotropy_significance_sigma": 0.115,
  "principal_axis_uvw": [
   1,
   0.04,
   -0.16
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## Step 16 · analyze_displacement_directions · round 4

**Model text before the call:**

> Next I'll check displacement directions for the three O sites, and the Ca–O shell.

**Arguments:** `{"site_ref":3}` · status ok · 1.4847919999156147 ms

**Checks the model read:**

- note: No preferred direction: the peak is 1.23σ, below 2.5σ: nothing to report.
- ok: The displacements are anisotropic: the map departs from isotropy at 6.66σ. Thermal ellipsoids pass this test too: it is not a preferred direction, which needs a finding of the peak test.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why",
 "site": 3,
 "element": "O",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0.179,
  1.9
 ],
 "peak": {
  "enhancement": 1.9,
  "count": 24,
  "expected": 12.6,
  "significance_sigma": 1.23,
  "direction_cartesian": [
   0,
   -1,
   0
  ],
  "direction_uvw": [
   0,
   -1,
   0
  ],
  "angles_to_abc_deg": [
   90,
   180,
   90
  ],
  "radius_deg": 20.9,
  "tier": "none"
 },
 "map_significance_sigma": 6.66,
 "antipodal_asymmetry": 0.145,
 "antipodal_asymmetry_z": -0.465,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.403,
   0.397,
   0.2
  ],
  "anisotropy": 0.21,
  "anisotropy_significance_sigma": 9.23,
  "principal_axis_uvw": [
   -0.62,
   1,
   -0.05
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## Step 17 · analyze_displacement_directions · round 4

**Model text before the call:**

> Next I'll check displacement directions for the three O sites, and the Ca–O shell.

**Arguments:** `{"site_ref":4}` · status ok · 1.0250409999862313 ms

**Checks the model read:**

- note: A hint of a direction, not a finding: the peak is 2.63σ, between 2.5σ and 3σ; toward [1 0 0.62] ± 19.3°, the cell radius at ν = 2.
- ok: The displacements are anisotropic: the map departs from isotropy at 8.34σ. Thermal ellipsoids pass this test too: it is not a preferred direction, which needs a finding of the peak test.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why",
 "site": 4,
 "element": "O",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0.0793,
  2.33
 ],
 "peak": {
  "enhancement": 2.33,
  "count": 26,
  "expected": 11.2,
  "significance_sigma": 2.63,
  "direction_cartesian": [
   0.851,
   0,
   0.526
  ],
  "direction_uvw": [
   1,
   0,
   0.62
  ],
  "angles_to_abc_deg": [
   31.7,
   90,
   58.3
  ],
  "radius_deg": 19.3,
  "tier": "hint"
 },
 "map_significance_sigma": 8.34,
 "antipodal_asymmetry": 0.148,
 "antipodal_asymmetry_z": -0.253,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.436,
   0.38,
   0.184
  ],
  "anisotropy": 0.307,
  "anisotropy_significance_sigma": 10.8,
  "principal_axis_uvw": [
   1,
   -0.01,
   -0.38
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## Step 18 · analyze_displacement_directions · round 4

**Model text before the call:**

> Next I'll check displacement directions for the three O sites, and the Ca–O shell.

**Arguments:** `{"site_ref":5}` · status ok · 0.6993340000044554 ms

**Checks the model read:**

- note: A hint of a direction, not a finding: the peak is 2.63σ, between 2.5σ and 3σ; toward [0 -0.62 -1] ± 19.3°, the cell radius at ν = 2.
- ok: The displacements are anisotropic: the map departs from isotropy at 8.22σ. Thermal ellipsoids pass this test too: it is not a preferred direction, which needs a finding of the peak test.

<details><summary>Result the model read</summary>

```json
{
 "note": "enhancement = density / isotropic (1 = isotropic); significances are calibrated one-sided sigma; the map is not antipodally folded, so +u and −u differ; [u v w] is a direct-lattice direction, not a plane normal; peak.radius_deg is the peak cell's radius: the peak names its direction only to within it; peak.tier: finding (≥ 3σ, ≥ 1.2×, held at the neighbouring resolution), hint, or none (below 2.5σ); the first check says why",
 "site": 5,
 "element": "O",
 "frequency": 2,
 "cells": 42,
 "used_points": 512,
 "rejected_points": 0,
 "enhancement_range": [
  0.238,
  2.33
 ],
 "peak": {
  "enhancement": 2.33,
  "count": 26,
  "expected": 11.2,
  "significance_sigma": 2.63,
  "direction_cartesian": [
   0,
   -0.526,
   -0.851
  ],
  "direction_uvw": [
   0,
   -0.62,
   -1
  ],
  "angles_to_abc_deg": [
   90,
   121.7,
   148.3
  ],
  "radius_deg": 19.3,
  "tier": "hint"
 },
 "map_significance_sigma": 8.22,
 "antipodal_asymmetry": 0.148,
 "antipodal_asymmetry_z": -0.247,
 "antipodal_asymmetry_significant": false,
 "orientation_tensor": {
  "eigenvalues": [
   0.435,
   0.395,
   0.17
  ],
  "anisotropy": 0.305,
  "anisotropy_significance_sigma": 11.7,
  "principal_axis_uvw": [
   0.1,
   0.66,
   1
  ]
 },
 "recommended_frequency": 2
}
```

</details>

## Step 19 · find_gr_peaks · round 4

**Model text before the call:**

> Next I'll check displacement directions for the three O sites, and the Ca–O shell.

**Arguments:** `{"pair":"Ca-O"}` · status ok · 0.16295799997169524 ms

**Checks the model read:**

- ok: First peak at 2.705 Å; first shell to 3.17 Å, mean 2.727 Å, CN 12 O per Ca, 4 Ca per O.

<details><summary>Result the model read</summary>

```json
{
 "pair": "Ca-O",
 "r_max_A": 6,
 "peaks_A": [
  {
   "r": 2.705,
   "fwhm": 0.29
  },
  {
   "r": 4.705,
   "fwhm": 0.26
  }
 ],
 "first_shell": {
  "window_A": [
   2.34,
   3.17
  ],
  "peaks_in_shell_A": [
   2.705
  ],
  "mean_d_A": 2.727,
  "sd_d_A": 0.12,
  "cn": {
   "O_per_Ca": 12,
   "Ca_per_O": 4
  },
  "cn_if_cut_0p2A_earlier_later": [
   11.7,
   12
  ],
  "trough_g_fraction": 0.00083,
  "average_structure_d_A": [
   2.72,
   2.73
  ]
 }
}
```

</details>

## The answer

*Round 4: the reference repair sent the answer below back to the model:*

> **Short answer:** I found a coherent Ti shift of 0.055 Å along [1 1 1] in the average structure. I found no superstructure, no preferred displacement direction at 3σ or more, and no finite clusters to test. At the tolerance you chose (Pm-3m, 0.09–1 Å) the group is centrosymmetric, achiral and non-polar. The Ti shift, though, is a lowering that Pm-3m does not show.
> 
> **Average structure (local-symmetry skill)**
> - I used your choice of Pm-3m (No. 221), point group m-3m, which holds from 0.09 to 1 Å. The context gives 48 operations, and the point-group facts give centrosymmetric, achiral and non-polar.
> - The ladder goes Pm-3m, then P-43m (0.076–0.09 Å), then R3m (0.0058–0.076 Å), then Cm and P1 below that.
> - The noise floor is {{ctx.symmetry.noise_floor_A}} Å, so the app's margin is about 0.034 Å (1.25 × the floor). Cm and P1 lie below the floor and are noise.
> - R3m holds across the margin, so it is the lowest rung that clears it. It is polar and non-centrosymmetric, with point group 3m.
> - `measure_symmetry_lowering` ({{r5.checks.0.text}}) gives:
>   - Ti is shifted 0.055 Å along [1 1 1], 3° off the axis, against the 0.027 Å floor.
>   - It is a coherent shift shared by every Ti copy, so the displacement maps cannot see it.
>   - Pm-3m to R3m loses the inversion centre and becomes polar.
> - The average Ti–O octahedron shows the same thing: its bond ladder is 1.887/1.892/1.894 and 1.957/1.960/1.964 Å, three short and three long ({{r8.data.average_structure.bond_ladder_A}}).
> - So the aver
> … [3579 more characters in the JSON record]

- Reference repair, round 4: The answer quoted 1 number by reference that names no value; the app asked for it again.

Stopped by: answer · rounds: 4 · outcome (computed): not verified · against the score: held

Why: 2 checks below contradict the answer. The average structure is consistent with Pm-3m at 0.09–1 Å (centrosymmetric, achiral, non-polar), but Ti shows a coherent [1 1 1] shift above the noise floor that points to a polar R3m lowering. No superstructure, no 3σ displacement direction and no clear polyhedral distortion were found.

> **Short answer:** I found a coherent Ti shift in the average structure. I found no superstructure, no preferred displacement direction at 3σ or more, and no finite clusters to test. At the tolerance you chose (Pm-3m, 0.09–1 Å) the group is centrosymmetric, achiral and non-polar. The Ti shift, though, is a lowering that Pm-3m does not show.
> 
> **Average structure (local-symmetry skill)**
> - I used your choice of Pm-3m (No. 221), point group m-3m, which holds from 0.09 to 1 Å. The context gives 48 operations, and the point-group facts give centrosymmetric, achiral and non-polar.
> - The ladder goes Pm-3m, then P-43m (0.076–0.09 Å), then R3m (0.0058–0.076 Å), then Cm and P1 below that.
> - The noise floor is 0.027 Å, so the app's margin is about 0.034 Å (1.25 × the floor). Cm and P1 lie below the floor and are noise.
> - R3m holds across the margin, so it is the lowest rung that clears it. It is polar and non-centrosymmetric, with point group 3m.
> - `measure_symmetry_lowering` gives:
>   - Ti is shifted 0.055 Å along [1 1 1], 3° off the axis, against a noise floor of 0.027 Å.
>   - It is a coherent shift shared by every Ti copy, so the displacement maps cannot see it.
>   - Pm-3m to R3m loses the inversion centre and becomes polar.
> - The average Ti–O octahedron shows the same thing: its bond ladder is 1.887/1.892/1.894 and 1.957/1.960/1.964 Å, three short and three long ([1.887, 1.892, 1.894, 1.957, 1.96, 1.964]).
> - So the average structure is consistent with Pm-3m at 0.2 Å and with R3m at 0.033 Å. The Ti shift is above the noise floor but modest.
> 
> **Tests that found nothing**
> - **Superstructure** (`analyze_modulations`, all elements, 511 wavevectors): no zone-boundary point stands out. The strongest is Ti at (0, ½, 0), at 3.8× the median background and 0.42σ.
> - **Ti displacement directions** (site 2): no preferred direction. The peak is -2.06σ and the map is -0.783σ.
> - **Ca displacement directions** (site 1): none. The peak is 0.35σ.
> - **O displacement directions** (sites 3–5):
>   - Site 3 has no peak, at 1.23σ.
>   - Sites 4 and 5 are only hints, at 2.63σ each, below the 3σ finding bar.
>   - All three O maps are anisotropic, at 6.66σ, 8.34σ and 8.22σ. That is an ellipsoid shape, which thermal motion also gives, so I do not call it order.
> - **Clusters:** `analyze_clusters` was not run. Ca–Ca and Ti–Ti each have 6 same-element neighbours per atom (6 for Ca). That is outside the 0.5–4.5 range for finite clusters, so they form an extended network. I did not run `find_gr_peaks` on Ti–Ti. I take its CN of 5.99 from the context.
> - **Ti–O octahedra** (`polyhedral_distortion`, 0–2.21 Å): 511 of 512 Ti have 6 O.
>   - Baur's distortion index is 0.0339 in the configuration, against 0.0179 in the average structure.
>   - Robinson's quadratic elongation is 1.0091, against 1.0009.
>   - The angle variance is 25.1 deg², against 2.05 deg².
>   - The octahedra are close to regular. The extra distortion over the average structure is local and thermal-sized, so I don't call it a distinct distortion.
> - **Shell structure:**
>   - The Ti–O shell is a single peak, 1.925 Å with CN 5.99.
>   - The Ca–O shell is a single peak, 2.705 Å with CN 12.
>   - The Ca–Ca shell is split (3.795 and 3.865 Å, FWHM 0.28 and 0.27 Å), but the peaks are separated by less than a FWHM and the shell mean of 3.854 Å matches the average-structure distance of 3.85 Å. I did not follow this up.
> - **Not tested:** I did not run `polyhedral_distortion` on the Ca–O cuboctahedra. I also did not check the partial weights of the Ca–Ti and Ca–Ca partials, so I leave them out of the conclusion.
> 
> **Conclusion:** The one finding is the coherent Ti shift along [1 1 1], a small polar rhombohedral (R3m) lowering of the average structure. I found no local off-centring, no cell-doubling order, and no cluster order. The reported group is Pm-3m (0.09–1 Å) as you chose, with R3m at 0.033 Å beside it.
> 
> Outcome: The average structure is consistent with Pm-3m at 0.09–1 Å (centrosymmetric, achiral, non-polar), but Ti shows a coherent [1 1 1] shift above the noise floor that points to a polar R3m lowering. No superstructure, no 3σ displacement direction and no clear polyhedral distortion were found.
> 
> VERDICT {"features": [{"kind": "symmetry_lowering", "element": "Ti", "direction_uvw": [1, 1, 1], "magnitude_A": 0.055, "q": null}], "space_group": "Pm-3m", "chiral": false, "centrosymmetric": true, "polar": false}

Numbers by reference: 23 of 23 filled from the analyses.

<details><summary>The answer as the model wrote it</summary>

> **Short answer:** I found a coherent Ti shift in the average structure. I found no superstructure, no preferred displacement direction at 3σ or more, and no finite clusters to test. At the tolerance you chose (Pm-3m, 0.09–1 Å) the group is centrosymmetric, achiral and non-polar. The Ti shift, though, is a lowering that Pm-3m does not show.
> 
> **Average structure (local-symmetry skill)**
> - I used your choice of Pm-3m (No. 221), point group m-3m, which holds from 0.09 to 1 Å. The context gives 48 operations, and the point-group facts give centrosymmetric, achiral and non-polar.
> - The ladder goes Pm-3m, then P-43m (0.076–0.09 Å), then R3m (0.0058–0.076 Å), then Cm and P1 below that.
> - The noise floor is {{ctx.symmetry.noise_floor_A}} Å, so the app's margin is about 0.034 Å (1.25 × the floor). Cm and P1 lie below the floor and are noise.
> - R3m holds across the margin, so it is the lowest rung that clears it. It is polar and non-centrosymmetric, with point group 3m.
> - `measure_symmetry_lowering` gives:
>   - Ti is shifted {{r5.sites.0.shift_A}} Å along [1 1 1], 3° off the axis, against a noise floor of {{r5.noise_floor_A}} Å.
>   - It is a coherent shift shared by every Ti copy, so the displacement maps cannot see it.
>   - Pm-3m to R3m loses the inversion centre and becomes polar.
> - The average Ti–O octahedron shows the same thing: its bond ladder is 1.887/1.892/1.894 and 1.957/1.960/1.964 Å, three short and three long ({{r8.data.average_structure.bond_ladder_A}}).
> - So the average structure is consistent with Pm-3m at 0.2 Å and with R3m at 0.033 Å. The Ti shift is above the noise floor but modest.
> 
> **Tests that found nothing**
> - **Superstructure** (`analyze_modulations`, all elements, 511 wavevectors): no zone-boundary point stands out. The strongest is Ti at (0, ½, 0), at 3.8× the median background and 0.42σ.
> - **Ti displacement directions** (site 2): no preferred direction. The peak is {{r9.data.peak.significance_sigma}}σ and the map is {{r9.data.map_significance_sigma}}σ.
> - **Ca displacement directions** (site 1): none. The peak is {{r10.data.peak.significance_sigma}}σ.
> - **O displacement directions** (sites 3–5):
>   - Site 3 has no peak, at {{r11.data.peak.significance_sigma}}σ.
>   - Sites 4 and 5 are only hints, at {{r12.data.peak.significance_sigma}}σ each, below the 3σ finding bar.
>   - All three O maps are anisotropic, at {{r11.data.map_significance_sigma}}σ, {{r12.data.map_significance_sigma}}σ and {{r13.data.map_significance_sigma}}σ. That is an ellipsoid shape, which thermal motion also gives, so I do not call it order.
> - **Clusters:** `analyze_clusters` was not run. Ca–Ca and Ti–Ti each have 6 same-element neighbours per atom ({{r6.data.first_shell.cn.Ca_per_Ca}} for Ca). That is outside the 0.5–4.5 range for finite clusters, so they form an extended network. I did not run `find_gr_peaks` on Ti–Ti. I take its CN of 5.99 from the context.
> - **Ti–O octahedra** (`polyhedral_distortion`, 0–2.21 Å): 511 of 512 Ti have 6 O.
>   - Baur's distortion index is {{r8.data.configuration.distortion_index.mean}} in the configuration, against {{r8.data.average_structure.distortion_index.mean}} in the average structure.
>   - Robinson's quadratic elongation is {{r8.data.configuration.quadratic_elongation.mean}}, against {{r8.data.average_structure.quadratic_elongation.mean}}.
>   - The angle variance is {{r8.data.configuration.angle_variance_deg2.mean}} deg², against {{r8.data.average_structure.angle_variance_deg2.mean}} deg².
>   - The octahedra are close to regular. The extra distortion over the average structure is local and thermal-sized, so I don't call it a distinct distortion.
> - **Shell structure:**
>   - The Ti–O shell is a single peak, 1.925 Å with CN {{r7.data.first_shell.cn.O_per_Ti}}.
>   - The Ca–O shell is a single peak, 2.705 Å with CN {{r14.data.first_shell.cn.O_per_Ca}}.
>   - The Ca–Ca shell is split (3.795 and 3.865 Å, FWHM 0.28 and 0.27 Å), but the peaks are separated by less than a FWHM and the shell mean of 3.854 Å matches the average-st
> … [1102 more characters in the JSON record]

</details>

## Verdict and score

```json
{
 "features": [
  {
   "kind": "symmetry_lowering",
   "element": "Ti",
   "direction_uvw": [
    1,
    1,
    1
   ],
   "magnitude_A": 0.055
  }
 ],
 "space_group": "Pm-3m",
 "chiral": false,
 "centrosymmetric": true,
 "polar": false
}
```

| Item | Result |
| --- | --- |
| planted symmetry_lowering (Ti) | found; direction off by 0.0°; magnitude 0.055 ok |
| spurious claims | none |
| space_group | wrong |
| chiral | right |
| centrosymmetric | wrong |
| polar | wrong |
| **case score** | **0.5**  |

## Answer checks

- Findings under the answer: superstructure: The answer claims a superstructure, but no analyze_modulations of this question found order between cells (no zone-boundary point or general wavevector beyond the independent-displacement background after the correction). · coordination: The answer gives O a coordination of 5.99, but its whole first shell holds 2 Ti per O in 1.67–2.21 Å (a window that cuts the shell counts fewer: say so if that window was meant).
- Contradictions in the verdict a check covers: caught none; missed called centrosymmetric
- Findings with no matching contradiction in the verdict: superstructure, coordination

## Numbers in the answer

65 of 65 checkable numbers match a value the model was shown.

| Number | In the answer | Source |
| --- | --- | --- |
| 3 σ | no preferred displacement direction at 3σ or more, and no fin | tool ask_user (app_ask_1) note |
| 0.09 | est. At the tolerance you chose (Pm-3m, 0.09–1 Å) the group is c | tool ask_user (app_ask_1) note |
| 1 Å | At the tolerance you chose (Pm-3m, 0.09–1 Å) the group is centr | tool ask_user (app_ask_1) note |
| 0.09 | 21), point group m-3m, which holds from 0.09 to 1 Å. The context | tool ask_user (app_ask_1) note |
| 1 Å | nt group m-3m, which holds from 0.09 to 1 Å. The context gives | tool ask_user (app_ask_1) note |
| 0.076 | r. - The ladder goes Pm-3m, then P-43m (0.076–0.09 Å), then R3m ( | tool list_sites (toolu_01BWyPe8zgg6WtizFBLRvxSR#3) data.sites[1].kurtosis_axes[2] |
| 0.09 Å | he ladder goes Pm-3m, then P-43m (0.076–0.09 Å), then R3m (0.0058– | tool ask_user (app_ask_1) note |
| 0.0058 | m, then P-43m (0.076–0.09 Å), then R3m (0.0058–0.076 Å), then Cm a | run context symmetry.ladder[1].holds_A[1] |
| 0.076 Å | P-43m (0.076–0.09 Å), then R3m (0.0058–0.076 Å), then Cm and P1 be | tool list_sites (toolu_01BWyPe8zgg6WtizFBLRvxSR#3) data.sites[1].kurtosis_axes[2] |
| 0.027 Å | and P1 below that. - The noise floor is 0.027 Å, so the app's margi | tool measure_symmetry_lowering (toolu_01KxoVE51vgZsWVCjhviVq2j#5) data.noise_floor_A |
| 0.034 Å | s 0.027 Å, so the app's margin is about 0.034 Å (1.25 × the floor). | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.configuration.distortion_index.mean |
| 1.25 × | , so the app's margin is about 0.034 Å (1.25 × the floor). Cm and | tool read_skill (toolu_016KMyPxmsL5gY5MDqFxhezL#1) data.text |
| 0.055 Å | etry_lowering` gives: - Ti is shifted 0.055 Å along [1 1 1], 3° o | tool list_sites (toolu_01BWyPe8zgg6WtizFBLRvxSR#3) data.sites[0].rms_axes_A[2] |
| 3 ° | - Ti is shifted 0.055 Å along [1 1 1], 3° off the axis, again | tool ask_user (app_ask_1) note |
| 0.027 Å | off the axis, against a noise floor of 0.027 Å. - It is a cohere | tool measure_symmetry_lowering (toolu_01KxoVE51vgZsWVCjhviVq2j#5) data.noise_floor_A |
| 1.887 | hows the same thing: its bond ladder is 1.887/1.892/1.894 and 1.9 | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[0] |
| 1.892 | he same thing: its bond ladder is 1.887/1.892/1.894 and 1.957/1.9 | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[1] |
| 1.894 | e thing: its bond ladder is 1.887/1.892/1.894 and 1.957/1.960/1.9 | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[2] |
| 1.957 | ts bond ladder is 1.887/1.892/1.894 and 1.957/1.960/1.964 Å, thre | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[3] |
| 1.960 | d ladder is 1.887/1.892/1.894 and 1.957/1.960/1.964 Å, three shor | tool find_gr_peaks (toolu_019TZgYjcxDDZGKJXb4cALfr#11) data.first_shell.average_structure_d_A[1] |
| 1.964 Å | er is 1.887/1.892/1.894 and 1.957/1.960/1.964 Å, three short and th | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[5] |
| 1.887 | 0/1.964 Å, three short and three long ([1.887, 1.892, 1.894, 1.95 | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[0] |
| 1.892 | Å, three short and three long ([1.887, 1.892, 1.894, 1.957, 1.96 | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[1] |
| 1.894 | ee short and three long ([1.887, 1.892, 1.894, 1.957, 1.96, 1.964 | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[2] |
| 1.957 | t and three long ([1.887, 1.892, 1.894, 1.957, 1.96, 1.964]). - S | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[3] |
| 1.96 | hree long ([1.887, 1.892, 1.894, 1.957, 1.96, 1.964]). - So the | tool find_gr_peaks (toolu_019TZgYjcxDDZGKJXb4cALfr#11) data.first_shell.average_structure_d_A[1] |
| 1.964 | ong ([1.887, 1.892, 1.894, 1.957, 1.96, 1.964]). - So the average | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.bond_ladder_A[5] |
| 0.2 Å | e structure is consistent with Pm-3m at 0.2 Å and with R3m at 0.0 | tool read_skill (toolu_016KMyPxmsL5gY5MDqFxhezL#1) data.text |
| 0.033 Å | ent with Pm-3m at 0.2 Å and with R3m at 0.033 Å. The Ti shift is ab | tool list_sites (toolu_01BWyPe8zgg6WtizFBLRvxSR#3) data.sites[2].kurtosis |
| 3.8 × | t. The strongest is Ti at (0, ½, 0), at 3.8× the median backgrou | tool analyze_modulations (toolu_01NZSnVY6sGxQms3hFSFE1hN#4) data.elements[2].zone_boundary[1][1] |
| 0.42 σ | , 0), at 3.8× the median background and 0.42σ. - **Ti displacemen | tool analyze_modulations (toolu_01NZSnVY6sGxQms3hFSFE1hN#4) check 1 |
| -2.06 σ | 2): no preferred direction. The peak is -2.06σ and the map is -0.7 | tool analyze_displacement_directions (toolu_011fYNiXkxm3UVwJJahGkF6K#13) data.peak.significance_sigma |
| -0.783 σ | tion. The peak is -2.06σ and the map is -0.783σ. - **Ca displacemen | tool analyze_displacement_directions (toolu_011fYNiXkxm3UVwJJahGkF6K#13) data.map_significance_sigma |
| 0.35 σ | irections** (site 1): none. The peak is 0.35σ. - **O displacement | tool analyze_displacement_directions (toolu_01VLNqYkkZQeLnuVPjkfCeBF#14) data.peak.significance_sigma |
| 1.23 σ | (sites 3–5): - Site 3 has no peak, at 1.23σ. - Sites 4 and 5 | tool analyze_displacement_directions (toolu_01Weumy4c43GDrTBYPjhbeRA#15) data.peak.significance_sigma |
| 2.63 σ | σ. - Sites 4 and 5 are only hints, at 2.63σ each, below the 3σ | tool analyze_displacement_directions (toolu_012SAmvruheDQ8GLttBCAVqU#16) data.peak.significance_sigma |
| 3 σ | re only hints, at 2.63σ each, below the 3σ finding bar. - Al | tool ask_user (app_ask_1) note |
| 6.66 σ | - All three O maps are anisotropic, at 6.66σ, 8.34σ and 8.22σ. T | tool analyze_displacement_directions (toolu_01Weumy4c43GDrTBYPjhbeRA#15) data.map_significance_sigma |
| 8.34 σ | three O maps are anisotropic, at 6.66σ, 8.34σ and 8.22σ. That is | tool analyze_displacement_directions (toolu_012SAmvruheDQ8GLttBCAVqU#16) data.map_significance_sigma |
| 8.22 σ | ps are anisotropic, at 6.66σ, 8.34σ and 8.22σ. That is an ellipso | tool analyze_displacement_directions (toolu_01VWC4NovdKnn1pTWHEKg1J2#17) data.map_significance_sigma |
| 0.5 | er atom (6 for Ca). That is outside the 0.5–4.5 range for finit | tool read_skill (toolu_016KMyPxmsL5gY5MDqFxhezL#1) data.text |
| 4.5 | tom (6 for Ca). That is outside the 0.5–4.5 range for finite cl | tool read_skill (toolu_016KMyPxmsL5gY5MDqFxhezL#1) data.text |
| 5.99 | nd_gr_peaks` on Ti–Ti. I take its CN of 5.99 from the context. - | tool find_gr_peaks (toolu_019TZgYjcxDDZGKJXb4cALfr#11) data.first_shell.cn.O_per_Ti |
| 2.21 Å | octahedra** (`polyhedral_distortion`, 0–2.21 Å): 511 of 512 Ti hav | tool find_gr_peaks (toolu_019TZgYjcxDDZGKJXb4cALfr#11) data.first_shell.window_A[1] |
| 0.0339 | ave 6 O. - Baur's distortion index is 0.0339 in the configuratio | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.configuration.distortion_index.mean |
| 0.0179 | is 0.0339 in the configuration, against 0.0179 in the average stru | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.distortion_index.mean |
| 1.0091 | - Robinson's quadratic elongation is 1.0091, against 1.0009. | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.configuration.quadratic_elongation.mean |
| 1.0009 | quadratic elongation is 1.0091, against 1.0009. - The angle vari | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.quadratic_elongation.mean |
| 25.1 ° | ainst 1.0009. - The angle variance is 25.1 deg², against 2.05 deg² | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.configuration.angle_variance_deg2.mean |
| 2.05 ° | he angle variance is 25.1 deg², against 2.05 deg². - The octahedra | tool polyhedral_distortion (toolu_019CDr89wKTXJGSM6vZtcVek#12) data.average_structure.angle_variance_deg2.mean |
| 1.925 Å | ** - The Ti–O shell is a single peak, 1.925 Å with CN 5.99. - T | tool find_gr_peaks (toolu_019TZgYjcxDDZGKJXb4cALfr#11) data.peaks_A[0].r |
| 5.99 | shell is a single peak, 1.925 Å with CN 5.99. - The Ca–O shell | tool find_gr_peaks (toolu_019TZgYjcxDDZGKJXb4cALfr#11) data.first_shell.cn.O_per_Ti |
| 2.705 Å | 9. - The Ca–O shell is a single peak, 2.705 Å with CN 12. - The | tool find_gr_peaks (toolu_013ESr8sRQMuWASvYhMKGgs9#18) data.peaks_A[0].r |
| 3.795 | th CN 12. - The Ca–Ca shell is split (3.795 and 3.865 Å, FWHM 0 | tool find_gr_peaks (toolu_01PBda8tV4ED4p5VrA3yqZ9D#6) data.peaks_A[0].r |
| 3.865 Å | - The Ca–Ca shell is split (3.795 and 3.865 Å, FWHM 0.28 and 0.27 | tool find_gr_peaks (toolu_01PBda8tV4ED4p5VrA3yqZ9D#6) data.peaks_A[1].r |
| 0.28 | shell is split (3.795 and 3.865 Å, FWHM 0.28 and 0.27 Å), but th | tool find_gr_peaks (toolu_01PBda8tV4ED4p5VrA3yqZ9D#6) data.peaks_A[0].fwhm |
| 0.27 Å | split (3.795 and 3.865 Å, FWHM 0.28 and 0.27 Å), but the peaks are | tool find_gr_peaks (toolu_01PBda8tV4ED4p5VrA3yqZ9D#6) data.peaks_A[1].fwhm |
| 3.854 Å | less than a FWHM and the shell mean of 3.854 Å matches the average | tool find_gr_peaks (toolu_01PBda8tV4ED4p5VrA3yqZ9D#6) data.first_shell.mean_d_A |
| 3.85 Å | tches the average-structure distance of 3.85 Å. I did not follow t | tool find_gr_peaks (toolu_01PBda8tV4ED4p5VrA3yqZ9D#6) data.first_shell.mean_d_A |
| 0.09 | ter order. The reported group is Pm-3m (0.09–1 Å) as you chose, | tool ask_user (app_ask_1) note |
| 1 Å | rder. The reported group is Pm-3m (0.09–1 Å) as you chose, with | tool ask_user (app_ask_1) note |
| 0.033 Å | 3m (0.09–1 Å) as you chose, with R3m at 0.033 Å beside it. Outcome | tool list_sites (toolu_01BWyPe8zgg6WtizFBLRvxSR#3) data.sites[2].kurtosis |
| 0.09 | e structure is consistent with Pm-3m at 0.09–1 Å (centrosymmetri | tool ask_user (app_ask_1) note |
| 1 Å | ucture is consistent with Pm-3m at 0.09–1 Å (centrosymmetric, a | tool ask_user (app_ask_1) note |
| 3 σ | lar R3m lowering. No superstructure, no 3σ displacement direct | tool ask_user (app_ask_1) note |

## Safety

- Unsafe actions: 0
- Unknown-tool calls: 0 · failed calls: 4 · questions to the user: 1 (all skipped by the simulated user)
- Skills read: local-order, local-symmetry

## Planted truth (never shown to the model)

every Ti shifted by 0.06 Å along [1 1 1] (coherent): the average structure is R3m, polar

```json
{
 "features": [
  {
   "kind": "symmetry_lowering",
   "element": "Ti",
   "accept": [
    "symmetry_lowering",
    "off_centre"
   ],
   "direction_uvw": [
    1,
    1,
    1
   ],
   "direction_mode": "axis",
   "magnitude_A": 0.06
  }
 ],
 "tolerated": [],
 "symmetry": {
  "space_group": "R3m",
  "chiral": false,
  "centrosymmetric": false,
  "polar": true,
  "primary": true
 }
}
```

Traps in this case:
- at the Detected SG card's default 0.2 Å the shift (0.06 Å) is inside the tolerance: the card says Pm-3m
